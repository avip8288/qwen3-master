import json
import os
import random
import re
from typing import List, Dict, Any, Optional, Union, Tuple
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from torch.utils.tensorboard import SummaryWriter
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    PreTrainedModel,
    PreTrainedTokenizer,
)
from dataclasses import dataclass
import deepspeed
from transformers import default_data_collator

# 设置随机种子
def set_seed(seed: int = 42):
    random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

set_seed()

# 检查是否有可用的GPU
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

class NL2SQLDataset(Dataset):
    def __init__(self, data_path: str, tokenizer: PreTrainedTokenizer, max_length: int = 256):
        self.data = self._load_data(data_path)
        self.tokenizer = tokenizer
        self.max_length = max_length
        
    def _load_data(self, data_path: str) -> List[Dict[str, str]]:
        try:
            with open(data_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            return data
        except Exception as e:
            print(f"加载数据失败: {e}")
            return []
            
    def __len__(self) -> int:
        return len(self.data)
        
    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        item = self.data[idx]
        instruction = item["instruction"]
        input_text = item["input"]
        output = item["output"]
        prompt = f"{instruction}\n{input_text}"
        
        inputs = self.tokenizer(
            prompt,
            max_length=self.max_length,
            truncation=True,
            padding="max_length",
            return_tensors="pt",
        )
        
        targets = self.tokenizer(
            output,
            max_length=self.max_length,
            truncation=True,
            padding="max_length",
            return_tensors="pt",
        )
        
        return {
            "input_ids": inputs["input_ids"].squeeze(0),
            "attention_mask": inputs["attention_mask"].squeeze(0),
            "target_ids": targets["input_ids"].squeeze(0),
            "target_attention_mask": targets["attention_mask"].squeeze(0),
        }

class Critic(nn.Module):
    def __init__(self, base_model: PreTrainedModel):
        super().__init__()
        self.base_model = base_model
        self.value_head = nn.Linear(base_model.config.hidden_size, 1)
        self.to(base_model.dtype)
        
    def forward(self, input_ids: torch.Tensor, attention_mask: torch.Tensor, num_actions: int) -> torch.Tensor:
        hidden_state = self.base_model(input_ids, attention_mask=attention_mask).last_hidden_state
        value_output = self.value_head(hidden_state)
        values = value_output.squeeze(-1)[:, -num_actions:]
        return values

class SQLRewardModel(nn.Module):
    def __init__(self, base_model: PreTrainedModel):
        super().__init__()
        self.base_model = base_model
        self.reward_head = nn.Linear(base_model.config.hidden_size, 1)
        self.to(base_model.dtype)
        
    def forward(self, input_ids: torch.Tensor, attention_mask: torch.Tensor) -> torch.Tensor:
        outputs = self.base_model(input_ids, attention_mask=attention_mask)
        pooled_output = outputs.last_hidden_state[:, 0, :]
        reward = self.reward_head(pooled_output)
        return reward

def compute_policy_loss(log_probs, old_log_probs, advantages, action_mask=None, clip_eps=0.2):
    ratio = torch.exp(log_probs - old_log_probs)
    surr1 = ratio * advantages
    surr2 = ratio.clamp(1.0 - clip_eps, 1.0 + clip_eps) * advantages
    loss = -torch.min(surr1, surr2)
    
    if action_mask is None:
        return loss.mean()
    return ((loss * action_mask).sum() / action_mask.sum())

def compute_value_loss(values, old_values, returns, action_mask=None, clip_eps=None):
    if clip_eps is not None:
        values_clipped = old_values + (values - old_values).clamp(-clip_eps, clip_eps)
        surr1 = (values_clipped - returns) ** 2
        surr2 = (values - returns) ** 2
        loss = torch.max(surr1, surr2)
    else:
        loss = (values - returns) ** 2
        
    if action_mask is None:
        return loss.mean()
    return ((loss * action_mask).sum() / action_mask.sum())

class ExperienceBuffer:
    def __init__(self, limit: int = 500):
        self.limit = limit
        self.buffer = []
        
    def append(self, experiences: List[Dict[str, Any]]) -> None:
        self.buffer.extend(experiences)
        if len(self.buffer) > self.limit:
            self.buffer = self.buffer[-self.limit:]
            
    def get_batches(self, batch_size: int) -> List[Dict[str, Any]]:
        if len(self.buffer) < batch_size:
            return self.buffer
        return random.sample(self.buffer, batch_size)
        
    def clear(self) -> None:
        self.buffer = []
        
    def __len__(self) -> int:
        return len(self.buffer)

@dataclass
class Samples:
    seqs: torch.Tensor
    attention_mask: Optional[torch.Tensor]
    action_mask: Optional[torch.Tensor]
    num_actions: Union[int, torch.Tensor]
    response_length: torch.Tensor
    total_length: torch.Tensor

@dataclass
class Experience:
    seqs: torch.Tensor
    action_log_probs: torch.Tensor
    values: torch.Tensor
    returns: torch.Tensor
    advantages: torch.Tensor
    attention_mask: torch.Tensor
    action_mask: torch.Tensor
    reward: torch.Tensor
    response_length: torch.Tensor
    total_length: torch.Tensor
    num_actions: Union[int, torch.Tensor]
    kl: Optional[torch.Tensor] = None

def compute_approx_kl(log_probs, ref_log_probs, action_mask=None):
    log_ratio = log_probs - ref_log_probs
    if action_mask is not None:
        log_ratio = log_ratio * action_mask
    return log_ratio

def get_advantages_and_returns(values, rewards, action_mask, gamma=0.99, lambd=0.95):
    lastgaelam = 0
    advantages_reversed = []
    response_length = rewards.size(1)
    
    if action_mask is not None:
        values = values * action_mask
        rewards = rewards * action_mask
    
    for t in reversed(range(response_length)):
        nextvalues = values[:, t + 1] if t < response_length - 1 else 0.0
        delta = rewards[:, t] + gamma * nextvalues - values[:, t]
        lastgaelam = delta + gamma * lambd * lastgaelam
        advantages_reversed.append(lastgaelam)
    
    advantages = torch.stack(advantages_reversed[::-1], dim=1)
    returns = advantages + values
    return advantages.detach(), returns.detach()

def generate_samples(prompts, model, tokenizer, max_length=256, max_new_tokens=32, n_samples_per_prompt=1, batch_size=1):
    samples_list = []
    model.eval()
    
    all_prompts = [p for prompt in prompts for p in [prompt] * n_samples_per_prompt]
    
    for i in range(0, len(all_prompts), batch_size):
        batch_prompts = all_prompts[i : i + batch_size]
        
        inputs = tokenizer(
            batch_prompts,
            padding="max_length",
            max_length=max_length - max_new_tokens,
            truncation=True,
            return_tensors="pt",
        )
        
        input_ids = inputs["input_ids"].to(device)
        attention_mask = inputs["attention_mask"].to(device)
        
        with torch.no_grad():
            with torch.amp.autocast(device_type='cuda', dtype=torch.float16):
                outputs = model.generate(
                    input_ids=input_ids,
                    attention_mask=attention_mask,
                    max_new_tokens=max_new_tokens,
                    pad_token_id=tokenizer.pad_token_id,
                    eos_token_id=tokenizer.eos_token_id,
                    do_sample=True,
                    temperature=0.5,
                    top_p=0.9,
                )
        
        generated_tokens = outputs[:, input_ids.shape[1]:]
        action_mask = generated_tokens.ne(tokenizer.pad_token_id) & generated_tokens.ne(tokenizer.eos_token_id)
        
        samples = Samples(
            seqs=outputs,
            attention_mask=(outputs.ne(tokenizer.pad_token_id)).to(dtype=torch.long),
            action_mask=action_mask.to(dtype=torch.long),
            num_actions=action_mask.size(1),
            response_length=action_mask.sum(dim=1).float(),
            total_length=(outputs.ne(tokenizer.pad_token_id)).sum(dim=1).float(),
        )
        
        samples_list.append(samples)
    
    return samples_list

def compute_sql_rewards(generated_sqls, target_sqls, reward_model, reward_tokenizer, kl, action_mask, kl_ctl=0.1, clip_reward_value=10.0):
    reward_inputs = [f"生成的SQL: {gen_sql}\n参考SQL: {target_sql}" for gen_sql, target_sql in zip(generated_sqls, target_sqls)]
    
    inputs = reward_tokenizer(
        reward_inputs,
        padding="max_length",
        max_length=256,
        truncation=True,
        return_tensors="pt",
    ).to(device)
    
    with torch.no_grad():
        with torch.amp.autocast(device_type='cuda', dtype=torch.float16):
            reward_scores = reward_model(**inputs).squeeze(-1)
    
    kl_penalty = -kl_ctl * kl
    rewards = kl_penalty
    
    ends = action_mask.sum(1)
    for i in range(len(rewards)):
        if ends[i] > 0:
            rewards[i, ends[i]-1] += reward_scores[i]
    
    rewards = torch.clamp(rewards, -clip_reward_value, clip_reward_value)
    return rewards

def generate_experiences(samples_list, actor_model, ref_model, critic_model, reward_model, tokenizer, target_sqls, kl_ctl=0.1, clip_reward_value=10.0):
    experiences = []
    
    for samples in samples_list:
        seqs = samples.seqs
        attention_mask = samples.attention_mask
        action_mask = samples.action_mask
        num_actions = samples.num_actions
        
        with torch.no_grad():
            with torch.amp.autocast(device_type='cuda', dtype=torch.float16):
                actor_outputs = actor_model(seqs, attention_mask=attention_mask)
                logits = actor_outputs.logits
                log_probs = F.log_softmax(logits[:, :-1, :], dim=-1)
                next_token_log_probs = log_probs.gather(dim=-1, index=seqs[:, 1:].unsqueeze(-1)).squeeze(-1)
                action_log_probs = next_token_log_probs[:, -num_actions:]
                
                ref_outputs = ref_model(seqs, attention_mask=attention_mask)
                ref_logits = ref_outputs.logits
                ref_log_probs = F.log_softmax(ref_logits[:, :-1, :], dim=-1)
                ref_next_token_log_probs = ref_log_probs.gather(dim=-1, index=seqs[:, 1:].unsqueeze(-1)).squeeze(-1)
                ref_action_log_probs = ref_next_token_log_probs[:, -num_actions:]
                
                kl = compute_approx_kl(action_log_probs, ref_action_log_probs, action_mask=action_mask)
                values = critic_model(seqs, attention_mask, num_actions)
                
                generated_sqls = [tokenizer.decode(seq[attention_mask.sum(dim=1)-num_actions:], skip_special_tokens=True) for seq in seqs]
                rewards = compute_sql_rewards(generated_sqls, target_sqls, reward_model, tokenizer, kl, action_mask, kl_ctl, clip_reward_value)
                
                advantages, returns = get_advantages_and_returns(values, rewards, action_mask)
            
        experience = Experience(
            seqs=seqs,
            action_log_probs=action_log_probs,
            values=values,
            returns=returns,
            advantages=advantages,
            attention_mask=attention_mask,
            action_mask=action_mask,
            reward=rewards,
            response_length=samples.response_length,
            total_length=samples.total_length,
            num_actions=num_actions,
            kl=kl,
        )
        
        experiences.append(experience)
    
    return experiences

def train_step(experience, actor_engine, critic_engine, clip_eps=0.2, clip_value_eps=0.2, writer=None, global_step=0):
    if torch.isnan(experience.seqs).any() or torch.isinf(experience.seqs).any():
        return None, None, None
    
    if torch.isnan(experience.advantages).any() or torch.isinf(experience.advantages).any():
        return None, None, None
    
    actor_engine.train()
    critic_engine.train()
    
    seqs = experience.seqs
    attention_mask = experience.attention_mask
    action_mask = experience.action_mask
    old_action_log_probs = experience.action_log_probs
    advantages = experience.advantages
    num_actions = experience.num_actions
    
    if isinstance(num_actions, list) and len(num_actions) > 0:
        num_actions = num_actions[0]
    elif isinstance(num_actions, torch.Tensor):
        num_actions = num_actions.item()
    
    if not isinstance(num_actions, int) or num_actions <= 0:
        return None, None, None
    
    with torch.amp.autocast(device_type='cuda', dtype=torch.float16):
        outputs = actor_engine(seqs, attention_mask=attention_mask)
        logits = outputs.logits
        log_probs = F.log_softmax(logits[:, :-1, :], dim=-1)
        next_token_log_probs = log_probs.gather(dim=-1, index=seqs[:, 1:].unsqueeze(-1)).squeeze(-1)
        action_log_probs = next_token_log_probs[:, -num_actions:]
        
        advantages = (advantages - advantages.mean()) / (advantages.std() + 1e-8)
        advantages = torch.clamp(advantages, -2.0, 2.0)
        
        policy_loss = compute_policy_loss(action_log_probs, old_action_log_probs, advantages, action_mask, clip_eps)
    
    if torch.isnan(policy_loss) or torch.isinf(policy_loss):
        return None, None, None
        
    actor_engine.backward(policy_loss)
    actor_engine.step()
    
    with torch.amp.autocast(device_type='cuda', dtype=torch.float16):
        values = critic_engine(seqs, attention_mask, num_actions)
        returns = torch.clamp(returns, -2.0, 2.0)
        value_loss = compute_value_loss(values, old_values, returns, action_mask, clip_value_eps)
    
    if torch.isnan(value_loss) or torch.isinf(value_loss):
        return None, None, None
        
    critic_engine.backward(value_loss)
    critic_engine.step()
    
    if writer is not None and global_step % 10 == 0 and deepspeed.comm.get_rank() == 0:
        writer.add_scalar("policy_loss", policy_loss.item(), global_step)
        writer.add_scalar("value_loss", value_loss.item(), global_step)
        writer.add_scalar("reward_mean", experience.reward.mean().item(), global_step)
    
    return policy_loss.item(), value_loss.item(), experience.reward.mean().item()

def train(actor_model, ref_model, critic_model, reward_model, tokenizer, dataset, output_dir="./results", 
          batch_size=2, micro_batch_size=1, max_epochs=3, max_new_tokens=32, n_samples_per_prompt=1,
          kl_ctl=0.03, clip_reward_value=2.0, clip_eps=0.05, clip_value_eps=0.05,
          learning_rate_actor=5e-8, learning_rate_critic=5e-8, log_dir="./logs"):
    
    # 创建输出目录
    os.makedirs(output_dir, exist_ok=True)
    
    # 准备数据加载器
    dataloader = DataLoader(dataset, batch_size=1, shuffle=True, collate_fn=default_data_collator)
    
    # 获取当前设备数量
    world_size = torch.cuda.device_count() if torch.cuda.is_available() else 1
    
    # 设置DeepSpeed配置 - 针对旧版本DeepSpeed优化
    deepspeed_config = {
        "train_micro_batch_size_per_gpu": micro_batch_size,
        "gradient_accumulation_steps": 1,
        "optimizer": {
            "type": "AdamW",
            "params": {
                "lr": learning_rate_actor,
                "betas": [0.9, 0.999],
                "eps": 1e-8,
                "weight_decay": 0.01
            }
        },
        "fp16": {
            "enabled": True,
            "loss_scale": 0,
            "loss_scale_window": 1000,
            "initial_scale_power": 16
        },
        "scheduler": {
            "type": "WarmupLR",
            "params": {
                "warmup_min_lr": 0,
                "warmup_max_lr": learning_rate_actor,
                "warmup_num_steps": 1000
            }
        },
        "zero_optimization": {
            "stage": 2,
            "offload_optimizer": {
                "device": "cpu",
                "pin_memory": True
            },
            "offload_param": {
                "device": "cpu",
                "pin_memory": True
            },
            "overlap_comm": True,
            "contiguous_gradients": True,
            "reduce_bucket_size": 300000000
        },
        "steps_per_print": 10,
        "wall_clock_breakdown": False
    }
    
    # 初始化actor模型的DeepSpeed引擎
    optimizer_actor = torch.optim.AdamW(actor_model.parameters(), lr=learning_rate_actor)
    actor_engine, _, _, _ = deepspeed.initialize(
        args=None,
        model=actor_model,
        model_parameters=actor_model.parameters(),
        config_params=deepspeed_config
    )
    
    # 初始化critic模型的DeepSpeed引擎
    optimizer_critic = torch.optim.AdamW(critic_model.parameters(), lr=learning_rate_critic)
    critic_engine, _, _, _ = deepspeed.initialize(
        args=None,
        model=critic_model,
        model_parameters=critic_model.parameters(),
        config_params=deepspeed_config
    )
    
    # 将ref_model和reward_model移到设备上
    ref_model = ref_model.to(device)
    reward_model = reward_model.to(device)
    
    # 创建经验缓冲区
    buffer = ExperienceBuffer(limit=500)
    
    # 初始化TensorBoard写入器
    if deepspeed.comm.get_rank() == 0:
        writer = SummaryWriter(log_dir)
        print(f"TensorBoard日志将保存在: {log_dir}")
    else:
        writer = None
    
    global_step = 0
    
    for epoch in range(max_epochs):
        if deepspeed.comm.get_rank() == 0:
            print(f"Epoch {epoch+1}/{max_epochs}")
        
        for batch_idx, batch in enumerate(dataloader):
            batch = {k: v.to(device) for k, v in batch.items()}
            input_ids = batch["input_ids"]
            attention_mask = batch["attention_mask"]
            target_ids = batch["target_ids"]
            
            target_sqls = [tokenizer.decode(ids, skip_special_tokens=True) for ids in target_ids]
            prompts = [tokenizer.decode(input_ids[i][:attention_mask[i].sum()], skip_special_tokens=True) for i in range(len(input_ids))]
            
            samples_list = generate_samples(
                prompts, actor_engine, tokenizer, 
                max_length=256, max_new_tokens=32, 
                n_samples_per_prompt=1, batch_size=1
            )
            
            experiences = generate_experiences(samples_list, actor_engine, ref_model, critic_model, reward_model, tokenizer, target_sqls, kl_ctl, clip_reward_value)
            
            for exp in experiences:
                for k, v in exp.__dict__.items():
                    if isinstance(v, torch.Tensor):
                        exp.__dict__[k] = v.to(device)
            
            buffer.append([vars(exp) for exp in experiences])
            
            if len(buffer) >= micro_batch_size:
                batch_experience = buffer.get_batches(micro_batch_size)
                merged_exp = {}
                
                for k in batch_experience[0].keys():
                    values = [exp[k] for exp in batch_experience]
                    if isinstance(values[0], torch.Tensor):
                        merged_exp[k] = torch.cat([v.to(device) for v in values], dim=0)
                    else:
                        merged_exp[k] = values
                
                merged_exp_obj = Experience(**merged_exp)
                if isinstance(merged_exp_obj.num_actions, torch.Tensor):
                    merged_exp_obj.num_actions = merged_exp_obj.num_actions.item()
                
                policy_loss, value_loss, reward_mean = train_step(
                    merged_exp_obj, actor_engine, critic_engine, 
                    clip_eps, clip_value_eps, writer, global_step
                )
                global_step += 1
            
            if (batch_idx + 1) % 50 == 0 and deepspeed.comm.get_rank() == 0:
                print(f"Batch {batch_idx+1}, Step {global_step}")
                actor_engine.save_pretrained(os.path.join(output_dir, f"model_step_{global_step}"), save_optimizer=False, save_lr_scheduler=False)
                tokenizer.save_pretrained(os.path.join(output_dir, f"model_step_{global_step}"))
        
        if deepspeed.comm.get_rank() == 0:
            print(f"Saving model at epoch {epoch+1}")
            actor_engine.save_pretrained(os.path.join(output_dir, f"model_epoch_{epoch+1}"), save_optimizer=False, save_lr_scheduler=False)
            tokenizer.save_pretrained(os.path.join(output_dir, f"model_epoch_{epoch+1}"))
    
    if deepspeed.comm.get_rank() == 0:
        print("Training completed! Saving final model...")
        actor_engine.save_pretrained(os.path.join(output_dir, "final_model"), save_optimizer=False, save_lr_scheduler=False)
        tokenizer.save_pretrained(os.path.join(output_dir, "final_model"))
        if writer is not None:
            writer.close()
        print("Training finished.")

def evaluate(model, tokenizer, dataset, num_samples=5, max_new_tokens=32):
    if deepspeed.comm.get_rank() == 0:
        model.eval()
        
        indices = random.sample(range(len(dataset)), min(num_samples, len(dataset)))
        
        for i, idx in enumerate(indices):
            sample = dataset[idx]
            input_ids = sample["input_ids"].unsqueeze(0).to(device)
            attention_mask = sample["attention_mask"].unsqueeze(0).to(device)
            target_ids = sample["target_ids"]
            
            with torch.no_grad():
                with torch.amp.autocast(device_type='cuda', dtype=torch.float16):
                    outputs = model.generate(
                        input_ids=input_ids,
                        attention_mask=attention_mask,
                        max_new_tokens=max_new_tokens,
                        pad_token_id=tokenizer.pad_token_id,
                        eos_token_id=tokenizer.eos_token_id,
                        temperature=0.3,
                    )
            
            generated_sql = tokenizer.decode(outputs[0][input_ids.shape[1]:], skip_special_tokens=True)
            target_sql = tokenizer.decode(target_ids, skip_special_tokens=True)
            prompt = tokenizer.decode(input_ids[0][:attention_mask[0].sum()], skip_special_tokens=True)
            
            print(f"\n示例 {i+1}:")
            print(f"输入提示:\n{prompt}")
            print(f"\n生成的SQL:\n{generated_sql}")
            print(f"\n参考SQL:\n{target_sql}")
            print("-" * 80)

def main():
    os.environ["TOKENIZERS_PARALLELISM"] = "false"
    
    model_name = r"/Qwen3-4B"
    dataset_path = r"/root/20230412_78K_SelfMade_NL2SQLpilot.json"
    output_dir = "./nl2sql_deepspeed_results"
    log_dir = "./nl2sql_deepspeed_logs"
    
    # 初始化DeepSpeed
    deepspeed.init_distributed()
    
    # 加载tokenizer
    if deepspeed.comm.get_rank() == 0:
        print("加载tokenizer...")
    tokenizer = AutoTokenizer.from_pretrained(model_name, trust_remote_code=True)
    tokenizer.padding_side = "left"
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    
    # 加载模型
    if deepspeed.comm.get_rank() == 0:
        print("加载模型...")
    actor_model = AutoModelForCausalLM.from_pretrained(
        model_name, 
        trust_remote_code=True,
        torch_dtype=torch.float16,
        low_cpu_mem_usage=True
    )
    
    if hasattr(actor_model, "tie_weights"):
        actor_model.tie_weights()
    
    actor_model.train()
    
    ref_model = AutoModelForCausalLM.from_pretrained(
        model_name, 
        trust_remote_code=True,
        torch_dtype=torch.float16,
        low_cpu_mem_usage=True
    )
    
    if hasattr(ref_model, "tie_weights"):
        ref_model.tie_weights()
    
    ref_model.eval()
    
    critic_model = Critic(actor_model.base_model).to(device)
    reward_model = SQLRewardModel(actor_model.base_model).to(device)
    
    # 加载数据集
    if deepspeed.comm.get_rank() == 0:
        print("加载数据集...")
    dataset = NL2SQLDataset(dataset_path, tokenizer)
    
    # 开始训练
    if deepspeed.comm.get_rank() == 0:
        print("开始训练...")
    train(
        actor_model=actor_model,
        ref_model=ref_model,
        critic_model=critic_model,
        reward_model=reward_model,
        tokenizer=tokenizer,
        dataset=dataset,
        output_dir=output_dir,
        batch_size=2,
        micro_batch_size=1,
        max_epochs=3,
        max_new_tokens=32,
        n_samples_per_prompt=1,
        kl_ctl=0.03,
        clip_reward_value=2.0,
        clip_eps=0.05,
        clip_value_eps=0.05,
        learning_rate_actor=5e-8,
        learning_rate_critic=5e-8,
        log_dir=log_dir,
    )
    
    # 评估模型
    if deepspeed.comm.get_rank() == 0:
        print("评估模型...")
        evaluate(
            model=actor_model,
            tokenizer=tokenizer,
            dataset=dataset,
            num_samples=5,
            max_new_tokens=32,
        )

if __name__ == "__main__":
    main()