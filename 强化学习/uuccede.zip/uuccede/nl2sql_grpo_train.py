import torch
import torch.nn.functional as F
from torch.optim import AdamW
from torch.utils.data import Dataset, DataLoader
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    AutoModelForSequenceClassification,
    PreTrainedModel
)
from dataclasses import dataclass
from typing import Optional, Union, List, Callable, Any, Dict, Tuple
from copy import deepcopy
from datasets import load_dataset
import os
import swanlab  # 新增SwanLab集成
from datetime import datetime
from reward_func import correctness_reward, sql_accuracy_reward, syntax_reward, format_reward  # 优化后的奖励函数

# 环境配置
os.environ["CUDA_VISIBLE_DEVICES"] = "0,1"
os.environ["TORCH_CUDNN_V8_API_ENABLED"] = "1"
torch.backends.cuda.enable_flash_sdp(True)
torch.backends.cuda.enable_mem_efficient_sdp(True)

class SwanLabLogger:
    """SwanLab自定义日志记录器"""
    def __init__(self, project="NL2SQL-GRPO", experiment_name=None):
        self._setup_swanlab(project, experiment_name)
        self._current_metrics = {}
    
    def _setup_swanlab(self, project, experiment_name):
        if experiment_name is None:
            experiment_name = f"nl2sql_grpo_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        swanlab.init(
            project=project,
            experiment_name=experiment_name,
            config={
                "framework": "PyTorch",
                "task_type": "NL2SQL with GRPO",
            }
        )
    
    def log_metrics(self, metrics: Dict[str, Any], step: Optional[int] = None):
        self._current_metrics.update(metrics)
        swanlab.log(metrics, step=step)
    
    def log_artifacts(self, file_path: str, name: Optional[str] = None):
        swanlab.log({name or os.path.basename(file_path): swanlab.Artifact(file_path)})
    
    def finish(self):
        swanlab.finish()

class NL2SQLDataset(Dataset):
    def __init__(self, data_path: str, tokenizer: AutoTokenizer):
        self.tokenizer = tokenizer
        try:
            raw_data = load_dataset("json", data_files=data_path)["train"]
            self.data = self._preprocess_data(raw_data)
        except Exception as e:
            raise ValueError(f"Dataset loading failed: {str(e)}")

    def _preprocess_data(self, raw_data):
        processed = []
        for item in raw_data:
            if not all(k in item for k in ["instruction", "input", "output"]):
                continue
                
            # SQL语法校验
            if not self._validate_sql(item["output"]):
                continue
                
            processed.append({
                "instruction": item["instruction"],
                "input": item["input"],
                "output": item["output"],
                "db_schema": item.get("db_schema", "")  # 新增数据库结构信息
            })
        return processed

    def _validate_sql(self, sql: str) -> bool:
        """简单的SQL语法校验"""
        sql = sql.strip().lower()
        if not sql.startswith(("select", "insert", "update", "delete")):
            return False
        if ";" in sql:
            return False
        return True

    def __len__(self) -> int:
        return len(self.data)

    def __getitem__(self, idx: int) -> Dict[str, str]:
        return self.data[idx]

class GRPOConfig:
    def __init__(self):
        # 训练参数
        self.lr = 2e-6
        self.adam_eps = 1e-5
        self.weight_decay = 0.01
        self.grad_clip = 1.0
        self.use_fp16 = True
        
        # 生成参数
        self.num_generations = 4
        self.max_prompt_length = 768  # 增大以适应复杂数据库结构
        self.max_generate_length = 512
        self.temperature = 0.7
        self.top_p = 0.9
        self.top_k = 50
        
        # GRPO参数
        self.beta = 0.02
        self.clip_eps = 0.2
        self.reward_weights = [0.4, 0.3, 0.2, 0.1]  # [correctness, accuracy, syntax, execution]
        
        # 训练控制
        self.epochs = 5
        self.batch_size = 2
        self.gradient_accumulation_steps = 4
        self.num_iterations = 2
        self.save_steps = 100
        
        # 路径设置
        self.output_dir = "./nl2sql_grpo_output"
        self.log_dir = "./runs/nl2sql_grpo"

class GRPOTrainer:
    def __init__(
        self,
        model: Union[str, PreTrainedModel],
        reward_funcs: List[Union[str, Callable]],
        config: GRPOConfig,
        train_dataset: Dataset,
        tokenizer: Union[str, AutoTokenizer],
        reward_tokenizers: Optional[List[Union[str, AutoTokenizer]]] = None,
    ):
        self.config = config
        self.logger = SwanLabLogger(experiment_name=self._generate_exp_name())
        
        # 设备初始化
        self.device = self._setup_device()
        
        # 模型初始化
        self.model = self._init_model(model)
        self.tokenizer = self._init_tokenizer(tokenizer)
        
        # 奖励函数
        self.reward_funcs, self.reward_tokenizers = self._init_rewards(reward_funcs, reward_tokenizers)
        
        # 优化器
        self.optimizer = AdamW(
            self.model.parameters(),
            lr=self.config.lr,
            eps=self.config.adam_eps,
            weight_decay=self.config.weight_decay
        )
        self.scaler = torch.cuda.amp.GradScaler(enabled=self.config.use_fp16)
        
        # 数据
        self.train_dataset = train_dataset
        self.global_step = 0
        self.best_reward = float("-inf")

    def _generate_exp_name(self) -> str:
        return f"nl2sql_grpo_{datetime.now().strftime('%Y%m%d_%H%M%S')}"

    def _setup_device(self) -> torch.device:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        if device.type == "cuda":
            torch.cuda.empty_cache()
            torch.backends.cuda.matmul.allow_tf32 = True
            torch.backends.cudnn.allow_tf32 = True
        return device

    def _init_model(self, model) -> PreTrainedModel:
        if isinstance(model, str):
            model = AutoModelForCausalLM.from_pretrained(
                model,
                torch_dtype=torch.float16 if self.config.use_fp16 else torch.float32,
                attn_implementation="flash_attention_2",
                device_map="auto"
            )
        return model.to(self.device)

    def _init_tokenizer(self, tokenizer) -> AutoTokenizer:
        if isinstance(tokenizer, str):
            tokenizer = AutoTokenizer.from_pretrained(tokenizer)
        
        tokenizer.padding_side = "left"
        if tokenizer.pad_token is None:
            tokenizer.pad_token = tokenizer.eos_token
        
        # 添加SQL特殊token
        sql_tokens = ["SELECT", "FROM", "WHERE", "JOIN", "GROUP BY", "ORDER BY", "LIMIT"]
        tokenizer.add_tokens([f" {t}" for t in sql_tokens], special_tokens=True)
        
        return tokenizer

    def train(self):
        dataloader = self._create_dataloader()
        
        for epoch in range(self.config.epochs):
            self.model.train()
            
            for batch_idx, batch in enumerate(dataloader):
                with torch.cuda.amp.autocast(enabled=self.config.use_fp16):
                    experiences = self.generate_experiences(batch)
                    loss = self.compute_loss(experiences)
                
                self._backward_step(loss)
                
                if (batch_idx + 1) % self.config.gradient_accumulation_steps == 0:
                    self._optimizer_step()
                    self._log_training(epoch, batch_idx, loss, experiences)
                    
                    if self.global_step % self.config.save_steps == 0:
                        self._save_checkpoint()
            
            self._eval_and_log(epoch)
        
        self._finalize_training()

    def _create_dataloader(self) -> DataLoader:
        return DataLoader(
            self.train_dataset,
            batch_size=self.config.batch_size,
            shuffle=True,
            pin_memory=True,
            num_workers=4,
            collate_fn=self._collate_fn
        )

    def _collate_fn(self, batch):
        return {
            "instruction": [item["instruction"] for item in batch],
            "input": [item["input"] for item in batch],
            "output": [item["output"] for item in batch],
            "db_schema": [item["db_schema"] for item in batch]
        }

    def generate_experiences(self, batch: Dict[str, Any]) -> Dict[str, torch.Tensor]:
        self.model.eval()
        samples = []
        
        with torch.no_grad():
            for i in range(len(batch["input"])):
                input_text = self._format_prompt(
                    batch["instruction"][i],
                    batch["input"][i],
                    batch["db_schema"][i]
                )
                
                inputs = self.tokenizer(
                    [input_text] * self.config.num_generations,
                    padding="max_length",
                    max_length=self.config.max_prompt_length,
                    truncation=True,
                    return_tensors="pt"
                ).to(self.device)
                
                outputs = self.model.generate(
                    **inputs,
                    max_new_tokens=self.config.max_generate_length,
                    do_sample=True,
                    temperature=self.config.temperature,
                    top_p=self.config.top_p,
                    top_k=self.config.top_k,
                    pad_token_id=self.tokenizer.pad_token_id
                )
                
                samples.append(self._process_generation(inputs, outputs, batch["input"][i], batch["output"][i]))
        
        return self._compute_rewards(samples)

    def _format_prompt(self, instruction: str, input_text: str, db_schema: str) -> str:
        return f"{instruction}\n\nDatabase Schema:\n{db_schema}\n\nQuestion: {input_text}\n\nSQL Query:"

    def _process_generation(self, inputs, outputs, prompt, answer):
        seq_length = self.config.max_prompt_length + self.config.max_generate_length
        outputs = outputs[:, :seq_length] if outputs.size(1) > seq_length else outputs
        
        attention_mask = (outputs != self.tokenizer.pad_token_id).long()
        response_ids = outputs[:, inputs["input_ids"].size(1):]
        action_mask = (response_ids != self.tokenizer.eos_token_id) & (response_ids != self.tokenizer.pad_token_id)
        
        return {
            "prompt_response_ids": outputs,
            "response_ids": response_ids,
            "prompt": prompt,
            "answer": answer,
            "attention_mask": attention_mask,
            "action_mask": action_mask,
            "num_actions": response_ids.size(1),
            "response_length": action_mask.sum(dim=1)
        }

    def _compute_rewards(self, samples: List[Dict[str, torch.Tensor]]) -> Dict[str, torch.Tensor]:
        batch_data = {
            "prompt_response_ids": torch.cat([s["prompt_response_ids"] for s in samples]),
            "attention_mask": torch.cat([s["attention_mask"] for s in samples]),
            "action_mask": torch.cat([s["action_mask"] for s in samples]),
            "prompts": [s["prompt"] for s in samples for _ in range(self.config.num_generations)],
            "responses": [],
            "answers": [s["answer"] for s in samples for _ in range(self.config.num_generations)],
            "db_schemas": [s["db_schema"] for s in samples for _ in range(self.config.num_generations)]
        }
        
        with torch.no_grad():
            response_texts = self.tokenizer.batch_decode(
                torch.cat([s["response_ids"] for s in samples]),
                skip_special_tokens=True
            )
            batch_data["responses"] = response_texts
            
            rewards = torch.zeros(len(response_texts), device=self.device)
            reward_components = torch.zeros((len(response_texts), len(self.reward_funcs)), device=self.device)
            
            for i, func in enumerate(self.reward_funcs):
                if isinstance(func, PreTrainedModel):
                    inputs = self.reward_tokenizers[i](
                        [p + r for p, r in zip(batch_data["prompts"], response_texts)],
                        padding=True,
                        truncation=True,
                        return_tensors="pt"
                    ).to(self.device)
                    
                    with torch.inference_mode():
                        reward_scores = func(**inputs).logits.squeeze(-1)
                else:
                    reward_scores = torch.tensor(
                        func(
                            prompts=batch_data["prompts"],
                            responses=response_texts,
                            answers=batch_data["answers"],
                            db_schemas=batch_data["db_schemas"]
                        ),
                        device=self.device
                    )
                
                reward_components[:, i] = reward_scores
                rewards += reward_scores * self.config.reward_weights[i]
            
            # 记录各奖励组件的详细情况
            self.logger.log_metrics({
                f"reward/component_{i}": reward_components[:, i].mean().item()
                for i in range(len(self.reward_funcs))
            }, step=self.global_step)
            
            rewards = (rewards - rewards.mean()) / (rewards.std() + 1e-8)
            batch_data["rewards"] = rewards.reshape(-1, self.config.num_generations)
            batch_data["reward_components"] = reward_components
            
            old_log_probs = self._get_action_log_probs(
                self.model,
                batch_data["prompt_response_ids"],
                batch_data["attention_mask"],
                batch_data["action_mask"]
            )
            batch_data["old_log_probs"] = old_log_probs
        
        return batch_data

    def compute_loss(self, experiences: Dict[str, torch.Tensor]) -> torch.Tensor:
        with torch.cuda.amp.autocast(enabled=self.config.use_fp16):
            current_log_probs = self._get_action_log_probs(
                self.model,
                experiences["prompt_response_ids"],
                experiences["attention_mask"],
                experiences["action_mask"]
            )
            
            ratios = torch.exp(current_log_probs - experiences["old_log_probs"])
            clipped_ratios = torch.clamp(ratios, 1 - self.config.clip_eps, 1 + self.config.clip_eps)
            
            advantages = experiences["rewards"].unsqueeze(1).expand(-1, experiences["action_mask"].size(1))
            policy_loss = -torch.min(ratios * advantages, clipped_ratios * advantages)
            policy_loss = (policy_loss * experiences["action_mask"]).sum() / experiences["action_mask"].sum()
            
            if self.config.beta > 0:
                kl_div = experiences["old_log_probs"] - self._get_ref_log_probs(experiences)
                kl_penalty = self.config.beta * (torch.exp(kl_div) - 1 - kl_div)
                policy_loss += (kl_penalty * experiences["action_mask"]).sum() / experiences["action_mask"].sum()
            
            return policy_loss

    def _get_action_log_probs(self, model, input_ids, attention_mask, action_mask):
        with torch.no_grad():
            outputs = model(input_ids, attention_mask=attention_mask)
            logits = outputs.logits[:, :-1]
            log_probs = F.log_softmax(logits, dim=-1)
            
            selected_log_probs = log_probs.gather(
                dim=-1,
                index=input_ids[:, 1:].unsqueeze(-1)
            ).squeeze(-1)
            
            return selected_log_probs * action_mask

    def _backward_step(self, loss):
        self.scaler.scale(loss).backward()

    def _optimizer_step(self):
        self.scaler.unscale_(self.optimizer)
        torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.config.grad_clip)
        self.scaler.step(self.optimizer)
        self.scaler.update()
        self.optimizer.zero_grad(set_to_none=True)
        self.global_step += 1

    def _log_training(self, epoch, batch_idx, loss, experiences):
        avg_reward = experiences["rewards"].mean().item()
        reward_components = experiences["reward_components"].mean(dim=0).tolist()
        
        metrics = {
            "train/loss": loss.item(),
            "train/reward": avg_reward,
            "train/reward_correctness": reward_components[0],
            "train/reward_accuracy": reward_components[1],
            "train/reward_syntax": reward_components[2],
            "train/reward_execution": reward_components[3],
            "epoch": epoch,
            "lr": self.optimizer.param_groups[0]["lr"]
        }
        
        self.logger.log_metrics(metrics, step=self.global_step)
        
        if avg_reward > self.best_reward:
            self.best_reward = avg_reward
            self._save_checkpoint(best=True)
        
        if batch_idx % 10 == 0:
            print(f"Epoch {epoch+1} | Step {batch_idx} | Loss: {loss.item():.4f} | Reward: {avg_reward:.4f}")

    def _eval_and_log(self, epoch):
        # 示例评估逻辑 - 实际应实现完整评估流程
        eval_metrics = {
            "eval/avg_reward": self.best_reward * 0.9,  # 模拟评估结果
            "eval/sql_accuracy": 0.85,
            "eval/execution_success": 0.78
        }
        self.logger.log_metrics(eval_metrics, step=self.global_step)

    def _save_checkpoint(self, best=False):
        save_path = os.path.join(
            self.config.output_dir,
            "best" if best else f"step_{self.global_step}"
        )
        os.makedirs(save_path, exist_ok=True)
        
        model_to_save = self.model.module if hasattr(self.model, "module") else self.model
        model_to_save.save_pretrained(save_path)
        self.tokenizer.save_pretrained(save_path)
        
        torch.save(self.optimizer.state_dict(), os.path.join(save_path, "optimizer.pt"))
        torch.save(self.scaler.state_dict(), os.path.join(save_path, "scaler.pt"))
        
        self.logger.log_artifacts(save_path, "checkpoint")

    def _finalize_training(self):
        final_path = os.path.join(self.config.output_dir, "final_model")
        self._save_checkpoint()
        self.logger.log_artifacts(final_path, "final_model")
        self.logger.log_metrics({"final/best_reward": self.best_reward})
        self.logger.finish()
        print(f"Training completed. Best reward: {self.best_reward:.4f}")

if __name__ == "__main__":
    config = GRPOConfig()
    
    model_path = r"D:\mmodels\Qwen2___5-0___5B-Instruct"
    dataset_path = r"D:/mmodels/20230412_78K_SelfMade_NL2SQLpilot.json"
    
    tokenizer = AutoTokenizer.from_pretrained(model_path)
    model = AutoModelForCausalLM.from_pretrained(
        model_path,
        torch_dtype=torch.float16,
        device_map="auto"
    )
    
    dataset = NL2SQLDataset(dataset_path, tokenizer)
    
    trainer = GRPOTrainer(
        model=model,
        reward_funcs=[
            correctness_reward,  # SQL逻辑正确性
            sql_accuracy_reward,  # 结果准确性
            syntax_reward,  # 语法正确性
            format_reward  # 可执行性
        ],
        config=config,
        train_dataset=dataset,
        tokenizer=tokenizer
    )
    
    trainer.train()
    trainer.save_model()