import json
import os
import random
import re
from typing import List, Dict, Any, Optional, Union, Tuple
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from torch.utils.tensorboard import SummaryWriter
from transformers import AutoModelForCausalLM, AutoTokenizer, PreTrainedModel, PreTrainedTokenizer
from dataclasses import dataclass
import swanlab
import deepspeed
from deepspeed import init_distributed
from deepspeed.runtime.pipe import PipelineModule
from deepspeed.utils import RepeatingLoader
from transformers.deepspeed import HfDeepSpeedConfig

# SwanLab 导入
try:
    import swanlab
    from swanlab import Experiment
    SWANLAB_AVAILABLE = True
except ImportError:
    SWANLAB_AVAILABLE = False
    print("警告：未安装SwanLab，记录功能将仅使用TensorBoard")

def set_seed(seed: int = 42):
    random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

set_seed()

# 初始化分布式环境
init_distributed()
local_rank = torch.distributed.get_rank()
torch.cuda.set_device(local_rank)
world_size = torch.distributed.get_world_size()
device = f"cuda:{local_rank}" if torch.cuda.is_available() else "cpu"

class NL2SQLDataset(Dataset):
    def __init__(self, data_path: str, tokenizer: PreTrainedTokenizer, max_length: int = 512):
        self.data = self._load_data(data_path)
        self.tokenizer = tokenizer
        self.max_length = max_length
        
    def _load_data(self, data_path: str) -> List[Dict[str, str]]:
        try:
            with open(data_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            return data
        except Exception as e:
            print(f"加载数据失败: {e}")
            return []
            
    def __len__(self) -> int:
        return len(self.data)
        
    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        item = self.data[idx]
        instruction = item["instruction"]
        input_text = item["input"]
        output = item["output"]
        prompt = f"{instruction}\n{input_text}"
        
        inputs = self.tokenizer(
            prompt,
            max_length=self.max_length,
            truncation=True,
            padding="max_length",
            return_tensors="pt",
        )
        
        targets = self.tokenizer(
            output,
            max_length=self.max_length,
            truncation=True,
            padding="max_length",
            return_tensors="pt",
        )
        
        return {
            "input_ids": inputs["input_ids"].squeeze(0),
            "attention_mask": inputs["attention_mask"].squeeze(0),
            "target_ids": targets["input_ids"].squeeze(0),
            "target_attention_mask": targets["attention_mask"].squeeze(0),
        }

class Critic(nn.Module):
    def __init__(self, base_model: PreTrainedModel):
        super().__init__()
        self.base_model = base_model
        self.value_head = nn.Linear(base_model.config.hidden_size, 1)
        self.to(base_model.dtype)
        
    def forward(self, input_ids: torch.Tensor, attention_mask: torch.Tensor, num_actions: int) -> torch.Tensor:
        hidden_state = self.base_model(input_ids, attention_mask=attention_mask).last_hidden_state
        value_output = self.value_head(hidden_state)
        values = value_output.squeeze(-1)[:, -num_actions:]
        return values

class SQLRewardModel(nn.Module):
    def __init__(self, base_model: PreTrainedModel):
        super().__init__()
        self.base_model = base_model
        self.reward_head = nn.Linear(base_model.config.hidden_size, 1)
        self.to(base_model.dtype)
        
    def forward(self, input_ids: torch.Tensor, attention_mask: torch.Tensor) -> torch.Tensor:
        outputs = self.base_model(input_ids, attention_mask=attention_mask)
        pooled_output = outputs.last_hidden_state[:, 0, :]
        reward = self.reward_head(pooled_output)
        return reward

def compute_policy_loss(log_probs, old_log_probs, advantages, action_mask=None, clip_eps=0.2):
    ratio = torch.exp(log_probs - old_log_probs)
    surr1 = ratio * advantages
    surr2 = ratio.clamp(1.0 - clip_eps, 1.0 + clip_eps) * advantages
    loss = -torch.min(surr1, surr2)
    
    if action_mask is None:
        return loss.mean()
    return ((loss * action_mask).sum() / action_mask.sum())

def compute_value_loss(values, old_values, returns, action_mask=None, clip_eps=None):
    if clip_eps is not None:
        values_clipped = old_values + (values - old_values).clamp(-clip_eps, clip_eps)
        surr1 = (values_clipped - returns) ** 2
        surr2 = (values - returns) ** 2
        loss = torch.max(surr1, surr2)
    else:
        loss = (values - returns) ** 2
        
    if action_mask is None:
        return loss.mean()
    return ((loss * action_mask).sum() / action_mask.sum())

class ExperienceBuffer:
    def __init__(self, limit: int = 1000):
        self.limit = limit
        self.buffer = []
        
    def append(self, experiences: List[Dict[str, Any]]) -> None:
        self.buffer.extend(experiences)
        if len(self.buffer) > self.limit:
            self.buffer = self.buffer[-self.limit:]
            
    def get_batches(self, batch_size: int) -> List[Dict[str, Any]]:
        if len(self.buffer) < batch_size:
            return self.buffer
        return random.sample(self.buffer, batch_size)
        
    def clear(self) -> None:
        self.buffer = []
        
    def __len__(self) -> int:
        return len(self.buffer)

@dataclass
class Samples:
    seqs: torch.Tensor
    attention_mask: Optional[torch.Tensor]
    action_mask: Optional[torch.Tensor]
    num_actions: Union[int, torch.Tensor]
    response_length: torch.Tensor
    total_length: torch.Tensor

@dataclass
class Experience:
    seqs: torch.Tensor
    action_log_probs: torch.Tensor
    values: torch.Tensor
    returns: torch.Tensor
    advantages: torch.Tensor
    attention_mask: torch.Tensor
    action_mask: torch.Tensor
    reward: torch.Tensor
    response_length: torch.Tensor
    total_length: torch.Tensor
    num_actions: Union[int, torch.Tensor]
    kl: Optional[torch.Tensor] = None

def compute_approx_kl(log_probs, ref_log_probs, action_mask=None):
    log_ratio = log_probs - ref_log_probs
    if action_mask is not None:
        log_ratio = log_ratio * action_mask
    return log_ratio

def get_advantages_and_returns(values, rewards, action_mask, gamma=0.99, lambd=0.95):
    lastgaelam = 0
    advantages_reversed = []
    response_length = rewards.size(1)
    
    if action_mask is not None:
        values = values * action_mask
        rewards = rewards * action_mask
    
    for t in reversed(range(response_length)):
        nextvalues = values[:, t + 1] if t < response_length - 1 else 0.0
        delta = rewards[:, t] + gamma * nextvalues - values[:, t]
        lastgaelam = delta + gamma * lambd * lastgaelam
        advantages_reversed.append(lastgaelam)
    
    advantages = torch.stack(advantages_reversed[::-1], dim=1)
    returns = advantages + values
    return advantages.detach(), returns.detach()

def generate_samples(prompts, model, tokenizer, max_length=512, max_new_tokens=128, n_samples_per_prompt=1, batch_size=4):
    samples_list = []
    model.eval()
    
    all_prompts = [p for prompt in prompts for p in [prompt] * n_samples_per_prompt]
    
    for i in range(0, len(all_prompts), batch_size):
        batch_prompts = all_prompts[i : i + batch_size]
        
        inputs = tokenizer(
            batch_prompts,
            padding="max_length",
            max_length=max_length - max_new_tokens,
            truncation=True,
            return_tensors="pt",
        )
        
        input_ids = inputs["input_ids"].to(device)
        attention_mask = inputs["attention_mask"].to(device)
        
        with torch.no_grad():
            outputs = model.generate(
                input_ids=input_ids,
                attention_mask=attention_mask,
                max_new_tokens=max_new_tokens,
                pad_token_id=tokenizer.pad_token_id,
                eos_token_id=tokenizer.eos_token_id,
                do_sample=True,
                temperature=0.7,
                top_p=0.9,
            )
        
        generated_tokens = outputs[:, input_ids.shape[1]:]
        action_mask = generated_tokens.ne(tokenizer.pad_token_id) & generated_tokens.ne(tokenizer.eos_token_id)
        
        samples = Samples(
            seqs=outputs,
            attention_mask=(outputs.ne(tokenizer.pad_token_id)).to(dtype=torch.long),
            action_mask=action_mask.to(dtype=torch.long),
            num_actions=action_mask.size(1),
            response_length=action_mask.sum(dim=1).float(),
            total_length=(outputs.ne(tokenizer.pad_token_id)).sum(dim=1).float(),
        )
        
        samples_list.append(samples)
    
    return samples_list

def compute_sql_rewards(generated_sqls, target_sqls, reward_model, reward_tokenizer, kl, action_mask, kl_ctl=0.1, clip_reward_value=10.0):
    reward_inputs = [f"生成的SQL: {gen_sql}\n参考SQL: {target_sql}" for gen_sql, target_sql in zip(generated_sqls, target_sqls)]
    
    inputs = reward_tokenizer(
        reward_inputs,
        padding="max_length",
        max_length=512,
        truncation=True,
        return_tensors="pt",
    ).to(device)
    
    with torch.no_grad():
        reward_scores = reward_model(**inputs).squeeze(-1)
    
    kl_penalty = -kl_ctl * kl
    rewards = kl_penalty
    
    ends = action_mask.sum(1)
    for i in range(len(rewards)):
        if ends[i] > 0:
            rewards[i, ends[i]-1] += reward_scores[i]
    
    rewards = torch.clamp(rewards, -clip_reward_value, clip_reward_value)
    return rewards

def generate_experiences(samples_list, actor_model, ref_model, critic_model, reward_model, tokenizer, target_sqls, kl_ctl=0.1, clip_reward_value=10.0):
    experiences = []
    
    for samples in samples_list:
        seqs = samples.seqs
        attention_mask = samples.attention_mask
        action_mask = samples.action_mask
        num_actions = samples.num_actions
        
        with torch.no_grad():
            actor_outputs = actor_model(seqs, attention_mask=attention_mask)
            logits = actor_outputs.logits
            log_probs = F.log_softmax(logits[:, :-1, :], dim=-1)
            next_token_log_probs = log_probs.gather(dim=-1, index=seqs[:, 1:].unsqueeze(-1)).squeeze(-1)
            action_log_probs = next_token_log_probs[:, -num_actions:]
            
            ref_outputs = ref_model(seqs, attention_mask=attention_mask)
            ref_logits = ref_outputs.logits
            ref_log_probs = F.log_softmax(ref_logits[:, :-1, :], dim=-1)
            ref_next_token_log_probs = ref_log_probs.gather(dim=-1, index=seqs[:, 1:].unsqueeze(-1)).squeeze(-1)
            ref_action_log_probs = ref_next_token_log_probs[:, -num_actions:]
            
            kl = compute_approx_kl(action_log_probs, ref_action_log_probs, action_mask=action_mask)
            values = critic_model(seqs, attention_mask, num_actions)
            
            generated_sqls = [tokenizer.decode(seq[attention_mask.sum(dim=1)-num_actions:], skip_special_tokens=True) for seq in seqs]
            rewards = compute_sql_rewards(generated_sqls, target_sqls, reward_model, tokenizer, kl, action_mask, kl_ctl, clip_reward_value)
            
            advantages, returns = get_advantages_and_returns(values, rewards, action_mask)
            
        experience = Experience(
            seqs=seqs,
            action_log_probs=action_log_probs,
            values=values,
            returns=returns,
            advantages=advantages,
            attention_mask=attention_mask,
            action_mask=action_mask,
            reward=rewards,
            response_length=samples.response_length,
            total_length=samples.total_length,
            num_actions=num_actions,
            kl=kl,
        )
        
        experiences.append(experience)
    
    return experiences

def train_step(experience, actor_model, critic_model, optimizer_actor, optimizer_critic, clip_eps=0.2, clip_value_eps=0.2, 
               writer=None, swan_experiment=None, global_step=0):
    actor_model.train()
    critic_model.train()
    
    optimizer_actor.zero_grad()
    
    seqs = experience.seqs
    attention_mask = experience.attention_mask
    action_mask = experience.action_mask
    old_action_log_probs = experience.action_log_probs
    advantages = experience.advantages
    num_actions = experience.num_actions
    
    with torch.cuda.amp.autocast(dtype=torch.float16):
        outputs = actor_model(seqs, attention_mask=attention_mask)
        logits = outputs.logits
        logits = logits.float()
        log_probs = F.log_softmax(logits[:, :-1, :], dim=-1)
        next_token_log_probs = log_probs.gather(dim=-1, index=seqs[:, 1:].unsqueeze(-1)).squeeze(-1)
        action_log_probs = next_token_log_probs[:, -num_actions:]
        
        advantages = (advantages - advantages.mean()) / (advantages.std() + 1e-8)
        
        policy_loss = compute_policy_loss(action_log_probs, old_action_log_probs, advantages, action_mask, clip_eps)
    
    policy_loss.backward()
    torch.nn.utils.clip_grad_norm_(actor_model.parameters(), 1.0)
    optimizer_actor.step()
    
    optimizer_critic.zero_grad()
    
    old_values = experience.values
    returns = experience.returns
    
    with torch.cuda.amp.autocast(dtype=torch.float16):
        values = critic_model(seqs, attention_mask, num_actions)
        
        if torch.isnan(returns).any():
            returns = torch.zeros_like(returns)
            
        value_loss = compute_value_loss(values, old_values, returns, action_mask, clip_value_eps)
    
    value_loss.backward()
    torch.nn.utils.clip_grad_norm_(critic_model.parameters(), 1.0)
    optimizer_critic.step()
    
    if writer is not None and local_rank == 0:
        writer.add_scalar("policy_loss", policy_loss.item(), global_step)
        writer.add_scalar("value_loss", value_loss.item(), global_step)
        writer.add_scalar("reward_mean", experience.reward.mean().item(), global_step)
        writer.add_scalar("advantages_mean", advantages.mean().item(), global_step)
    
    # SwanLab 记录指标
    if swan_experiment and SWANLAB_AVAILABLE and local_rank == 0:
        swan_experiment.log_metrics({
            "policy_loss": policy_loss.item(),
            "value_loss": value_loss.item(),
            "reward_mean": experience.reward.mean().item(),
            "advantages_mean": advantages.mean().item()
        }, step=global_step)
    
    if local_rank == 0:
        print(f"Step {global_step}: Policy Loss = {policy_loss.item():.4f}, Value Loss = {value_loss.item():.4f}, Reward Mean = {experience.reward.mean().item():.4f}")
    return policy_loss.item(), value_loss.item(), experience.reward.mean().item()

def create_ds_config(world_size):
    """创建DeepSpeed配置"""
    ds_config = {
        "zero_optimization": {
            "stage": 3,
            "offload_optimizer": {
                "device": "cpu",
                "pin_memory": True
            },
            "offload_param": {
                "device": "cpu",
                "pin_memory": True
            },
            "allgather_partitions": True,
            "allgather_bucket_size": 5e8,
            "overlap_comm": True,
            "reduce_scatter": True,
            "contiguous_gradients": True
        },
        "fp16": {
            "enabled": True,
            "loss_scale": 0,
            "loss_scale_window": 1000,
            "initial_scale_power": 16,
            "hysteresis": 2,
            "min_loss_scale": 1
        },
        "gradient_accumulation_steps": 8,
        "gradient_clipping": 1.0,
        "steps_per_print": 10,
        "train_batch_size": None,
        "train_micro_batch_size_per_gpu": 2,
        "wall_clock_breakdown": False,
        "model_parallel_size": world_size,  # 模型并行大小等于卡数
        "pipeline_parallel": {
            "enabled": True,
            "chunks": 4,
            "pipeline_batch_size": 2
        }
    }
    return ds_config

def create_layer_split_model(model, world_size):
    """按层切分模型"""
    if world_size == 1:
        return model.to(device)
    
    # 假设模型有n层，平均分配到world_size张卡
    num_layers = model.config.num_hidden_layers
    layers_per_gpu = num_layers // world_size
    
    # 这里以QWen模型为例，假设模型层存储在model.model.layers中
    layers = model.model.layers
    split_layers = []
    for i in range(world_size):
        start = i * layers_per_gpu
        end = start + layers_per_gpu if i < world_size - 1 else num_layers
        split_layers.append(layers[start:end])
    
    # 创建流水线模块
    class QWenPipeline(PipelineModule):
        def __init__(self, layers):
            super().__init__()
            self.layers = nn.ModuleList(layers)
        
        def forward(self, input_ids, attention_mask):
            hidden_states = model.model.embedding(input_ids)
            hidden_states = model.model.layers[0].ln_1(hidden_states)
            for layer in self.layers:
                hidden_states = layer(hidden_states, attention_mask)
            hidden_states = model.model.layers[-1].ln_2(hidden_states)
            output = model.lm_head(hidden_states)
            return output
    
    # 为每张卡创建流水线模块
    pipe_models = []
    for i in range(world_size):
        pipe_model = QWenPipeline(split_layers[i])
        pipe_model.to(f"cuda:{i}")
        pipe_models.append(pipe_model)
    
    # 返回一个包装后的模型
    class DistributedQWen(nn.Module):
        def __init__(self, pipe_models):
            super().__init__()
            self.pipe_models = pipe_models
            self.embedding = model.model.embedding
            self.lm_head = model.lm_head
            self.layers = model.model.layers
        
        def forward(self, input_ids, attention_mask):
            hidden_states = self.embedding(input_ids)
            hidden_states = self.layers[0].ln_1(hidden_states)
            for i, pipe_model in enumerate(self.pipe_models):
                hidden_states = pipe_model(hidden_states, attention_mask)
            hidden_states = self.layers[-1].ln_2(hidden_states)
            output = self.lm_head(hidden_states)
            return output
    
    return DistributedQWen(pipe_models)

def train(actor_model, ref_model, critic_model, reward_model, tokenizer, dataset, output_dir="./results", 
          batch_size=4, micro_batch_size=1, max_epochs=3, max_new_tokens=128, n_samples_per_prompt=1, 
          kl_ctl=0.1, clip_reward_value=10.0, clip_eps=0.2, clip_value_eps=0.2, 
          learning_rate_actor=5e-6, learning_rate_critic=5e-6, log_dir="./logs"):
    os.makedirs(output_dir, exist_ok=True)
    
    # 创建DeepSpeed配置
    ds_config = create_ds_config(world_size)
    
    # 配置DeepSpeed for Actor模型
    dschf_config = HfDeepSpeedConfig(ds_config)  # 这必须在加载模型之前调用
    
    # 按层切分模型
    actor_model = create_layer_split_model(actor_model, world_size)
    
    # 初始化DeepSpeed优化器
    optimizer_actor = torch.optim.AdamW(actor_model.parameters(), lr=learning_rate_actor)
    optimizer_critic = torch.optim.AdamW(critic_model.parameters(), lr=learning_rate_critic)
    
    # 集成DeepSpeed
    actor_model, optimizer_actor, _, _ = deepspeed.initialize(
        model=actor_model,
        optimizer=optimizer_actor,
        config_params=ds_config
    )
    
    # 对于Critic和Reward模型，使用数据并行
    if world_size > 1:
        critic_model = nn.parallel.DistributedDataParallel(critic_model, device_ids=[local_rank])
        reward_model = nn.parallel.DistributedDataParallel(reward_model, device_ids=[local_rank])
    
    buffer = ExperienceBuffer(limit=1000)
    
    # 仅在主卡创建SummaryWriter
    writer = SummaryWriter(log_dir) if local_rank == 0 else None
    
    # SwanLab 初始化实验
    swan_experiment = None
    if SWANLAB_AVAILABLE and local_rank == 0:
        try:
            swan_experiment = Experiment(
                project_name="NL2SQL-PPO",
                experiment_name="SQL生成模型训练",
                tags=["NL2SQL", "PPO", "强化学习", f"{world_size}卡训练"]
            )
            # 记录超参数
            swan_experiment.log_params({
                "batch_size": batch_size,
                "micro_batch_size": micro_batch_size,
                "max_epochs": max_epochs,
                "max_new_tokens": max_new_tokens,
                "n_samples_per_prompt": n_samples_per_prompt,
                "kl_ctl": kl_ctl,
                "clip_reward_value": clip_reward_value,
                "clip_eps": clip_eps,
                "clip_value_eps": clip_value_eps,
                "learning_rate_actor": learning_rate_actor,
                "learning_rate_critic": learning_rate_critic,
                "gpu_count": world_size
            })
        except Exception as e:
            print(f"SwanLab初始化失败: {e}")
            swan_experiment = None
    
    global_step = 0
    
    # 创建数据加载器
    train_sampler = torch.utils.data.DistributedSampler(dataset, shuffle=True)
    dataloader = DataLoader(dataset, batch_size=batch_size, sampler=train_sampler)
    dataloader = RepeatingLoader(dataloader)  # DeepSpeed需要重复加载器
    
    for epoch in range(max_epochs):
        if local_rank == 0:
            print(f"Epoch {epoch+1}/{max_epochs}")
        
        for batch_idx in range(100):  # 每个epoch训练100步
            batch = next(dataloader)
            input_ids = batch["input_ids"].to(device)
            attention_mask = batch["attention_mask"].to(device)
            target_ids = batch["target_ids"].to(device)
            
            target_sqls = [tokenizer.decode(ids, skip_special_tokens=True) for ids in target_ids]
            prompts = [tokenizer.decode(input_ids[i][:attention_mask[i].sum()], skip_special_tokens=True) for i in range(len(input_ids))]
            
            samples_list = generate_samples(prompts, actor_model, tokenizer, max_length=512, max_new_tokens=max_new_tokens, n_samples_per_prompt=n_samples_per_prompt, batch_size=micro_batch_size)
            experiences = generate_experiences(samples_list, actor_model, ref_model, critic_model, reward_model, tokenizer, target_sqls, kl_ctl, clip_reward_value)
            buffer.append([vars(exp) for exp in experiences])
            
            if len(buffer) >= micro_batch_size:
                for _ in range(4):
                    batch_experience = buffer.get_batches(micro_batch_size)
                    merged_exp = {}
                    
                    for k in batch_experience[0].keys():
                        values = [exp[k] for exp in batch_experience]
                        
                        if isinstance(values[0], (int, float)):
                            merged_exp[k] = torch.tensor(values, device=device)
                        elif isinstance(values[0], torch.Tensor):
                            if values[0].dim() == 0:
                                merged_exp[k] = torch.stack(values, dim=0)
                            else:
                                merged_exp[k] = torch.cat(values, dim=0)
                        else:
                            merged_exp[k] = values
                    
                    merged_exp_obj = Experience(**merged_exp)
                    train_step(merged_exp_obj, actor_model, critic_model, optimizer_actor, optimizer_critic, 
                              clip_eps, clip_value_eps, writer, swan_experiment, global_step)
                    global_step += 1
            
            if (batch_idx + 1) % 10 == 0 and local_rank == 0:
                print(f"Batch {batch_idx+1} completed")
        
        # 仅在主卡保存检查点
        if local_rank == 0:
            print(f"Saving model at epoch {epoch+1}")
            model_save_path = os.path.join(output_dir, f"model_epoch_{epoch+1}")
            # 保存模型时需要获取原始模型
            unwrapped_model = actor_model.module if hasattr(actor_model, "module") else actor_model
            unwrapped_model.save_pretrained(model_save_path)
            tokenizer.save_pretrained(model_save_path)
            
            # SwanLab 记录 epoch 模型
            if swan_experiment and SWANLAB_AVAILABLE:
                swan_experiment.log_artifact(model_save_path, name=f"model_epoch_{epoch+1}")
    
    if local_rank == 0:
        print("Training completed! Saving final model...")
        model_save_path = os.path.join(output_dir, "final_model")
        unwrapped_model = actor_model.module if hasattr(actor_model, "module") else actor_model
        unwrapped_model.save_pretrained(model_save_path)
        tokenizer.save_pretrained(model_save_path)
        
        # SwanLab 记录最终模型
        if swan_experiment and SWANLAB_AVAILABLE:
            swan_experiment.log_artifact(model_save_path, name="final_model")
            swan_experiment.complete()
    
    if writer:
        writer.close()
    print("Training finished.")

def evaluate(model, tokenizer, dataset, num_samples=10, max_new_tokens=128):
    model.eval()
    indices = random.sample(range(len(dataset)), min(num_samples, len(dataset)))
    
    eval_results = []
    for i, idx in enumerate(indices):
        sample = dataset[idx]
        input_ids = sample["input_ids"].unsqueeze(0).to(device)
        attention_mask = sample["attention_mask"].unsqueeze(0).to(device)
        target_ids = sample["target_ids"]
        
        with torch.no_grad():
            outputs = model.generate(
                input_ids=input_ids,
                attention_mask=attention_mask,
                max_new_tokens=max_new_tokens,
                pad_token_id=tokenizer.pad_token_id,
                eos_token_id=tokenizer.eos_token_id,
            )
        
        generated_sql = tokenizer.decode(outputs[0][input_ids.shape[1]:], skip_special_tokens=True)
        target_sql = tokenizer.decode(target_ids, skip_special_tokens=True)
        prompt = tokenizer.decode(input_ids[0][:attention_mask[0].sum()], skip_special_tokens=True)
        
        # 简单评估生成SQL与目标SQL的相似度（示例：仅判断是否包含关键词）
        is_correct = "SELECT" in generated_sql and "FROM" in generated_sql
        eval_results.append({
            "prompt": prompt,
            "generated_sql": generated_sql,
            "target_sql": target_sql,
            "is_correct": is_correct
        })
        
        if local_rank == 0:
            print(f"\n示例 {i+1}:")
            print(f"输入提示:\n{prompt}")
            print(f"\n生成的SQL:\n{generated_sql}")
            print(f"\n参考SQL:\n{target_sql}")
            print(f"评估结果: {'正确' if is_correct else '错误'}")
            print("-" * 80)
    
    # SwanLab 记录评估结果
    if SWANLAB_AVAILABLE and swan_experiment and local_rank == 0:
        accuracy = sum(1 for r in eval_results if r["is_correct"]) / len(eval_results)
        swan_experiment.log_metrics({"evaluation_accuracy": accuracy})
        swan_experiment.log_table("evaluation_results", eval_results)
    
    return eval_results

def main():
    model_name = r"D:\mmodels\Qwen2___5-0___5B-Instruct"
    dataset_path = r"D:\mmodels\20230412_78K_SelfMade_NL2SQLpilot.json"
    output_dir = "./nl2sql_ppo_results"
    log_dir = "./nl2sql_ppo_logs"
    
    tokenizer = AutoTokenizer.from_pretrained(model_name, trust_remote_code=True)
    tokenizer.padding_side = "left"
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    
    # 加载模型
    actor_model = AutoModelForCausalLM.from_pretrained(
        model_name, 
        trust_remote_code=True,
        torch_dtype=torch.float16,
        device_map="auto"
    )
    actor_model.train()
    for param in actor_model.parameters():
        param.requires_grad_(True)
    
    ref_model = AutoModelForCausalLM.from_pretrained(
        model_name, 
        trust_remote_code=True,
        torch_dtype=torch.float16,
        device_map="auto"
    )
    
    critic_model = Critic(actor_model.base_model).to(device)
    reward_model = SQLRewardModel(actor_model.base_model).to(device)
    
    dataset = NL2SQLDataset(dataset_path, tokenizer)
    
    train(
        actor_model=actor_model,
        ref_model=ref_model,
        critic_model=critic_model,
        reward_model=reward_model,
        tokenizer=tokenizer,
        dataset=dataset,
        output_dir=output_dir,
        batch_size=4,
        micro_batch_size=1,
        max_epochs=3,
        max_new_tokens=128,
        n_samples_per_prompt=1,
        kl_ctl=0.1,
        clip_reward_value=10.0,
        clip_eps=0.2,
        clip_value_eps=0.2,
        learning_rate_actor=5e-6,
        learning_rate_critic=5e-6,
        log_dir=log_dir,
    )
    
    # 仅在主卡进行评估
    if local_rank == 0:
        evaluate(
            model=actor_model,
            tokenizer=tokenizer,
            dataset=dataset,
            num_samples=5,
            max_new_tokens=128,
        )

if __name__ == "__main__":
    main()