import torch
print(torch.cuda.is_available())
import torch
from transformers import AutoModel, AutoTokenizer

# 检查CUDA是否可用
print(f"CUDA可用: {torch.cuda.is_available()}")
print(f"CUDA设备数量: {torch.cuda.device_count()}")
print(f"当前CUDA设备: {torch.cuda.get_device_name(0)}")

# 测试Transformers
tokenizer = AutoTokenizer.from_pretrained("bert-base-chinese")
model = AutoModel.from_pretrained("bert-base-chinese")

inputs = tokenizer("你好，Transformers!", return_tensors="pt")
outputs = model(**inputs)

print("模型推理成功！")