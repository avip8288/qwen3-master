import time
import subprocess
import psutil
import re

def get_cpu_usage():
    """获取CPU使用率"""
    return psutil.cpu_percent(interval=1)

def get_memory_usage():
    """获取内存使用情况"""
    mem = psutil.virtual_memory()
    return mem.percent

def get_gpu_info():
    """获取NVIDIA GPU使用情况"""
    try:
        result = subprocess.run(['nvidia-smi', '--query-gpu=utilization.gpu,memory.used,memory.total', 
                               '--format=csv,noheader,nounits'], 
                              stdout=subprocess.PIPE, 
                              stderr=subprocess.PIPE,
                              text=True)
        if result.returncode == 0:
            gpu_info = result.stdout.strip().split(',')
            gpu_usage = gpu_info[0].strip()
            mem_used = gpu_info[1].strip()
            mem_total = gpu_info[2].strip()
            return {
                'gpu_usage': gpu_usage,
                'mem_used': mem_used,
                'mem_total': mem_total,
                'mem_percent': round((int(mem_used) / int(mem_total)) * 100, 1)
            }
        return None
    except FileNotFoundError:
        return None

def print_system_stats():
    """打印系统统计信息"""
    cpu_usage = get_cpu_usage()
    mem_usage = get_memory_usage()
    gpu_info = get_gpu_info()
    
    print("\n" + "="*50)
    print(f"CPU 使用率: {cpu_usage}%")
    print(f"内存使用率: {mem_usage}%")
    
    if gpu_info:
        print(f"GPU 使用率: {gpu_info['gpu_usage']}%")
        print(f"GPU 显存: {gpu_info['mem_used']}/{gpu_info['mem_total']} MB ({gpu_info['mem_percent']}%)")
    else:
        print("未检测到NVIDIA GPU或nvidia-smi不可用")
    print("="*50 + "\n")

def main():
    print("开始监控系统资源使用情况 (按Ctrl+C退出)...")
    try:
        while True:
            print_system_stats()
            time.sleep(2)
    except KeyboardInterrupt:
        print("\n监控已停止")

if __name__ == "__main__":
    main()