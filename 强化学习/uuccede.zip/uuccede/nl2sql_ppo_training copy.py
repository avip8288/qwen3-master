import json
import os
import random
import re
from typing import List, Dict, Any, Optional, Union, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from torch.utils.tensorboard import SummaryWriter
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    AutoModelForSequenceClassification,
    PreTrainedModel,
    PreTrainedTokenizer,
)
from dataclasses import dataclass

# 设置随机种子确保结果可复现
def set_seed(seed: int = 42):
    random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

set_seed()

# 定义设备
device = "cuda" if torch.cuda.is_available() else "cpu"

# 加载数据集
class NL2SQLDataset(Dataset):
    def __init__(self, data_path: str, tokenizer: PreTrainedTokenizer, max_length: int = 512):
        self.data = self._load_data(data_path)
        self.tokenizer = tokenizer
        self.max_length = max_length
        
    def _load_data(self, data_path: str) -> List[Dict[str, str]]:
        try:
            with open(data_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            return data
        except Exception as e:
            print(f"加载数据失败: {e}")
            return []
            
    def __len__(self) -> int:
        return len(self.data)
        
    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        item = self.data[idx]
        instruction = item["instruction"]
        input_text = item["input"]
        output = item["output"]
        
        # 构建完整的提示
        prompt = f"{instruction}\n{input_text}"
        
        # 编码输入和目标
        inputs = self.tokenizer(
            prompt,
            max_length=self.max_length,
            truncation=True,
            padding="max_length",
            return_tensors="pt",
        )
        
        targets = self.tokenizer(
            output,
            max_length=self.max_length,
            truncation=True,
            padding="max_length",
            return_tensors="pt",
        )
        
        return {
            "input_ids": inputs["input_ids"].squeeze(0),
            "attention_mask": inputs["attention_mask"].squeeze(0),
            "target_ids": targets["input_ids"].squeeze(0),
            "target_attention_mask": targets["attention_mask"].squeeze(0),
        }

# 价值（评论家）模型
class Critic(nn.Module):
    def __init__(self, base_model: PreTrainedModel):
        super().__init__()
        self.base_model = base_model
        self.value_head = nn.Linear(base_model.config.hidden_size, 1)
        
    def forward(self, input_ids: torch.Tensor, attention_mask: torch.Tensor, num_actions: int) -> torch.Tensor:
        hidden_state = self.base_model(input_ids, attention_mask=attention_mask).last_hidden_state
        value_output = self.value_head(hidden_state)
        values = value_output.squeeze(-1)[:, -num_actions:]
        return values

# SQL奖励模型
class SQLRewardModel(nn.Module):
    def __init__(self, base_model: PreTrainedModel):
        super().__init__()
        self.base_model = base_model
        self.reward_head = nn.Linear(base_model.config.hidden_size, 1)
        
    def forward(self, input_ids: torch.Tensor, attention_mask: torch.Tensor) -> torch.Tensor:
        outputs = self.base_model(input_ids, attention_mask=attention_mask)
        pooled_output = outputs.last_hidden_state[:, 0, :]
        reward = self.reward_head(pooled_output)
        return reward

# 计算策略损失
def compute_policy_loss(
    log_probs: torch.Tensor,
    old_log_probs: torch.Tensor,
    advantages: torch.Tensor,
    action_mask: Optional[torch.Tensor] = None,
    clip_eps: float = 0.2,
) -> torch.Tensor:
    ratio = torch.exp(log_probs - old_log_probs)
    surr1 = ratio * advantages
    surr2 = ratio.clamp(1.0 - clip_eps, 1.0 + clip_eps) * advantages
    loss = -torch.min(surr1, surr2)
    
    if action_mask is None:
        return loss.mean()
    
    return ((loss * action_mask).sum() / action_mask.sum())

# 计算价值损失
def compute_value_loss(
    values: torch.Tensor,
    old_values: torch.Tensor,
    returns: torch.Tensor,
    action_mask: Optional[torch.Tensor] = None,
    clip_eps: Optional[float] = None,
) -> torch.Tensor:
    if clip_eps is not None:
        values_clipped = old_values + (values - old_values).clamp(-clip_eps, clip_eps)
        surr1 = (values_clipped - returns) ** 2
        surr2 = (values - returns) ** 2
        loss = torch.max(surr1, surr2)
    else:
        loss = (values - returns) ** 2
        
    if action_mask is None:
        return loss.mean()
    
    return ((loss * action_mask).sum() / action_mask.sum())

# 经验缓冲区
class ExperienceBuffer:
    def __init__(self, limit: int = 1000):
        self.limit = limit
        self.buffer = []
        
    def append(self, experiences: List[Dict[str, Any]]) -> None:
        self.buffer.extend(experiences)
        if len(self.buffer) > self.limit:
            self.buffer = self.buffer[-self.limit:]
            
    def get_batches(self, batch_size: int) -> List[Dict[str, Any]]:
        if len(self.buffer) < batch_size:
            return self.buffer
        return random.sample(self.buffer, batch_size)
        
    def clear(self) -> None:
        self.buffer = []
        
    def __len__(self) -> int:
        return len(self.buffer)

# 样本数据类
@dataclass
class Samples:
    seqs: torch.Tensor
    attention_mask: Optional[torch.Tensor]
    action_mask: Optional[torch.Tensor]
    num_actions: Union[int, torch.Tensor]
    response_length: torch.Tensor
    total_length: torch.Tensor

# 经验数据类
@dataclass
class Experience:
    seqs: torch.Tensor
    action_log_probs: torch.Tensor
    values: torch.Tensor
    returns: torch.Tensor
    advantages: torch.Tensor
    attention_mask: torch.Tensor
    action_mask: torch.Tensor
    reward: torch.Tensor
    response_length: torch.Tensor
    total_length: torch.Tensor
    num_actions: Union[int, torch.Tensor]
    kl: Optional[torch.Tensor] = None

# 计算近似KL散度
def compute_approx_kl(
    log_probs: torch.Tensor,
    ref_log_probs: torch.Tensor,
    action_mask: Optional[torch.Tensor] = None,
) -> torch.Tensor:
    log_ratio = log_probs - ref_log_probs
    if action_mask is not None:
        log_ratio = log_ratio * action_mask
    return log_ratio

# 计算优势和回报
def get_advantages_and_returns(
    values: torch.Tensor,
    rewards: torch.Tensor,
    action_mask: torch.Tensor,
    gamma: float = 0.99,
    lambd: float = 0.95,
) -> Tuple[torch.Tensor, torch.Tensor]:
    lastgaelam = 0
    advantages_reversed = []
    response_length = rewards.size(1)
    
    if action_mask is not None:
        values = values * action_mask
        rewards = rewards * action_mask
    
    for t in reversed(range(response_length)):
        nextvalues = values[:, t + 1] if t < response_length - 1 else 0.0
        delta = rewards[:, t] + gamma * nextvalues - values[:, t]
        lastgaelam = delta + gamma * lambd * lastgaelam
        advantages_reversed.append(lastgaelam)
    
    advantages = torch.stack(advantages_reversed[::-1], dim=1)
    returns = advantages + values
    return advantages.detach(), returns.detach()

# 生成样本
def generate_samples(
    prompts: List[str],
    model: PreTrainedModel,
    tokenizer: PreTrainedTokenizer,
    max_length: int = 512,
    max_new_tokens: int = 128,
    n_samples_per_prompt: int = 1,
    batch_size: int = 4,
) -> List[Samples]:
    samples_list = []
    model.eval()
    
    all_prompts = [p for prompt in prompts for p in [prompt] * n_samples_per_prompt]
    
    for i in range(0, len(all_prompts), batch_size):
        batch_prompts = all_prompts[i : i + batch_size]
        
        inputs = tokenizer(
            batch_prompts,
            padding="max_length",
            max_length=max_length - max_new_tokens,
            truncation=True,
            return_tensors="pt",
        )
        
        input_ids = inputs["input_ids"].to(device)
        attention_mask = inputs["attention_mask"].to(device)
        
        with torch.no_grad():
            outputs = model.generate(
                input_ids=input_ids,
                attention_mask=attention_mask,
                max_new_tokens=max_new_tokens,
                pad_token_id=tokenizer.pad_token_id,
                eos_token_id=tokenizer.eos_token_id,
                do_sample=True,
                temperature=0.7,
                top_p=0.9,
            )
        
        # 计算action_mask (不包括输入部分)
        generated_tokens = outputs[:, input_ids.shape[1] :]
        action_mask = generated_tokens.ne(tokenizer.pad_token_id) & generated_tokens.ne(tokenizer.eos_token_id)
        
        samples = Samples(
            seqs=outputs,
            attention_mask=(outputs.ne(tokenizer.pad_token_id)).to(dtype=torch.long),
            action_mask=action_mask.to(dtype=torch.long),
            num_actions=action_mask.size(1),
            response_length=action_mask.sum(dim=1).float(),
            total_length=(outputs.ne(tokenizer.pad_token_id)).sum(dim=1).float(),
        )
        
        samples_list.append(samples)
    
    return samples_list

# 计算SQL奖励
def compute_sql_rewards(
    generated_sqls: List[str],
    target_sqls: List[str],
    reward_model: SQLRewardModel,
    reward_tokenizer: PreTrainedTokenizer,
    kl: torch.Tensor,
    action_mask: torch.Tensor,
    kl_ctl: float = 0.1,
    clip_reward_value: float = 10.0,
) -> torch.Tensor:
    # 准备输入到奖励模型的文本
    reward_inputs = []
    for gen_sql, target_sql in zip(generated_sqls, target_sqls):
        input_text = f"生成的SQL: {gen_sql}\n参考SQL: {target_sql}"
        reward_inputs.append(input_text)
    
    # 编码输入
    inputs = reward_tokenizer(
        reward_inputs,
        padding="max_length",
        max_length=512,
        truncation=True,
        return_tensors="pt",
    ).to(device)
    
    # 获取奖励分数
    with torch.no_grad():
        reward_scores = reward_model(**inputs).squeeze(-1)
    
    # 应用KL惩罚
    kl_penalty = -kl_ctl * kl
    
    # 合并奖励和KL惩罚
    rewards = kl_penalty
    
    # 将奖励分数添加到最后一个有效动作位置
    ends = action_mask.sum(1)
    for i in range(len(rewards)):
        if ends[i] > 0:
            rewards[i, ends[i] - 1] += reward_scores[i]
    
    # 裁剪奖励值
    rewards = torch.clamp(rewards, -clip_reward_value, clip_reward_value)
    
    return rewards

# 生成经验
def generate_experiences(
    samples_list: List[Samples],
    actor_model: PreTrainedModel,
    ref_model: PreTrainedModel,
    critic_model: Critic,
    reward_model: SQLRewardModel,
    tokenizer: PreTrainedTokenizer,
    target_sqls: List[str],
    kl_ctl: float = 0.1,
    clip_reward_value: float = 10.0,
) -> List[Experience]:
    experiences = []
    
    for samples in samples_list:
        seqs = samples.seqs
        attention_mask = samples.attention_mask
        action_mask = samples.action_mask
        num_actions = samples.num_actions
        
        with torch.no_grad():
            # 计算策略模型的对数概率
            actor_outputs = actor_model(seqs, attention_mask=attention_mask)
            logits = actor_outputs.logits
            log_probs = F.log_softmax(logits[:, :-1, :], dim=-1)
            next_token_log_probs = log_probs.gather(
                dim=-1, index=seqs[:, 1:].unsqueeze(-1)
            ).squeeze(-1)
            action_log_probs = next_token_log_probs[:, -num_actions:]
            
            # 计算参考模型的对数概率
            ref_outputs = ref_model(seqs, attention_mask=attention_mask)
            ref_logits = ref_outputs.logits
            ref_log_probs = F.log_softmax(ref_logits[:, :-1, :], dim=-1)
            ref_next_token_log_probs = ref_log_probs.gather(
                dim=-1, index=seqs[:, 1:].unsqueeze(-1)
            ).squeeze(-1)
            ref_action_log_probs = ref_next_token_log_probs[:, -num_actions:]
            
            # 计算KL散度
            kl = compute_approx_kl(
                action_log_probs, ref_action_log_probs, action_mask=action_mask
            )
            
            # 计算价值
            values = critic_model(seqs, attention_mask, num_actions)
            
            # 解码生成的SQL
            generated_sqls = []
            for seq in seqs:
                generated_part = seq[attention_mask.sum(dim=1) - num_actions :]
                generated_sql = tokenizer.decode(generated_part, skip_special_tokens=True)
                generated_sqls.append(generated_sql)
            
            # 计算奖励
            rewards = compute_sql_rewards(
                generated_sqls,
                target_sqls,
                reward_model,
                tokenizer,
                kl,
                action_mask,
                kl_ctl=kl_ctl,
                clip_reward_value=clip_reward_value,
            )
            
            # 计算优势和回报
            advantages, returns = get_advantages_and_returns(
                values, rewards, action_mask, gamma=0.99, lambd=0.95
            )
            
        # 创建经验对象
        experience = Experience(
            seqs=seqs,
            action_log_probs=action_log_probs,
            values=values,
            returns=returns,
            advantages=advantages,
            attention_mask=attention_mask,
            action_mask=action_mask,
            reward=rewards,
            response_length=samples.response_length,
            total_length=samples.total_length,
            num_actions=num_actions,
            kl=kl,
        )
        
        experiences.append(experience)
    
    return experiences

# 训练步骤
def train_step(
    experience: Experience,
    actor_model: PreTrainedModel,
    critic_model: Critic,
    optimizer_actor: torch.optim.Optimizer,
    optimizer_critic: torch.optim.Optimizer,
    clip_eps: float = 0.2,
    clip_value_eps: Optional[float] = 0.2,
    writer: Optional[SummaryWriter] = None,
    global_step: int = 0,
) -> None:
    # 训练actor
    actor_model.train()
    optimizer_actor.zero_grad()
    
    # 获取数据
    seqs = experience.seqs
    attention_mask = experience.attention_mask
    action_mask = experience.action_mask
    old_action_log_probs = experience.action_log_probs
    advantages = experience.advantages
    num_actions = experience.num_actions
    
    # 前向传播
    outputs = actor_model(seqs, attention_mask=attention_mask)
    logits = outputs.logits
    log_probs = F.log_softmax(logits[:, :-1, :], dim=-1)
    next_token_log_probs = log_probs.gather(
        dim=-1, index=seqs[:, 1:].unsqueeze(-1)
    ).squeeze(-1)
    action_log_probs = next_token_log_probs[:, -num_actions:]
    
    # 计算策略损失
    policy_loss = compute_policy_loss(
        action_log_probs, old_action_log_probs, advantages, action_mask, clip_eps
    )
    
    # 反向传播
    policy_loss.backward()
    
    # 梯度裁剪
    torch.nn.utils.clip_grad_norm_(actor_model.parameters(), 1.0)
    
    # 优化
    optimizer_actor.step()
    
    # 训练critic
    critic_model.train()
    optimizer_critic.zero_grad()
    
    # 获取数据
    old_values = experience.values
    returns = experience.returns
    
    # 前向传播
    values = critic_model(seqs, attention_mask, num_actions)
    
    # 计算价值损失
    value_loss = compute_value_loss(
        values, old_values, returns, action_mask, clip_value_eps
    )
    
    # 反向传播
    value_loss.backward()
    
    # 梯度裁剪
    torch.nn.utils.clip_grad_norm_(critic_model.parameters(), 1.0)
    
    # 优化
    optimizer_critic.step()
    
    # 记录日志
    if writer is not None:
        writer.add_scalar("policy_loss", policy_loss.item(), global_step)
        writer.add_scalar("value_loss", value_loss.item(), global_step)
        writer.add_scalar("reward_mean", experience.reward.mean().item(), global_step)
    
    print(
        f"Step {global_step}: Policy Loss = {policy_loss.item():.4f}, Value Loss = {value_loss.item():.4f}, Reward Mean = {experience.reward.mean().item():.4f}"
    )

# 主训练函数
def train(
    actor_model: PreTrainedModel,
    ref_model: PreTrainedModel,
    critic_model: Critic,
    reward_model: SQLRewardModel,
    tokenizer: PreTrainedTokenizer,
    dataset: NL2SQLDataset,
    output_dir: str = "./results",
    batch_size: int = 4,
    micro_batch_size: int = 1,
    max_epochs: int = 3,
    max_new_tokens: int = 128,
    n_samples_per_prompt: int = 1,
    kl_ctl: float = 0.1,
    clip_reward_value: float = 10.0,
    clip_eps: float = 0.2,
    clip_value_eps: float = 0.2,
    learning_rate_actor: float = 5e-6,
    learning_rate_critic: float = 5e-6,
    log_dir: str = "./logs",
):
    # 创建输出目录
    os.makedirs(output_dir, exist_ok=True)
    
    # 创建数据加载器
    dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True)
    
    # 初始化优化器
    optimizer_actor = torch.optim.AdamW(
        actor_model.parameters(), lr=learning_rate_actor
    )
    optimizer_critic = torch.optim.AdamW(
        critic_model.parameters(), lr=learning_rate_critic
    )
    
    # 初始化经验缓冲区
    buffer = ExperienceBuffer(limit=1000)
    
    # 初始化TensorBoard写入器
    writer = SummaryWriter(log_dir)
    
    # 全局步数
    global_step = 0
    
    # 训练循环
    for epoch in range(max_epochs):
        print(f"Epoch {epoch + 1}/{max_epochs}")
        
        for batch_idx, batch in enumerate(dataloader):
            # 准备数据
            input_ids = batch["input_ids"].to(device)
            attention_mask = batch["attention_mask"].to(device)
            target_ids = batch["target_ids"].to(device)
            
            # 解码目标SQL
            target_sqls = []
            for ids in target_ids:
                sql = tokenizer.decode(ids, skip_special_tokens=True)
                target_sqls.append(sql)
            
            # 解码输入提示
            prompts = []
            for i in range(len(input_ids)):
                prompt = tokenizer.decode(
                    input_ids[i][: attention_mask[i].sum()], skip_special_tokens=True
                )
                prompts.append(prompt)
            
            # 生成样本
            samples_list = generate_samples(
                prompts,
                actor_model,
                tokenizer,
                max_length=512,
                max_new_tokens=max_new_tokens,
                n_samples_per_prompt=n_samples_per_prompt,
                batch_size=micro_batch_size,
            )
            
            # 生成经验
            experiences = generate_experiences(
                samples_list,
                actor_model,
                ref_model,
                critic_model,
                reward_model,
                tokenizer,
                target_sqls,
                kl_ctl=kl_ctl,
                clip_reward_value=clip_reward_value,
            )
            
            # 添加到经验缓冲区
            buffer.append([vars(exp) for exp in experiences])
            
            # 从缓冲区采样进行训练
            if len(buffer) >= micro_batch_size:
                for _ in range(4):  # 多次训练同一个批次
                    batch_experience = buffer.get_batches(micro_batch_size)
                    
                    # 合并批次
                    merged_exp = {
                        k: torch.cat([torch.tensor(exp[k]) if isinstance(exp[k], int) else exp[k] for exp in batch_experience], dim=0)
                        for k in batch_experience[0].keys()
                    }
                    
                    # 转换回Experience对象
                    merged_exp_obj = Experience(**merged_exp)
                    
                    # 执行训练步骤
                    train_step(
                        merged_exp_obj,
                        actor_model,
                        critic_model,
                        optimizer_actor,
                        optimizer_critic,
                        clip_eps=clip_eps,
                        clip_value_eps=clip_value_eps,
                        writer=writer,
                        global_step=global_step,
                    )
                    
                    global_step += 1
            
            # 每100个批次保存一次模型
            if (batch_idx + 1) % 100 == 0:
                print(f"Saving model at batch {batch_idx + 1}")
                model_save_path = os.path.join(output_dir, f"model_step_{global_step}")
                actor_model.save_pretrained(model_save_path)
                tokenizer.save_pretrained(model_save_path)
        
        # 每个epoch结束后保存模型
        print(f"Saving model at epoch {epoch + 1}")
        model_save_path = os.path.join(output_dir, f"model_epoch_{epoch + 1}")
        actor_model.save_pretrained(model_save_path)
        tokenizer.save_pretrained(model_save_path)
    
    # 训练结束后保存最终模型
    print("Training completed! Saving final model...")
    model_save_path = os.path.join(output_dir, "final_model")
    actor_model.save_pretrained(model_save_path)
    tokenizer.save_pretrained(model_save_path)
    
    # 关闭TensorBoard写入器
    writer.close()

# 评估模型
def evaluate(
    model: PreTrainedModel,
    tokenizer: PreTrainedTokenizer,
    dataset: NL2SQLDataset,
    num_samples: int = 10,
    max_new_tokens: int = 128,
):
    model.eval()
    
    # 随机选择样本
    indices = random.sample(range(len(dataset)), min(num_samples, len(dataset)))
    
    for i, idx in enumerate(indices):
        sample = dataset[idx]
        input_ids = sample["input_ids"].unsqueeze(0).to(device)
        attention_mask = sample["attention_mask"].unsqueeze(0).to(device)
        target_ids = sample["target_ids"]
        
        # 生成SQL
        with torch.no_grad():
            outputs = model.generate(
                input_ids=input_ids,
                attention_mask=attention_mask,
                max_new_tokens=max_new_tokens,
                pad_token_id=tokenizer.pad_token_id,
                eos_token_id=tokenizer.eos_token_id,
            )
        
        # 解码生成的SQL和目标SQL
        generated_sql = tokenizer.decode(
            outputs[0][input_ids.shape[1] :], skip_special_tokens=True
        )
        target_sql = tokenizer.decode(target_ids, skip_special_tokens=True)
        
        # 解码输入提示
        prompt = tokenizer.decode(
            input_ids[0][: attention_mask[0].sum()], skip_special_tokens=True
        )
        
        # 打印结果
        print(f"\n示例 {i + 1}:")
        print(f"输入提示:\n{prompt}")
        print(f"\n生成的SQL:\n{generated_sql}")
        print(f"\n参考SQL:\n{target_sql}")
        print("-" * 80)

# 主函数
def main():
    # 模型和数据路径
    model_name = r"D:\mmodels\Qwen2___5-0___5B-Instruct"  # 可以替换为其他适合的模型
    dataset_path = r"D:\mmodels\20230412_78K_SelfMade_NL2SQLpilot.json"
    output_dir = "./nl2sql_ppo_results"
    log_dir = "./nl2sql_ppo_logs"
    
    # 加载tokenizer
    print("加载tokenizer...")
    tokenizer = AutoTokenizer.from_pretrained(model_name, trust_remote_code=True)
    tokenizer.padding_side = "left"
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    
    # 加载模型
    print("加载模型...")
    actor_model = AutoModelForCausalLM.from_pretrained(
        model_name, 
        trust_remote_code=True,
        torch_dtype=torch.float16,
        device_map="auto"
    )
    
    # 加载参考模型（与actor模型相同，但不更新）
    ref_model = AutoModelForCausalLM.from_pretrained(
        model_name, 
        trust_remote_code=True,
        torch_dtype=torch.float16,
        device_map="auto"
    )
    
    # 初始化评论家模型
    critic_model = Critic(actor_model.base_model).to(device)
    
    # 初始化奖励模型
    reward_model = SQLRewardModel(actor_model.base_model).to(device)
    
    # 加载数据集
    print("加载数据集...")
    dataset = NL2SQLDataset(dataset_path, tokenizer)
    
    # 训练模型
    print("开始训练...")
    train(
        actor_model=actor_model,
        ref_model=ref_model,
        critic_model=critic_model,
        reward_model=reward_model,
        tokenizer=tokenizer,
        dataset=dataset,
        output_dir=output_dir,
        batch_size=4,
        micro_batch_size=1,
        max_epochs=3,
        max_new_tokens=128,
        n_samples_per_prompt=1,
        kl_ctl=0.1,
        clip_reward_value=10.0,
        clip_eps=0.2,
        clip_value_eps=0.2,
        learning_rate_actor=5e-6,
        learning_rate_critic=5e-6,
        log_dir=log_dir,
    )
    
    # 评估模型
    print("评估模型...")
    evaluate(
        model=actor_model,
        tokenizer=tokenizer,
        dataset=dataset,
        num_samples=5,
        max_new_tokens=128,
    )

if __name__ == "__main__":
    main()    