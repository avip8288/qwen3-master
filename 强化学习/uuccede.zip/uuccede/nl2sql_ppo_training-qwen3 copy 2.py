import json
import os
import random
import re
from typing import List, Dict, Any, Optional, Union, Tuple
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from torch.utils.tensorboard import SummaryWriter
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    PreTrainedModel,
    PreTrainedTokenizer,
)
from dataclasses import dataclass

def set_seed(seed: int = 42):
    random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

set_seed()

device = "cuda" if torch.cuda.is_available() else "cpu"

class NL2SQLDataset(Dataset):
    def __init__(self, data_path: str, tokenizer: PreTrainedTokenizer, max_length: int = 512):
        self.data = self._load_data(data_path)
        self.tokenizer = tokenizer
        self.max_length = max_length
        
    def _load_data(self, data_path: str) -> List[Dict[str, str]]:
        try:
            with open(data_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            return data
        except Exception as e:
            print(f"加载数据失败: {e}")
            return []
            
    def __len__(self) -> int:
        return len(self.data)
        
    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        item = self.data[idx]
        instruction = item["instruction"]
        input_text = item["input"]
        output = item["output"]
        prompt = f"{instruction}\n{input_text}"
        
        inputs = self.tokenizer(
            prompt,
            max_length=self.max_length,
            truncation=True,
            padding="max_length",
            return_tensors="pt",
        )
        
        targets = self.tokenizer(
            output,
            max_length=self.max_length,
            truncation=True,
            padding="max_length",
            return_tensors="pt",
        )
        
        return {
            "input_ids": inputs["input_ids"].squeeze(0),
            "attention_mask": inputs["attention_mask"].squeeze(0),
            "target_ids": targets["input_ids"].squeeze(0),
            "target_attention_mask": targets["attention_mask"].squeeze(0),
        }

class Critic(nn.Module):
    def __init__(self, base_model: PreTrainedModel):
        super().__init__()
        self.base_model = base_model
        self.value_head = nn.Linear(base_model.config.hidden_size, 1)
        self.to(base_model.dtype)
        
    def forward(self, input_ids: torch.Tensor, attention_mask: torch.Tensor, num_actions: int) -> torch.Tensor:
        # 添加数值检查
        if torch.isnan(input_ids).any() or torch.isinf(input_ids).any():
            print("警告: Critic输入包含NaN或inf")
            input_ids = torch.nan_to_num(input_ids)
            
        hidden_state = self.base_model(input_ids, attention_mask=attention_mask).last_hidden_state
        value_output = self.value_head(hidden_state)
        values = value_output.squeeze(-1)[:, -num_actions:]
        
        # 检查输出是否有效
        if torch.isnan(values).any() or torch.isinf(values).any():
            print("警告: Critic输出包含NaN或inf")
            values = torch.nan_to_num(values)
            
        return values

class SQLRewardModel(nn.Module):
    def __init__(self, base_model: PreTrainedModel):
        super().__init__()
        self.base_model = base_model
        self.reward_head = nn.Linear(base_model.config.hidden_size, 1)
        self.to(base_model.dtype)
        
    def forward(self, input_ids: torch.Tensor, attention_mask: torch.Tensor) -> torch.Tensor:
        # 添加数值检查
        if torch.isnan(input_ids).any() or torch.isinf(input_ids).any():
            print("警告: Reward模型输入包含NaN或inf")
            input_ids = torch.nan_to_num(input_ids)
            
        outputs = self.base_model(input_ids, attention_mask=attention_mask)
        pooled_output = outputs.last_hidden_state[:, 0, :]
        reward = self.reward_head(pooled_output)
        
        # 检查输出是否有效
        if torch.isnan(reward).any() or torch.isinf(reward).any():
            print("警告: Reward模型输出包含NaN或inf")
            reward = torch.nan_to_num(reward)
            
        return reward

def compute_policy_loss(log_probs, old_log_probs, advantages, action_mask=None, clip_eps=0.2):
    # 检查输入是否有效
    if torch.isnan(log_probs).any() or torch.isinf(log_probs).any():
        print("警告: compute_policy_loss的log_probs包含NaN或inf")
        log_probs = torch.nan_to_num(log_probs)
        
    if torch.isnan(old_log_probs).any() or torch.isinf(old_log_probs).any():
        print("警告: compute_policy_loss的old_log_probs包含NaN或inf")
        old_log_probs = torch.nan_to_num(old_log_probs)
        
    if torch.isnan(advantages).any() or torch.isinf(advantages).any():
        print("警告: compute_policy_loss的advantages包含NaN或inf")
        advantages = torch.nan_to_num(advantages)
    
    ratio = torch.exp(log_probs - old_log_probs)
    
    # 限制比率范围，防止梯度爆炸
    ratio = torch.clamp(ratio, 0.0, 10.0)
    
    surr1 = ratio * advantages
    surr2 = ratio.clamp(1.0 - clip_eps, 1.0 + clip_eps) * advantages
    loss = -torch.min(surr1, surr2)
    
    if action_mask is None:
        return loss.mean()
    return ((loss * action_mask).sum() / action_mask.sum())

def compute_value_loss(values, old_values, returns, action_mask=None, clip_eps=None):
    # 检查输入是否有效
    if torch.isnan(values).any() or torch.isinf(values).any():
        print("警告: compute_value_loss的values包含NaN或inf")
        values = torch.nan_to_num(values)
        
    if torch.isnan(old_values).any() or torch.isinf(old_values).any():
        print("警告: compute_value_loss的old_values包含NaN或inf")
        old_values = torch.nan_to_num(old_values)
        
    if torch.isnan(returns).any() or torch.isinf(returns).any():
        print("警告: compute_value_loss的returns包含NaN或inf")
        returns = torch.nan_to_num(returns)
    
    if clip_eps is not None:
        values_clipped = old_values + (values - old_values).clamp(-clip_eps, clip_eps)
        surr1 = (values_clipped - returns) ** 2
        surr2 = (values - returns) ** 2
        loss = torch.max(surr1, surr2)
    else:
        loss = (values - returns) ** 2
        
    if action_mask is None:
        return loss.mean()
    return ((loss * action_mask).sum() / action_mask.sum())

class ExperienceBuffer:
    def __init__(self, limit: int = 1000):
        self.limit = limit
        self.buffer = []
        
    def append(self, experiences: List[Dict[str, Any]]) -> None:
        # 过滤掉包含NaN或inf的经验
        valid_experiences = []
        for exp in experiences:
            valid = True
            for k, v in exp.items():
                if isinstance(v, torch.Tensor) and (torch.isnan(v).any() or torch.isinf(v).any()):
                    print(f"警告: 过滤掉包含无效值的经验，键: {k}")
                    valid = False
                    break
            if valid:
                valid_experiences.append(exp)
        
        self.buffer.extend(valid_experiences)
        if len(self.buffer) > self.limit:
            self.buffer = self.buffer[-self.limit:]
            
    def get_batches(self, batch_size: int) -> List[Dict[str, Any]]:
        if len(self.buffer) < batch_size:
            return self.buffer
        return random.sample(self.buffer, batch_size)
        
    def clear(self) -> None:
        self.buffer = []
        
    def __len__(self) -> int:
        return len(self.buffer)

@dataclass
class Samples:
    seqs: torch.Tensor
    attention_mask: Optional[torch.Tensor]
    action_mask: Optional[torch.Tensor]
    num_actions: Union[int, torch.Tensor]
    response_length: torch.Tensor
    total_length: torch.Tensor

@dataclass
class Experience:
    seqs: torch.Tensor
    action_log_probs: torch.Tensor
    values: torch.Tensor
    returns: torch.Tensor
    advantages: torch.Tensor
    attention_mask: torch.Tensor
    action_mask: torch.Tensor
    reward: torch.Tensor
    response_length: torch.Tensor
    total_length: torch.Tensor
    num_actions: Union[int, torch.Tensor]
    kl: Optional[torch.Tensor] = None

def compute_approx_kl(log_probs, ref_log_probs, action_mask=None):
    # 检查输入是否有效
    if torch.isnan(log_probs).any() or torch.isinf(log_probs).any():
        print("警告: compute_approx_kl的log_probs包含NaN或inf")
        log_probs = torch.nan_to_num(log_probs)
        
    if torch.isnan(ref_log_probs).any() or torch.isinf(ref_log_probs).any():
        print("警告: compute_approx_kl的ref_log_probs包含NaN或inf")
        ref_log_probs = torch.nan_to_num(ref_log_probs)
    
    log_ratio = log_probs - ref_log_probs
    if action_mask is not None:
        log_ratio = log_ratio * action_mask
    return log_ratio

def get_advantages_and_returns(values, rewards, action_mask, gamma=0.99, lambd=0.95):
    # 检查输入是否有效
    if torch.isnan(values).any() or torch.isinf(values).any():
        print("警告: get_advantages_and_returns的values包含NaN或inf")
        values = torch.nan_to_num(values)
        
    if torch.isnan(rewards).any() or torch.isinf(rewards).any():
        print("警告: get_advantages_and_returns的rewards包含NaN或inf")
        rewards = torch.nan_to_num(rewards)
    
    lastgaelam = 0
    advantages_reversed = []
    response_length = rewards.size(1)
    
    if action_mask is not None:
        values = values * action_mask
        rewards = rewards * action_mask
    
    for t in reversed(range(response_length)):
        nextvalues = values[:, t + 1] if t < response_length - 1 else 0.0
        delta = rewards[:, t] + gamma * nextvalues - values[:, t]
        lastgaelam = delta + gamma * lambd * lastgaelam
        advantages_reversed.append(lastgaelam)
    
    advantages = torch.stack(advantages_reversed[::-1], dim=1)
    returns = advantages + values
    
    # 再次检查输出是否有效
    if torch.isnan(advantages).any() or torch.isinf(advantages).any():
        print("警告: advantages包含NaN或inf，将其替换为0")
        advantages = torch.nan_to_num(advantages)
        
    if torch.isnan(returns).any() or torch.isinf(returns).any():
        print("警告: returns包含NaN或inf，将其替换为0")
        returns = torch.nan_to_num(returns)
        
    # 限制优势值和返回值的范围
    advantages = torch.clamp(advantages, -5.0, 5.0)
    returns = torch.clamp(returns, -5.0, 5.0)
        
    return advantages.detach(), returns.detach()

def generate_samples(prompts, model, tokenizer, max_length=512, max_new_tokens=128, n_samples_per_prompt=1, batch_size=4):
    samples_list = []
    model.eval()
    
    # 检查模型参数是否有效
    for name, param in model.named_parameters():
        if torch.isnan(param).any() or torch.isinf(param).any():
            print(f"警告: 模型参数 {name} 包含NaN或inf，跳过此批次生成")
            return []
    
    all_prompts = [p for prompt in prompts for p in [prompt] * n_samples_per_prompt]
    
    for i in range(0, len(all_prompts), batch_size):
        batch_prompts = all_prompts[i : i + batch_size]
        
        inputs = tokenizer(
            batch_prompts,
            padding="max_length",
            max_length=max_length - max_new_tokens,
            truncation=True,
            return_tensors="pt",
        )
        
        input_ids = inputs["input_ids"].to(device)
        attention_mask = inputs["attention_mask"].to(device)
        
        # 检查输入是否有效
        if torch.isnan(input_ids).any() or torch.isinf(input_ids).any():
            print("警告: 输入ID包含NaN或inf，跳过此批次生成")
            continue
            
        try:
            with torch.no_grad():
                # 使用较低的temperature来提高数值稳定性
                outputs = model.generate(
                    input_ids=input_ids,
                    attention_mask=attention_mask,
                    max_new_tokens=max_new_tokens,
                    pad_token_id=tokenizer.pad_token_id,
                    eos_token_id=tokenizer.eos_token_id,
                    do_sample=True,
                    temperature=0.5,  # 降低temperature
                    top_p=0.9,
                )
        except RuntimeError as e:
            print(f"生成过程中出错: {e}")
            print("跳过此批次生成")
            continue
        
        # 检查生成结果是否有效
        if torch.isnan(outputs).any() or torch.isinf(outputs).any():
            print("警告: 生成的输出包含NaN或inf，跳过此批次")
            continue
            
        generated_tokens = outputs[:, input_ids.shape[1]:]
        action_mask = generated_tokens.ne(tokenizer.pad_token_id) & generated_tokens.ne(tokenizer.eos_token_id)
        
        samples = Samples(
            seqs=outputs,
            attention_mask=(outputs.ne(tokenizer.pad_token_id)).to(dtype=torch.long),
            action_mask=action_mask.to(dtype=torch.long),
            num_actions=action_mask.size(1),
            response_length=action_mask.sum(dim=1).float(),
            total_length=(outputs.ne(tokenizer.pad_token_id)).sum(dim=1).float(),
        )
        
        samples_list.append(samples)
    
    return samples_list

def compute_sql_rewards(generated_sqls, target_sqls, reward_model, reward_tokenizer, kl, action_mask, kl_ctl=0.1, clip_reward_value=10.0):
    reward_inputs = [f"生成的SQL: {gen_sql}\n参考SQL: {target_sql}" for gen_sql, target_sql in zip(generated_sqls, target_sqls)]
    
    inputs = reward_tokenizer(
        reward_inputs,
        padding="max_length",
        max_length=512,
        truncation=True,
        return_tensors="pt",
    ).to(device)
    
    with torch.no_grad():
        reward_scores = reward_model(**inputs).squeeze(-1)
        
        # 检查奖励分数是否有效
        if torch.isnan(reward_scores).any() or torch.isinf(reward_scores).any():
            print(f"警告: 奖励分数包含NaN或inf，将其替换为0")
            reward_scores = torch.nan_to_num(reward_scores)
    
    kl_penalty = -kl_ctl * kl
    
    # 检查KL惩罚是否有效
    if torch.isnan(kl_penalty).any() or torch.isinf(kl_penalty).any():
        print(f"警告: KL惩罚包含NaN或inf，将其替换为0")
        kl_penalty = torch.nan_to_num(kl_penalty)
    
    rewards = kl_penalty
    
    ends = action_mask.sum(1)
    for i in range(len(rewards)):
        if ends[i] > 0:
            rewards[i, ends[i]-1] += reward_scores[i]
    
    # 限制奖励值范围
    rewards = torch.clamp(rewards, -clip_reward_value, clip_reward_value)
    
    # 再次检查奖励是否有效
    if torch.isnan(rewards).any() or torch.isinf(rewards).any():
        print(f"警告: 最终奖励包含NaN或inf，将其替换为0")
        rewards = torch.nan_to_num(rewards)
        
    return rewards

def generate_experiences(samples_list, actor_model, ref_model, critic_model, reward_model, tokenizer, target_sqls, kl_ctl=0.1, clip_reward_value=10.0):
    experiences = []
    
    for samples in samples_list:
        seqs = samples.seqs
        attention_mask = samples.attention_mask
        action_mask = samples.action_mask
        num_actions = samples.num_actions
        
        # 检查输入是否有效
        if torch.isnan(seqs).any() or torch.isinf(seqs).any():
            print("警告: 序列包含NaN或inf，跳过此样本")
            continue
            
        with torch.no_grad():
            # 检查模型参数是否有效
            for name, param in actor_model.named_parameters():
                if torch.isnan(param).any() or torch.isinf(param).any():
                    print(f"警告: Actor模型参数 {name} 包含NaN或inf，跳过此样本")
                    continue
            
            actor_outputs = actor_model(seqs, attention_mask=attention_mask)
            logits = actor_outputs.logits
            
            # 检查模型输出是否有效
            if torch.isnan(logits).any() or torch.isinf(logits).any():
                print(f"警告: Actor模型输出包含NaN或inf，跳过此样本")
                continue
            
            # 转换为float32以提高数值稳定性
            logits = logits.float()
            log_probs = F.log_softmax(logits[:, :-1, :], dim=-1)
            
            # 检查log_probs是否有效
            if torch.isnan(log_probs).any() or torch.isinf(log_probs).any():
                print(f"警告: log_probs包含NaN或inf，跳过此样本")
                continue
                
            next_token_log_probs = log_probs.gather(dim=-1, index=seqs[:, 1:].unsqueeze(-1)).squeeze(-1)
            action_log_probs = next_token_log_probs[:, -num_actions:]
            
            # 检查参考模型参数是否有效
            for name, param in ref_model.named_parameters():
                if torch.isnan(param).any() or torch.isinf(param).any():
                    print(f"警告: 参考模型参数 {name} 包含NaN或inf，跳过此样本")
                    continue
            
            ref_outputs = ref_model(seqs, attention_mask=attention_mask)
            ref_logits = ref_outputs.logits
            
            # 检查参考模型输出是否有效
            if torch.isnan(ref_logits).any() or torch.isinf(ref_logits).any():
                print(f"警告: 参考模型输出包含NaN或inf，跳过此样本")
                continue
                
            # 转换为float32以提高数值稳定性
            ref_logits = ref_logits.float()
            ref_log_probs = F.log_softmax(ref_logits[:, :-1, :], dim=-1)
            
            # 检查ref_log_probs是否有效
            if torch.isnan(ref_log_probs).any() or torch.isinf(ref_log_probs).any():
                print(f"警告: ref_log_probs包含NaN或inf，跳过此样本")
                continue
                
            ref_next_token_log_probs = ref_log_probs.gather(dim=-1, index=seqs[:, 1:].unsqueeze(-1)).squeeze(-1)
            ref_action_log_probs = ref_next_token_log_probs[:, -num_actions:]
            
            kl = compute_approx_kl(action_log_probs, ref_action_log_probs, action_mask=action_mask)
            values = critic_model(seqs, attention_mask, num_actions)
            
            # 检查Critic模型输出是否有效
            if torch.isnan(values).any() or torch.isinf(values).any():
                print(f"警告: Critic模型输出包含NaN或inf，跳过此样本")
                continue
                
            generated_sqls = [tokenizer.decode(seq[attention_mask.sum(dim=1)-num_actions:], skip_special_tokens=True) for seq in seqs]
            rewards = compute_sql_rewards(generated_sqls, target_sqls, reward_model, tokenizer, kl, action_mask, kl_ctl, clip_reward_value)
            
            advantages, returns = get_advantages_and_returns(values, rewards, action_mask)
            
        experience = Experience(
            seqs=seqs,
            action_log_probs=action_log_probs,
            values=values,
            returns=returns,
            advantages=advantages,
            attention_mask=attention_mask,
            action_mask=action_mask,
            reward=rewards,
            response_length=samples.response_length,
            total_length=samples.total_length,
            num_actions=num_actions,
            kl=kl,
        )
        
        experiences.append(experience)
    
    return experiences

def train_step(experience, actor_model, critic_model, optimizer_actor, optimizer_critic, clip_eps=0.2, clip_value_eps=0.2, writer=None, global_step=0):
    # 初始化检查
    if torch.isnan(experience.seqs).any() or torch.isinf(experience.seqs).any():
        print("警告: 输入序列包含NaN或inf，跳过此批次")
        return None, None, None
    
    if torch.isnan(experience.advantages).any() or torch.isinf(experience.advantages).any():
        print("警告: 优势值包含NaN或inf，跳过此批次")
        return None, None, None
    
    # 训练前检查模型参数
    for name, param in actor_model.named_parameters():
        if torch.isnan(param).any() or torch.isinf(param).any():
            print(f"警告: 演员模型参数 {name} 包含NaN或inf，跳过此批次")
            return None, None, None
    
    for name, param in critic_model.named_parameters():
        if torch.isnan(param).any() or torch.isinf(param).any():
            print(f"警告: Critic模型参数 {name} 包含NaN或inf，跳过此批次")
            return None, None, None
    
    actor_model.train()
    critic_model.train()
    
    # 检查输入数据
    print(f"输入序列形状: {experience.seqs.shape}, 设备: {experience.seqs.device}")
    print(f"优势值形状: {experience.advantages.shape}, 最小值: {experience.advantages.min()}, 最大值: {experience.advantages.max()}")
    
    # 在Critic前检查模型状态
    print(f"Critic模型参数设备: {next(critic_model.parameters()).device}")
    
    # Actor训练部分
    optimizer_actor.zero_grad()
    
    seqs = experience.seqs
    attention_mask = experience.attention_mask
    action_mask = experience.action_mask
    old_action_log_probs = experience.action_log_probs
    advantages = experience.advantages
    num_actions = experience.num_actions
    
    # 添加梯度裁剪和数值稳定性检查
    try:
        with torch.amp.autocast(device_type='cuda', dtype=torch.float16):
            outputs = actor_model(seqs, attention_mask=attention_mask)
            logits = outputs.logits
            
            # 数值稳定性处理
            logits = logits.float()  # 转换为float32避免数值问题
            log_probs = F.log_softmax(logits[:, :-1, :], dim=-1)
            
            # 检查log_probs是否有效
            if torch.isnan(log_probs).any() or torch.isinf(log_probs).any():
                print("警告: Actor训练中log_probs包含NaN或inf，跳过此批次")
                optimizer_actor.zero_grad()
                return None, None, None
                
            next_token_log_probs = log_probs.gather(dim=-1, index=seqs[:, 1:].unsqueeze(-1)).squeeze(-1)
            action_log_probs = next_token_log_probs[:, -num_actions:]
            
            # 优势值归一化
            advantages_mean = advantages.mean()
            advantages_std = advantages.std() + 1e-8
            advantages = (advantages - advantages_mean) / advantages_std
            
            # 限制优势值范围，防止梯度爆炸
            advantages = torch.clamp(advantages, -3.0, 3.0)
            
            policy_loss = compute_policy_loss(action_log_probs, old_action_log_probs, advantages, action_mask, clip_eps)
        
        # 检查损失值
        if torch.isnan(policy_loss).any() or torch.isinf(policy_loss).any():
            print("警告: Policy loss包含NaN或inf，跳过此批次")
            optimizer_actor.zero_grad()
            return None, None, None
            
        policy_loss.backward()
        
        # 梯度裁剪和检查
        grad_norm = torch.nn.utils.clip_grad_norm_(actor_model.parameters(), 0.5)  # 减小梯度裁剪阈值
        if torch.isnan(grad_norm) or torch.isinf(grad_norm):
            print(f"警告: Actor梯度范数包含NaN或inf，跳过此更新")
            optimizer_actor.zero_grad()
            return None, None, None
            
        optimizer_actor.step()
        
        # 释放不再需要的中间变量
        del outputs, logits, log_probs, next_token_log_probs, action_log_probs, policy_loss
        torch.cuda.empty_cache()
        
    except Exception as e:
        print(f"Actor训练出错: {str(e)}")
        # 恢复模型到之前的状态
        optimizer_actor.zero_grad()
        return None, None, None
    
    # Critic训练部分
    optimizer_critic.zero_grad()
    
    old_values = experience.values
    returns = experience.returns
    
    try:
        with torch.amp.autocast(device_type='cuda', dtype=torch.float16):
            values = critic_model(seqs, attention_mask, num_actions)
            
            # 确保返回值是有效的
            if torch.isnan(returns).any() or torch.isinf(returns).any():
                print(f"警告: 返回值包含NaN或inf，将其替换为0")
                returns = torch.nan_to_num(returns)
                
            # 限制返回值范围
            returns = torch.clamp(returns, -3.0, 3.0)
                
            value_loss = compute_value_loss(values, old_values, returns, action_mask, clip_value_eps)
        
        # 检查损失值
        if torch.isnan(value_loss).any() or torch.isinf(value_loss).any():
            print(f"警告: Value loss包含NaN或inf，跳过此更新")
            optimizer_critic.zero_grad()
            return None, None, None
            
        value_loss.backward()
        
        # 梯度裁剪和检查
        grad_norm = torch.nn.utils.clip_grad_norm_(critic_model.parameters(), 0.5)  # 减小梯度裁剪阈值
        if torch.isnan(grad_norm) or torch.isinf(grad_norm):
            print(f"警告: Critic梯度范数包含NaN或inf，跳过此更新")
            optimizer_critic.zero_grad()
            return None, None, None
            
        optimizer_critic.step()
        
        # 释放不再需要的中间变量
        del values, value_loss, returns, old_values
        torch.cuda.empty_cache()
        
    except Exception as e:
        print(f"Critic训练出错: {str(e)}")
        optimizer_critic.zero_grad()
        return None, None, None
    
    # 记录训练指标
    if writer is not None:
        writer.add_scalar("policy_loss", policy_loss.item(), global_step)
        writer.add_scalar("value_loss", value_loss.item(), global_step)
        writer.add_scalar("reward_mean", experience.reward.mean().item(), global_step)
        writer.add_scalar("advantages_mean", advantages.mean().item(), global_step)
        writer.add_scalar("actor_grad_norm", grad_norm.item(), global_step)
    
    print(f"Step {global_step}: Policy Loss = {policy_loss.item():.4f}, Value Loss = {value_loss.item():.4f}, Reward Mean = {experience.reward.mean().item():.4f}")
    return policy_loss.item(), value_loss.item(), experience.reward.mean().item()

def train(actor_model, ref_model, critic_model, reward_model, tokenizer, dataset, output_dir="./results", batch_size=4, micro_batch_size=1, max_epochs=3, max_new_tokens=128, n_samples_per_prompt=1, kl_ctl=0.1, clip_reward_value=10.0, clip_eps=0.2, clip_value_eps=0.2, learning_rate_actor=5e-6, learning_rate_critic=5e-6, log_dir="./logs"):
    os.makedirs(output_dir, exist_ok=True)
    
    # 减小batch_size以降低内存压力
    dataloader = DataLoader(dataset, batch_size=1, shuffle=True)
    
    # 降低学习率
    optimizer_actor = torch.optim.AdamW(actor_model.parameters(), lr=5e-7)  # 进一步降低学习率
    optimizer_critic = torch.optim.AdamW(critic_model.parameters(), lr=5e-7)  # 进一步降低学习率
    
    # 添加学习率调度器
    scheduler_actor = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer_actor, T_max=1000)
    scheduler_critic = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer_critic, T_max=1000)
    
    buffer = ExperienceBuffer(limit=1000)
    writer = SummaryWriter(log_dir)
    global_step = 0
    
    for epoch in range(max_epochs):
        print(f"Epoch {epoch+1}/{max_epochs}")
        
        for batch_idx, batch in enumerate(dataloader):
            input_ids = batch["input_ids"].to(device)
            attention_mask = batch["attention_mask"].to(device)
            target_ids = batch["target_ids"].to(device)
            
            # 监控GPU内存使用情况
            if torch.cuda.is_available():
                print(f"Batch {batch_idx+1} - GPU内存使用: {torch.cuda.memory_allocated()/1024**3:.2f} GB / {torch.cuda.memory_reserved()/1024**3:.2f} GB")
            
            target_sqls = [tokenizer.decode(ids, skip_special_tokens=True) for ids in target_ids]
            prompts = [tokenizer.decode(input_ids[i][:attention_mask[i].sum()], skip_special_tokens=True) for i in range(len(input_ids))]
            
            # 进一步减小生成参数
            samples_list = generate_samples(
                prompts, actor_model, tokenizer, 
                max_length=256, max_new_tokens=64,  # 减小序列长度
                n_samples_per_prompt=1, batch_size=1  # 减小生成批次大小
            )
            
            # 如果模型参数已经无效，停止训练
            for name, param in actor_model.named_parameters():
                if torch.isnan(param).any() or torch.isinf(param).any():
                    print(f"严重错误: Actor模型参数 {name} 包含NaN或inf，停止训练")
                    writer.close()
                    return
            
            experiences = generate_experiences(samples_list, actor_model, ref_model, critic_model, reward_model, tokenizer, target_sqls, kl_ctl, clip_reward_value)
            
            # 如果没有有效的经验样本，跳过此批次
            if len(experiences) == 0:
                print(f"警告: 批次 {batch_idx+1} 没有有效的经验样本，跳过")
                del input_ids, attention_mask, target_ids, target_sqls, prompts, samples_list
                torch.cuda.empty_cache()
                continue
                
            buffer.append([vars(exp) for exp in experiences])
            
            # 释放不再需要的变量
            del samples_list, experiences, input_ids, attention_mask, target_ids, target_sqls, prompts
            torch.cuda.empty_cache()
            
            if len(buffer) >= micro_batch_size:
                for _ in range(1):  # 只训练一次，减轻负担
                    batch_experience = buffer.get_batches(micro_batch_size)
                    merged_exp = {}
                    
                    for k in batch_experience[0].keys():
                        values = [exp[k] for exp in batch_experience]
                        
                        if isinstance(values[0], (int, float)):
                            merged_exp[k] = torch.tensor(values, device=device)
                        elif isinstance(values[0], torch.Tensor):
                            if values[0].dim() == 0:
                                merged_exp[k] = torch.stack(values, dim=0)
                            else:
                                merged_exp[k] = torch.cat(values, dim=0)
                        else:
                            merged_exp[k] = values
                    
                    merged_exp_obj = Experience(**merged_exp)
                    results = train_step(merged_exp_obj, actor_model, critic_model, optimizer_actor, optimizer_critic, clip_eps, clip_value_eps, writer, global_step)
                    
                    # 更新学习率
                    scheduler_actor.step()
                    scheduler_critic.step()
                    
                    # 如果训练步骤失败，跳过此更新
                    if results[0] is None:
                        print(f"警告: 步骤 {global_step} 训练失败，跳过")
                        continue
                        
                    global_step += 1
            
            if (batch_idx + 1) % 100 == 0:
                print(f"Saving model at batch {batch_idx+1}")
                model_save_path = os.path.join(output_dir, f"model_step_{global_step}")
                actor_model.save_pretrained(model_save_path)
                tokenizer.save_pretrained(model_save_path)
        
        print(f"Saving model at epoch {epoch+1}")
        model_save_path = os.path.join(output_dir, f"model_epoch_{epoch+1}")
        actor_model.save_pretrained(model_save_path)
        tokenizer.save_pretrained(model_save_path)
    
    print("Training completed! Saving final model...")
    model_save_path = os.path.join(output_dir, "final_model")
    actor_model.save_pretrained(model_save_path)
    tokenizer.save_pretrained(model_save_path)
    writer.close()
    print("Training finished.")

def evaluate(model, tokenizer, dataset, num_samples=10, max_new_tokens=128):
    model.eval()
    indices = random.sample(range(len(dataset)), min(num_samples, len(dataset)))
    
    for i, idx in enumerate(indices):
        sample = dataset[idx]
        input_ids = sample["input_ids"].unsqueeze(0).to(device)
        attention_mask = sample["attention_mask"].unsqueeze(0).to(device)
        target_ids = sample["target_ids"]
        
        with torch.no_grad():
            # 检查模型参数是否有效
            for name, param in model.named_parameters():
                if torch.isnan(param).any() or torch.isinf(param).any():
                    print(f"警告: 评估模型参数 {name} 包含NaN或inf，跳过此样本")
                    continue
            
            outputs = model.generate(
                input_ids=input_ids,
                attention_mask=attention_mask,
                max_new_tokens=max_new_tokens,
                pad_token_id=tokenizer.pad_token_id,
                eos_token_id=tokenizer.eos_token_id,
                temperature=0.3,  # 使用较低的temperature进行评估
            )
        
        generated_sql = tokenizer.decode(outputs[0][input_ids.shape[1]:], skip_special_tokens=True)
        target_sql = tokenizer.decode(target_ids, skip_special_tokens=True)
        prompt = tokenizer.decode(input_ids[0][:attention_mask[0].sum()], skip_special_tokens=True)
        
        print(f"\n示例 {i+1}:")
        print(f"输入提示:\n{prompt}")
        print(f"\n生成的SQL:\n{generated_sql}")
        print(f"\n参考SQL:\n{target_sql}")
        print("-" * 80)

def main():
    model_name = r"/mnt/d/mmodels/Qwen3-0.6B"
    dataset_path = r"/mnt/d/mmodels/20230412_78K_SelfMade_NL2SQLpilot.json"
    output_dir = "./nl2sql_ppo_results"
    log_dir = "./nl2sql_ppo_logs"
    
    print("加载tokenizer...")
    tokenizer = AutoTokenizer.from_pretrained(model_name, trust_remote_code=True)
    tokenizer.padding_side = "left"
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    
    print("加载模型...")
    # 使用float16减少内存占用
    actor_model = AutoModelForCausalLM.from_pretrained(
        model_name, 
        trust_remote_code=True,
        torch_dtype=torch.float16,
        device_map="auto"
    ).to(device)
    # 确保模型在训练前处于正确状态
    actor_model.train()
    for param in actor_model.parameters():
        param.requires_grad_(True)
    
    ref_model = AutoModelForCausalLM.from_pretrained(
        model_name, 
        trust_remote_code=True,
        torch_dtype=torch.float16,
        device_map="auto"
    )
    
    critic_model = Critic(actor_model.base_model).to(device)
    reward_model = SQLRewardModel(actor_model.base_model).to(device)
    
    print("加载数据集...")
    dataset = NL2SQLDataset(dataset_path, tokenizer)
    
    print("开始训练...")
    train(
        actor_model=actor_model,
        ref_model=ref_model,
        critic_model=critic_model,
        reward_model=reward_model,
        tokenizer=tokenizer,
        dataset=dataset,
        output_dir=output_dir,
        batch_size=1,
        micro_batch_size=1,
        max_epochs=3,
        max_new_tokens=64,  # 减小生成长度
        n_samples_per_prompt=1,
        kl_ctl=0.05,  # 减小KL控制参数
        clip_reward_value=3.0,  # 减小奖励裁剪值
        clip_eps=0.1,  # 进一步减小裁剪epsilon
        clip_value_eps=0.1,  # 进一步减小裁剪epsilon
        learning_rate_actor=5e-7,  # 进一步降低学习率
        learning_rate_critic=5e-7,  # 进一步降低学习率
        log_dir=log_dir,
    )
    
    print("评估模型...")
    evaluate(
        model=actor_model,
        tokenizer=tokenizer,
        dataset=dataset,
        num_samples=5,
        max_new_tokens=64,  # 减小生成长度
    )

if __name__ == "__main__":
    main()