import os
import time
from transformers import AutoModelForCausalLM, AutoTokenizer
from datasets import load_dataset
from trl import DPOTrainer, DPOConfig
from peft import LoraConfig, get_peft_model
from swanlab.integration.transformers import SwanLabCallback
import torch

# Configuration
MODEL_NAME = "/mnt/d/mmodels/Qwen3-0.6B"
DATASET_PATH = "/mnt/d/mmodels/20230412_78K_SelfMade_NL2SQLpilot.json"
OUTPUT_DIR = "./nl2sql-dpo-optimized"

def load_and_prepare_data(dataset_path):
    """优化后的数据加载函数"""
    dataset = load_dataset("json", data_files=dataset_path)['train']
    
    # 数据验证
    def is_valid_example(example):
        required_keys = ['instruction', 'input', 'output']
        if not all(key in example for key in required_keys):
            return False
        if not isinstance(example['output'], str) or len(example['output']) < 10:
            return False
        return True
    
    dataset = dataset.filter(is_valid_example)
    
    # 生成对比数据
    def generate_preferences(example):
        base_prompt = f"{example['instruction']}\n{example['input']}"
        valid_sql = example["output"]
        
        # 生成负样本
        error_sqls = [
            "",
            "SELECT * FROM table",
            valid_sql.replace("WHERE", "WHEREE"),
            valid_sql.split("WHERE")[0],
            valid_sql.replace("=", "==")  # 常见错误
        ]
        
        return {
            "prompt": base_prompt,
            "chosen": valid_sql,
            "rejected": error_sqls[hash(valid_sql) % len(error_sqls)]  # 确定性地选择一个错误样本
        }
    
    return dataset.map(generate_preferences, batched=False)

def load_model_with_retry(model_name, device_map):
    """稳健的模型加载"""
    model = None
    for _ in range(3):  # 重试3次
        try:
            model = AutoModelForCausalLM.from_pretrained(
                model_name,
                torch_dtype=torch.bfloat16,
                device_map=device_map,
                attn_implementation="flash_attention_2",
                use_cache=False
            )
            break
        except Exception as e:
            print(f"Model loading failed: {e}")
            time.sleep(5)
    if model is None:
        raise RuntimeError("Failed to load model after multiple attempts")
    return model

def main():
    # 初始化
    tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
    device_map = {"": int(os.environ.get("LOCAL_RANK") or 0)}
    
    # 加载模型
    model = load_model_with_retry(MODEL_NAME, device_map)
    model.enable_input_require_grads()
    
    ref_model = load_model_with_retry(MODEL_NAME, device_map)
    
    # LoRA配置
    lora_config = LoraConfig(
        r=64,
        lora_alpha=32,
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj"],
        lora_dropout=0.05,
        bias="none",
        task_type="CAUSAL_LM"
    )
    model = get_peft_model(model, lora_config)
    
    # 数据加载
    train_data = load_and_prepare_data(DATASET_PATH)
    
    # 监控回调
    swanlab_callback = SwanLabCallback(
        project="Qwen3-NL2SQL-DPO-Optimized",
        experiment_name="Qwen3-0.6B-NL2SQL-v2",
        config={
            "model": MODEL_NAME,
            "dataset_size": len(train_data),
            "lora_rank": 64,
            "lora_alpha": 32,
            "batch_size": 2,
            "grad_accumulation": 4
        }
    )
    
    # 训练参数
    training_args = DPOConfig(
        output_dir=OUTPUT_DIR,
        bf16=torch.cuda.is_bf16_supported(),
        gradient_checkpointing=True,
        per_device_train_batch_size=2,
        gradient_accumulation_steps=4,
        num_train_epochs=3,
        logging_steps=10,
        save_steps=500,
        learning_rate=5e-5,
        max_grad_norm=0.5,
        beta=0.1,
        optim="adamw_torch",
        lr_scheduler_type="cosine",
        warmup_ratio=0.1,
        evaluation_strategy="steps",
        eval_steps=200,
        report_to=["swanlab"]
    )
    
    # 初始化DPO Trainer
    trainer = DPOTrainer(
        model=model,
        ref_model=ref_model,
        train_dataset=train_data,
        tokenizer=tokenizer,
        args=training_args,
        callbacks=[swanlab_callback],
        max_length=1024,
        max_prompt_length=768,
        generate_during_eval=True
    )
    
    # 训练过程
    try:
        trainer.train()
        trainer.save_model(OUTPUT_DIR)
        trainer.save_state()
    except Exception as e:
        print(f"Training failed: {e}")
        # 尝试保存检查点
        trainer.save_model(f"{OUTPUT_DIR}_emergency")

if __name__ == "__main__":
    main()