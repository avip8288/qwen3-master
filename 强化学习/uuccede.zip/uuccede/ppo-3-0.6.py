import json
import os
import random
import re
from typing import List, Dict, Any, Optional, Union, Tuple
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from torch.utils.tensorboard import SummaryWriter
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    PreTrainedModel,
    PreTrainedTokenizer,
)
from dataclasses import dataclass
from accelerate import Accelerator, init_empty_weights
from accelerate.utils import set_seed as set_seed_util
from transformers import default_data_collator

# 初始化Accelerator用于多GPU支持
accelerator = Accelerator()

def set_seed(seed: int = 42):
    """设置随机种子，避免命名冲突"""
    set_seed_util(seed)
    random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

set_seed()

# 使用accelerator管理设备
device = accelerator.device

class NL2SQLDataset(Dataset):
    def __init__(self, data_path: str, tokenizer: PreTrainedTokenizer, max_length: int = 512):
        self.data = self._load_data(data_path)
        self.tokenizer = tokenizer
        self.max_length = max_length
        
    def _load_data(self, data_path: str) -> List[Dict[str, str]]:
        try:
            with open(data_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            return data
        except Exception as e:
            print(f"加载数据失败: {e}")
            return []
            
    def __len__(self) -> int:
        return len(self.data)
        
    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        item = self.data[idx]
        instruction = item["instruction"]
        input_text = item["input"]
        output = item["output"]
        prompt = f"{instruction}\n{input_text}"
        
        inputs = self.tokenizer(
            prompt,
            max_length=self.max_length,
            truncation=True,
            padding="max_length",
            return_tensors="pt",
        )
        
        targets = self.tokenizer(
            output,
            max_length=self.max_length,
            truncation=True,
            padding="max_length",
            return_tensors="pt",
        )
        
        return {
            "input_ids": inputs["input_ids"].squeeze(0),
            "attention_mask": inputs["attention_mask"].squeeze(0),
            "target_ids": targets["input_ids"].squeeze(0),
            "target_attention_mask": targets["attention_mask"].squeeze(0),
        }

class Critic(nn.Module):
    def __init__(self, base_model: PreTrainedModel):
        super().__init__()
        self.base_model = base_model
        self.value_head = nn.Linear(base_model.config.hidden_size, 1)
        self.to(base_model.dtype)
        
    def forward(self, input_ids: torch.Tensor, attention_mask: torch.Tensor, num_actions: int) -> torch.Tensor:
        hidden_state = self.base_model(input_ids, attention_mask=attention_mask).last_hidden_state
        value_output = self.value_head(hidden_state)
        values = value_output.squeeze(-1)[:, -num_actions:]
        return values

class SQLRewardModel(nn.Module):
    def __init__(self, base_model: PreTrainedModel):
        super().__init__()
        self.base_model = base_model
        self.reward_head = nn.Linear(base_model.config.hidden_size, 1)
        self.to(base_model.dtype)
        
    def forward(self, input_ids: torch.Tensor, attention_mask: torch.Tensor) -> torch.Tensor:
        outputs = self.base_model(input_ids, attention_mask=attention_mask)
        pooled_output = outputs.last_hidden_state[:, 0, :]
        reward = self.reward_head(pooled_output)
        return reward

def compute_policy_loss(log_probs, old_log_probs, advantages, action_mask=None, clip_eps=0.2):
    ratio = torch.exp(log_probs - old_log_probs)
    surr1 = ratio * advantages
    surr2 = ratio.clamp(1.0 - clip_eps, 1.0 + clip_eps) * advantages
    loss = -torch.min(surr1, surr2)
    
    if action_mask is None:
        return loss.mean()
    return ((loss * action_mask).sum() / action_mask.sum())

def compute_value_loss(values, old_values, returns, action_mask=None, clip_eps=None):
    if clip_eps is not None:
        values_clipped = old_values + (values - old_values).clamp(-clip_eps, clip_eps)
        surr1 = (values_clipped - returns) ** 2
        surr2 = (values - returns) ** 2
        loss = torch.max(surr1, surr2)
    else:
        loss = (values - returns) ** 2
        
    if action_mask is None:
        return loss.mean()
    return ((loss * action_mask).sum() / action_mask.sum())

class ExperienceBuffer:
    def __init__(self, limit: int = 1000):
        self.limit = limit
        self.buffer = []
        
    def append(self, experiences: List[Dict[str, Any]]) -> None:
        self.buffer.extend(experiences)
        if len(self.buffer) > self.limit:
            self.buffer = self.buffer[-self.limit:]
            
    def get_batches(self, batch_size: int) -> List[Dict[str, Any]]:
        if len(self.buffer) < batch_size:
            return self.buffer
        return random.sample(self.buffer, batch_size)
        
    def clear(self) -> None:
        self.buffer = []
        
    def __len__(self) -> int:
        return len(self.buffer)

@dataclass
class Samples:
    seqs: torch.Tensor
    attention_mask: Optional[torch.Tensor]
    action_mask: Optional[torch.Tensor]
    num_actions: Union[int, torch.Tensor]
    response_length: torch.Tensor
    total_length: torch.Tensor

@dataclass
class Experience:
    seqs: torch.Tensor
    action_log_probs: torch.Tensor
    values: torch.Tensor
    returns: torch.Tensor
    advantages: torch.Tensor
    attention_mask: torch.Tensor
    action_mask: torch.Tensor
    reward: torch.Tensor
    response_length: torch.Tensor
    total_length: torch.Tensor
    num_actions: Union[int, torch.Tensor]
    kl: Optional[torch.Tensor] = None

def compute_approx_kl(log_probs, ref_log_probs, action_mask=None):
    log_ratio = log_probs - ref_log_probs
    if action_mask is not None:
        log_ratio = log_ratio * action_mask
    return log_ratio

def get_advantages_and_returns(values, rewards, action_mask, gamma=0.99, lambd=0.95):
    lastgaelam = 0
    advantages_reversed = []
    response_length = rewards.size(1)
    
    if action_mask is not None:
        values = values * action_mask
        rewards = rewards * action_mask
    
    for t in reversed(range(response_length)):
        nextvalues = values[:, t + 1] if t < response_length - 1 else 0.0
        delta = rewards[:, t] + gamma * nextvalues - values[:, t]
        lastgaelam = delta + gamma * lambd * lastgaelam
        advantages_reversed.append(lastgaelam)
    
    advantages = torch.stack(advantages_reversed[::-1], dim=1)
    returns = advantages + values
    return advantages.detach(), returns.detach()

def generate_samples(prompts, model, tokenizer, max_length=512, max_new_tokens=128, n_samples_per_prompt=1, batch_size=4):
    samples_list = []
    model.eval()
    
    all_prompts = [p for prompt in prompts for p in [prompt] * n_samples_per_prompt]
    
    for i in range(0, len(all_prompts), batch_size):
        batch_prompts = all_prompts[i : i + batch_size]
        
        inputs = tokenizer(
            batch_prompts,
            padding="max_length",
            max_length=max_length - max_new_tokens,
            truncation=True,
            return_tensors="pt",
        )
        
        # 使用accelerator将输入移到正确的设备
        input_ids = inputs["input_ids"].to(device)
        attention_mask = inputs["attention_mask"].to(device)
        
        with torch.no_grad():
            with torch.amp.autocast(device_type='cuda', enabled=False):
                outputs = model.generate(
                    input_ids=input_ids,
                    attention_mask=attention_mask,
                    max_new_tokens=max_new_tokens,
                    pad_token_id=tokenizer.pad_token_id,
                    eos_token_id=tokenizer.eos_token_id,
                    do_sample=True,
                    temperature=0.5,
                    top_p=0.9,
                )
        
        generated_tokens = outputs[:, input_ids.shape[1]:]
        action_mask = generated_tokens.ne(tokenizer.pad_token_id) & generated_tokens.ne(tokenizer.eos_token_id)
        
        samples = Samples(
            seqs=outputs,
            attention_mask=(outputs.ne(tokenizer.pad_token_id)).to(dtype=torch.long),
            action_mask=action_mask.to(dtype=torch.long),
            num_actions=action_mask.size(1),
            response_length=action_mask.sum(dim=1).float(),
            total_length=(outputs.ne(tokenizer.pad_token_id)).sum(dim=1).float(),
        )
        
        samples_list.append(samples)
    
    return samples_list

def compute_sql_rewards(generated_sqls, target_sqls, reward_model, reward_tokenizer, kl, action_mask, kl_ctl=0.1, clip_reward_value=10.0):
    reward_inputs = [f"生成的SQL: {gen_sql}\n参考SQL: {target_sql}" for gen_sql, target_sql in zip(generated_sqls, target_sqls)]
    
    inputs = reward_tokenizer(
        reward_inputs,
        padding="max_length",
        max_length=512,
        truncation=True,
        return_tensors="pt",
    ).to(device)
    
    with torch.no_grad():
        with torch.amp.autocast(device_type='cuda', enabled=False):
            reward_scores = reward_model(**inputs).squeeze(-1)
    
    kl_penalty = -kl_ctl * kl
    rewards = kl_penalty
    
    ends = action_mask.sum(1)
    for i in range(len(rewards)):
        if ends[i] > 0:
            rewards[i, ends[i]-1] += reward_scores[i]
    
    rewards = torch.clamp(rewards, -clip_reward_value, clip_reward_value)
    return rewards

def generate_experiences(samples_list, actor_model, ref_model, critic_model, reward_model, tokenizer, target_sqls, kl_ctl=0.1, clip_reward_value=10.0):
    experiences = []
    
    for samples in samples_list:
        seqs = samples.seqs
        attention_mask = samples.attention_mask
        action_mask = samples.action_mask
        num_actions = samples.num_actions
        
        with torch.no_grad():
            with torch.amp.autocast(device_type='cuda', enabled=False):
                actor_outputs = actor_model(seqs, attention_mask=attention_mask)
                logits = actor_outputs.logits
                log_probs = F.log_softmax(logits[:, :-1, :], dim=-1)
                next_token_log_probs = log_probs.gather(dim=-1, index=seqs[:, 1:].unsqueeze(-1)).squeeze(-1)
                action_log_probs = next_token_log_probs[:, -num_actions:]
                
                ref_outputs = ref_model(seqs, attention_mask=attention_mask)
                ref_logits = ref_outputs.logits
                ref_log_probs = F.log_softmax(ref_logits[:, :-1, :], dim=-1)
                ref_next_token_log_probs = ref_log_probs.gather(dim=-1, index=seqs[:, 1:].unsqueeze(-1)).squeeze(-1)
                ref_action_log_probs = ref_next_token_log_probs[:, -num_actions:]
                
                kl = compute_approx_kl(action_log_probs, ref_action_log_probs, action_mask=action_mask)
                values = critic_model(seqs, attention_mask, num_actions)
                
                generated_sqls = [tokenizer.decode(seq[attention_mask.sum(dim=1)-num_actions:], skip_special_tokens=True) for seq in seqs]
                rewards = compute_sql_rewards(generated_sqls, target_sqls, reward_model, tokenizer, kl, action_mask, kl_ctl, clip_reward_value)
                
                advantages, returns = get_advantages_and_returns(values, rewards, action_mask)
            
        experience = Experience(
            seqs=seqs,
            action_log_probs=action_log_probs,
            values=values,
            returns=returns,
            advantages=advantages,
            attention_mask=attention_mask,
            action_mask=action_mask,
            reward=rewards,
            response_length=samples.response_length,
            total_length=samples.total_length,
            num_actions=num_actions,
            kl=kl,
        )
        
        experiences.append(experience)
    
    return experiences
def train_step(experience, actor_model, critic_model, optimizer_actor, optimizer_critic, clip_eps=0.2, clip_value_eps=0.2, writer=None, global_step=0):
    # 初始化检查
    if torch.isnan(experience.seqs).any() or torch.isinf(experience.seqs).any():
        print("警告: 输入序列包含NaN或inf，跳过此批次")
        return None, None, None
    
    if torch.isnan(experience.advantages).any() or torch.isinf(experience.advantages).any():
        print("警告: 优势值包含NaN或inf，跳过此批次")
        return None, None, None
    
    # 训练前检查模型参数
    for name, param in actor_model.named_parameters():
        if torch.isnan(param).any() or torch.isinf(param).any():
            print(f"警告: 演员模型参数 {name} 包含NaN或inf，跳过此批次")
            return None, None, None
    
    for name, param in critic_model.named_parameters():
        if torch.isnan(param).any() or torch.isinf(param).any():
            print(f"警告: Critic模型参数 {name} 包含NaN或inf，跳过此批次")
            return None, None, None
    
    actor_model.train()
    critic_model.train()
    
    # 检查输入数据
    print(f"输入序列形状: {experience.seqs.shape}, 设备: {experience.seqs.device}")
    print(f"优势值形状: {experience.advantages.shape}, 最小值: {experience.advantages.min()}, 最大值: {experience.advantages.max()}")
    
    # Actor训练部分
    optimizer_actor.zero_grad()
    
    seqs = experience.seqs
    attention_mask = experience.attention_mask
    action_mask = experience.action_mask
    old_action_log_probs = experience.action_log_probs
    advantages = experience.advantages
    num_actions = experience.num_actions
    
    # 确保num_actions是一个有效的整数值
    if isinstance(num_actions, list):
        # 如果是列表，取第一个元素（假设batch_size=1）
        if len(num_actions) > 0:
            num_actions = num_actions[0]
        else:
            print("警告: num_actions列表为空，跳过此批次")
            return None, None, None
    
    if isinstance(num_actions, torch.Tensor):
        num_actions = num_actions.item()
    
    # 确保num_actions是一个正整数
    if not isinstance(num_actions, int) or num_actions <= 0:
        print(f"警告: num_actions不是有效的正整数 ({num_actions})，跳过此批次")
        return None, None, None
    
    with torch.amp.autocast(device_type='cuda', enabled=False):
        outputs = actor_model(seqs, attention_mask=attention_mask)
        logits = outputs.logits
        log_probs = F.log_softmax(logits[:, :-1, :], dim=-1)
        next_token_log_probs = log_probs.gather(dim=-1, index=seqs[:, 1:].unsqueeze(-1)).squeeze(-1)
        action_log_probs = next_token_log_probs[:, -num_actions:]  # 现在应该是有效的索引操作
        
        # 优势值归一化
        advantages = (advantages - advantages.mean()) / (advantages.std() + 1e-8)
        advantages = torch.clamp(advantages, -2.0, 2.0)
        
        policy_loss = compute_policy_loss(action_log_probs, old_action_log_probs, advantages, action_mask, clip_eps)
    
    # 检查损失值
    if torch.isnan(policy_loss).any() or torch.isinf(policy_loss).any():
        print("警告: Policy loss包含NaN或inf，跳过此批次")
        optimizer_actor.zero_grad()
        return None, None, None
        
    # 使用accelerator进行梯度同步和优化
    with accelerator.accumulate(actor_model):
        policy_loss.backward()
        torch.nn.utils.clip_grad_norm_(actor_model.parameters(), 0.3)
        optimizer_actor.step()
    
    # Critic训练部分
    optimizer_critic.zero_grad()
    
    old_values = experience.values
    returns = experience.returns
    
    with torch.amp.autocast(device_type='cuda', enabled=False):
        values = critic_model(seqs, attention_mask, num_actions)
        returns = torch.clamp(returns, -2.0, 2.0)
        value_loss = compute_value_loss(values, old_values, returns, action_mask, clip_value_eps)
    
    if torch.isnan(value_loss).any() or torch.isinf(value_loss).any():
        print("警告: Value loss包含NaN或inf，跳过此批次")
        optimizer_critic.zero_grad()
        return None, None, None
        
    # 使用accelerator进行梯度同步和优化
    with accelerator.accumulate(critic_model):
        value_loss.backward()
        torch.nn.utils.clip_grad_norm_(critic_model.parameters(), 0.3)
        optimizer_critic.step()
    
    # 记录训练指标
    if writer is not None:
        # 使用accelerator获取全局步数
        writer.add_scalar("policy_loss", policy_loss.item(), global_step)
        writer.add_scalar("value_loss", value_loss.item(), global_step)
        writer.add_scalar("reward_mean", experience.reward.mean().item(), global_step)
        writer.add_scalar("advantages_mean", advantages.mean().item(), global_step)
    
    print(f"Step {global_step}: Policy Loss = {policy_loss.item():.4f}, Value Loss = {value_loss.item():.4f}, Reward Mean = {experience.reward.mean().item():.4f}")
    return policy_loss.item(), value_loss.item(), experience.reward.mean().item()
    

def train(actor_model, ref_model, critic_model, reward_model, tokenizer, dataset, output_dir="./results", batch_size=4, micro_batch_size=1, max_epochs=3, max_new_tokens=128, n_samples_per_prompt=1, kl_ctl=0.1, clip_reward_value=10.0, clip_eps=0.2, clip_value_eps=0.2, learning_rate_actor=1e-7, learning_rate_critic=1e-7, log_dir="./logs"):
    os.makedirs(output_dir, exist_ok=True)
    
    # 使用DataLoader和default_data_collator进行批处理
    dataloader = DataLoader(dataset, batch_size=1, shuffle=True, collate_fn=default_data_collator)
    
    optimizer_actor = torch.optim.AdamW(actor_model.parameters(), lr=learning_rate_actor)
    optimizer_critic = torch.optim.AdamW(critic_model.parameters(), lr=learning_rate_critic)
    
    # 使用accelerator准备模型和优化器
    actor_model, ref_model, critic_model, reward_model, optimizer_actor, optimizer_critic = accelerator.prepare(
        actor_model, ref_model, critic_model, reward_model, optimizer_actor, optimizer_critic
    )
    
    buffer = ExperienceBuffer(limit=1000)
    writer = SummaryWriter(log_dir)
    global_step = 0
    
    for epoch in range(max_epochs):
        print(f"Epoch {epoch+1}/{max_epochs}")
        
        for batch_idx, batch in enumerate(dataloader):
            # 使用accelerator将批次数据移到正确的设备
            batch = {k: v.to(device) for k, v in batch.items()}
            input_ids = batch["input_ids"]
            attention_mask = batch["attention_mask"]
            target_ids = batch["target_ids"]
            
            target_sqls = [tokenizer.decode(ids, skip_special_tokens=True) for ids in target_ids]
            prompts = [tokenizer.decode(input_ids[i][:attention_mask[i].sum()], skip_special_tokens=True) for i in range(len(input_ids))]
            
            samples_list = generate_samples(
                prompts, actor_model, tokenizer, 
                max_length=192, max_new_tokens=48, 
                n_samples_per_prompt=1, batch_size=1
            )
            
            experiences = generate_experiences(samples_list, actor_model, ref_model, critic_model, reward_model, tokenizer, target_sqls, kl_ctl, clip_reward_value)
            
            # 确保经验数据中的张量类型正确并移到设备
            for exp in experiences:
                for k, v in exp.__dict__.items():
                    if isinstance(v, torch.Tensor):
                        exp.__dict__[k] = v.to(device)
            
            buffer.append([vars(exp) for exp in experiences])
            
            if len(buffer) >= micro_batch_size:
                batch_experience = buffer.get_batches(micro_batch_size)
                merged_exp = {}
                
                for k in batch_experience[0].keys():
                    values = [exp[k] for exp in batch_experience]
                    if isinstance(values[0], torch.Tensor):
                        # 合并张量并移到设备
                        merged_exp[k] = torch.cat([v.to(device) for v in values], dim=0)
                    else:
                        merged_exp[k] = values
                
                merged_exp_obj = Experience(**merged_exp)
                # 确保num_actions是整数
                if isinstance(merged_exp_obj.num_actions, torch.Tensor):
                    merged_exp_obj.num_actions = merged_exp_obj.num_actions.item()
                
                train_step(merged_exp_obj, actor_model, critic_model, optimizer_actor, optimizer_critic, clip_eps, clip_value_eps, writer, global_step)
                global_step += 1
            
            if (batch_idx + 1) % 100 == 0:
                print(f"Saving model at batch {batch_idx+1}")
                # 使用accelerator获取原始模型进行保存
                unwrapped_actor = accelerator.unwrap_model(actor_model)
                model_save_path = os.path.join(output_dir, f"model_step_{global_step}")
                unwrapped_actor.save_pretrained(model_save_path)
                tokenizer.save_pretrained(model_save_path)
        
        print(f"Saving model at epoch {epoch+1}")
        unwrapped_actor = accelerator.unwrap_model(actor_model)
        model_save_path = os.path.join(output_dir, f"model_epoch_{epoch+1}")
        unwrapped_actor.save_pretrained(model_save_path)
        tokenizer.save_pretrained(model_save_path)
    
    print("Training completed! Saving final model...")
    unwrapped_actor = accelerator.unwrap_model(actor_model)
    model_save_path = os.path.join(output_dir, "final_model")
    unwrapped_actor.save_pretrained(model_save_path)
    tokenizer.save_pretrained(model_save_path)
    writer.close()
    print("Training finished.")

def evaluate(model, tokenizer, dataset, num_samples=10, max_new_tokens=128):
    # 使用accelerator获取原始模型进行评估
    unwrapped_model = accelerator.unwrap_model(model)
    unwrapped_model.eval()
    
    indices = random.sample(range(len(dataset)), min(num_samples, len(dataset)))
    
    for i, idx in enumerate(indices):
        sample = dataset[idx]
        input_ids = sample["input_ids"].unsqueeze(0).to(device)
        attention_mask = sample["attention_mask"].unsqueeze(0).to(device)
        target_ids = sample["target_ids"]
        
        with torch.no_grad():
            with torch.amp.autocast(device_type='cuda', enabled=False):
                outputs = unwrapped_model.generate(
                    input_ids=input_ids,
                    attention_mask=attention_mask,
                    max_new_tokens=max_new_tokens,
                    pad_token_id=tokenizer.pad_token_id,
                    eos_token_id=tokenizer.eos_token_id,
                    temperature=0.3,
                )
        
        generated_sql = tokenizer.decode(outputs[0][input_ids.shape[1]:], skip_special_tokens=True)
        target_sql = tokenizer.decode(target_ids, skip_special_tokens=True)
        prompt = tokenizer.decode(input_ids[0][:attention_mask[0].sum()], skip_special_tokens=True)
        
        print(f"\n示例 {i+1}:")
        print(f"输入提示:\n{prompt}")
        print(f"\n生成的SQL:\n{generated_sql}")
        print(f"\n参考SQL:\n{target_sql}")
        print("-" * 80)

def main():
    model_name = r"/Qwen3-0.6B"
    dataset_path = r"/root/20230412_78K_SelfMade_NL2SQLpilot.json"
    output_dir = "./nl2sql_ppo_results"
    log_dir = "./nl2sql_ppo_logs"
    
    print("加载tokenizer...")
    tokenizer = AutoTokenizer.from_pretrained(model_name, trust_remote_code=True)
    tokenizer.padding_side = "left"
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    
    print("加载模型...")
    # 先加载模型权重到CPU，再进行设备分配
    actor_model = AutoModelForCausalLM.from_pretrained(
        model_name, 
        trust_remote_code=True,
        torch_dtype=torch.float32,
        device_map="cpu"  # 先加载到CPU
    )
    
    # 绑定模型权重
    if hasattr(actor_model, "tie_weights"):
        actor_model.tie_weights()  # 显式绑定权重
    
    actor_model.train()
    for param in actor_model.parameters():
        param.requires_grad_(True)
    
    ref_model = AutoModelForCausalLM.from_pretrained(
        model_name, 
        trust_remote_code=True,
        torch_dtype=torch.float32,
        device_map="cpu"  # 先加载到CPU
    )
    
    if hasattr(ref_model, "tie_weights"):
        ref_model.tie_weights()  # 显式绑定权重
    
    # 将模型移动到accelerator管理的设备
    critic_model = Critic(actor_model.base_model).to(device)
    reward_model = SQLRewardModel(actor_model.base_model).to(device)
    
    print("加载数据集...")
    dataset = NL2SQLDataset(dataset_path, tokenizer)
    
    print("开始训练...")
    train(
        actor_model=actor_model,
        ref_model=ref_model,
        critic_model=critic_model,
        reward_model=reward_model,
        tokenizer=tokenizer,
        dataset=dataset,
        output_dir=output_dir,
        batch_size=1,
        micro_batch_size=1,
        max_epochs=3,
        max_new_tokens=48,
        n_samples_per_prompt=1,
        kl_ctl=0.03,
        clip_reward_value=2.0,
        clip_eps=0.05,
        clip_value_eps=0.05,
        learning_rate_actor=1e-7,
        learning_rate_critic=1e-7,
        log_dir=log_dir,
    )
    
    print("评估模型...")
    evaluate(
        model=actor_model,
        tokenizer=tokenizer,
        dataset=dataset,
        num_samples=5,
        max_new_tokens=48,
    )

if __name__ == "__main__":
    main()