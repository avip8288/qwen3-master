import json
import os
import random
import re
from typing import List, Dict, Any, Optional, Union, Tuple
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from torch.utils.tensorboard import SummaryWriter
from transformers import AutoModelForCausalLM, AutoTokenizer, PreTrainedModel, PreTrainedTokenizer
from dataclasses import dataclass
import swanlab
import deepspeed
from deepspeed import init_distributed
from deepspeed.runtime.pipe import PipelineModule
from deepspeed.utils import RepeatingLoader
from transformers.deepspeed import HfDeepSpeedConfig
import numpy as np

# SwanLab 导入
try:
    import swanlab
    from swanlab import Experiment
    SWANLAB_AVAILABLE = True
except ImportError:
    SWANLAB_AVAILABLE = False
    print("警告：未安装SwanLab，记录功能将仅使用TensorBoard")

def set_seed(seed: int = 42):
    random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

set_seed()

# 初始化分布式环境
init_distributed()
local_rank = torch.distributed.get_rank()
torch.cuda.set_device(local_rank)
world_size = torch.distributed.get_world_size()
device = f"cuda:{local_rank}" if torch.cuda.is_available() else "cpu"

class NL2SQLDataset(Dataset):
    def __init__(self, data_path: str, tokenizer: PreTrainedTokenizer, max_length: int = 512):
        self.data = self._load_data(data_path)
        self.tokenizer = tokenizer
        self.max_length = max_length
        
    def _load_data(self, data_path: str) -> List[Dict[str, str]]:
        try:
            with open(data_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            return data
        except Exception as e:
            print(f"加载数据失败: {e}")
            return []
            
    def __len__(self) -> int:
        return len(self.data)
        
    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        item = self.data[idx]
        instruction = item["instruction"]
        input_text = item["input"]
        output = item["output"]
        prompt = f"{instruction}\n{input_text}"
        
        inputs = self.tokenizer(
            prompt,
            max_length=self.max_length,
            truncation=True,
            padding="max_length",
            return_tensors="pt",
        )
        
        targets = self.tokenizer(
            output,
            max_length=self.max_length,
            truncation=True,
            padding="max_length",
            return_tensors="pt",
        )
        
        return {
            "input_ids": inputs["input_ids"].squeeze(0),
            "attention_mask": inputs["attention_mask"].squeeze(0),
            "target_ids": targets["input_ids"].squeeze(0),
            "target_attention_mask": targets["attention_mask"].squeeze(0),
        }

class GRPORewardModel(nn.Module):
    def __init__(self, base_model: PreTrainedModel):
        super().__init__()
        self.base_model = base_model
        self.reward_head = nn.Linear(base_model.config.hidden_size, 1)
        self.to(base_model.dtype)
        
    def forward(self, input_ids: torch.Tensor, attention_mask: torch.Tensor) -> torch.Tensor:
        outputs = self.base_model(input_ids, attention_mask=attention_mask)
        # 使用最后一个token的隐藏状态计算奖励
        last_token_idx = attention_mask.sum(dim=1) - 1
        last_token_hidden = outputs.last_hidden_state[torch.arange(len(input_ids)), last_token_idx]
        reward = self.reward_head(last_token_hidden).squeeze(-1)
        return reward

@dataclass
class GRPOSamples:
    prompt_ids: torch.Tensor
    prompt_attention_mask: torch.Tensor
    response_ids: torch.Tensor
    response_attention_mask: torch.Tensor
    reward: torch.Tensor
    prompt_length: torch.Tensor
    response_length: torch.Tensor

@dataclass
class GRPOExperience:
    prompt_ids: torch.Tensor
    prompt_attention_mask: torch.Tensor
    response_ids: torch.Tensor
    response_attention_mask: torch.Tensor
    reward: torch.Tensor
    log_probs: torch.Tensor
    baseline: torch.Tensor
    advantage: torch.Tensor
    prompt_length: torch.Tensor
    response_length: torch.Tensor

def generate_grpo_samples(prompts, actor_model, reward_model, tokenizer, max_length=512, max_new_tokens=128):
    samples_list = []
    actor_model.eval()
    reward_model.eval()
    
    for prompt in prompts:
        # 编码提示词
        prompt_inputs = tokenizer(
            prompt,
            padding="max_length",
            max_length=max_length - max_new_tokens,
            truncation=True,
            return_tensors="pt",
        )
        prompt_ids = prompt_inputs["input_ids"].to(device)
        prompt_attention_mask = prompt_inputs["attention_mask"].to(device)
        prompt_length = prompt_attention_mask.sum(dim=1)
        
        with torch.no_grad():
            # 生成响应
            response_outputs = actor_model.generate(
                input_ids=prompt_ids,
                attention_mask=prompt_attention_mask,
                max_new_tokens=max_new_tokens,
                pad_token_id=tokenizer.pad_token_id,
                eos_token_id=tokenizer.eos_token_id,
                do_sample=True,
                temperature=0.7,
                top_p=0.9,
            )
            response_ids = response_outputs[0, prompt_length:]  # 只取生成的部分
            response_attention_mask = (response_ids != tokenizer.pad_token_id).to(dtype=torch.long)
            response_length = response_attention_mask.sum(dim=0)
            
            # 计算完整输入（提示词+响应）的奖励
            full_input_ids = torch.cat([prompt_ids[0], response_ids], dim=0).unsqueeze(0)
            full_attention_mask = torch.cat([prompt_attention_mask[0], response_attention_mask], dim=0).unsqueeze(0)
            reward = reward_model(full_input_ids, full_attention_mask)
        
        samples = GRPOSamples(
            prompt_ids=prompt_ids,
            prompt_attention_mask=prompt_attention_mask,
            response_ids=response_ids,
            response_attention_mask=response_attention_mask,
            reward=reward,
            prompt_length=prompt_length,
            response_length=response_length,
        )
        samples_list.append(samples)
    
    return samples_list

def compute_grpo_loss(experience, actor_model, gamma=0.99, entropy_coef=0.01):
    prompt_ids = experience.prompt_ids
    prompt_attention_mask = experience.prompt_attention_mask
    response_ids = experience.response_ids
    response_attention_mask = experience.response_attention_mask
    advantage = experience.advantage
    log_probs = experience.log_probs
    reward = experience.reward
    
    # 计算完整输入
    full_ids = torch.cat([prompt_ids[0], response_ids], dim=0).unsqueeze(0)
    full_attention_mask = torch.cat([prompt_attention_mask[0], response_attention_mask], dim=0).unsqueeze(0)
    
    # 获取模型输出
    outputs = actor_model(full_ids, attention_mask=full_attention_mask)
    logits = outputs.logits
    
    # 计算响应部分的对数概率
    response_start_idx = prompt_ids.size(1)
    response_logits = logits[:, response_start_idx-1:-1, :]  # 忽略第一个token的预测
    response_log_probs = F.log_softmax(response_logits, dim=-1)
    
    # 计算目标token的对数概率
    target_log_probs = response_log_probs.gather(2, response_ids.unsqueeze(-1)).squeeze(-1)
    
    # 应用注意力掩码
    if response_attention_mask is not None:
        target_log_probs = target_log_probs * response_attention_mask
    
    # 计算策略损失 (负的对数概率乘以优势)
    policy_loss = -(target_log_probs * advantage).sum() / response_attention_mask.sum()
    
    # 计算熵奖励 (鼓励探索)
    probs = F.softmax(response_logits, dim=-1)
    entropy = -(probs * response_log_probs).sum(dim=-1)
    if response_attention_mask is not None:
        entropy = (entropy * response_attention_mask).sum() / response_attention_mask.sum()
    entropy_bonus = -entropy_coef * entropy
    
    # 总损失
    total_loss = policy_loss + entropy_bonus
    
    return total_loss, policy_loss, entropy_bonus, reward.mean()

def train_step_grpo(experience, actor_model, optimizer_actor, gamma=0.99, entropy_coef=0.01,
                 writer=None, swan_experiment=None, global_step=0):
    actor_model.train()
    
    optimizer_actor.zero_grad()
    
    with torch.cuda.amp.autocast(dtype=torch.float16):
        total_loss, policy_loss, entropy_bonus, reward_mean = compute_grpo_loss(
            experience, actor_model, gamma=gamma, entropy_coef=entropy_coef
        )
    
    total_loss.backward()
    torch.nn.utils.clip_grad_norm_(actor_model.parameters(), 1.0)
    optimizer_actor.step()
    
    if writer is not None and local_rank == 0:
        writer.add_scalar("total_loss", total_loss.item(), global_step)
        writer.add_scalar("policy_loss", policy_loss.item(), global_step)
        writer.add_scalar("entropy_bonus", entropy_bonus.item(), global_step)
        writer.add_scalar("reward_mean", reward_mean.item(), global_step)
    
    # SwanLab 记录指标
    if swan_experiment and SWANLAB_AVAILABLE and local_rank == 0:
        swan_experiment.log_metrics({
            "total_loss": total_loss.item(),
            "policy_loss": policy_loss.item(),
            "entropy_bonus": entropy_bonus.item(),
            "reward_mean": reward_mean.item()
        }, step=global_step)
    
    if local_rank == 0:
        print(f"Step {global_step}: Total Loss = {total_loss.item():.4f}, Policy Loss = {policy_loss.item():.4f}, "
              f"Entropy Bonus = {entropy_bonus.item():.4f}, Reward Mean = {reward_mean.item():.4f}")
    return total_loss.item(), policy_loss.item(), entropy_bonus.item(), reward_mean.item()

def create_ds_config(world_size):
    """创建DeepSpeed配置"""
    ds_config = {
        "zero_optimization": {
            "stage": 3,
            "offload_optimizer": {
                "device": "cpu",
                "pin_memory": True
            },
            "offload_param": {
                "device": "cpu",
                "pin_memory": True
            },
            "allgather_partitions": True,
            "allgather_bucket_size": 5e8,
            "overlap_comm": True,
            "reduce_scatter": True,
            "contiguous_gradients": True
        },
        "fp16": {
            "enabled": True,
            "loss_scale": 0,
            "loss_scale_window": 1000,
            "initial_scale_power": 16,
            "hysteresis": 2,
            "min_loss_scale": 1
        },
        "gradient_accumulation_steps": 4,
        "gradient_clipping": 1.0,
        "steps_per_print": 10,
        "train_batch_size": None,
        "train_micro_batch_size_per_gpu": 2,
        "wall_clock_breakdown": False,
        "model_parallel_size": world_size,
        "pipeline_parallel": {
            "enabled": True,
            "chunks": 4,
            "pipeline_batch_size": 2
        }
    }
    return ds_config

def create_layer_split_model(model, world_size):
    """按层切分模型"""
    if world_size == 1:
        return model.to(device)
    
    num_layers = model.config.num_hidden_layers
    layers_per_gpu = num_layers // world_size
    
    class QWenPipeline(PipelineModule):
        def __init__(self, layers):
            super().__init__()
            self.layers = nn.ModuleList(layers)
        
        def forward(self, input_ids, attention_mask):
            hidden_states = model.model.embedding(input_ids)
            hidden_states = model.model.layers[0].ln_1(hidden_states)
            for layer in self.layers:
                hidden_states = layer(hidden_states, attention_mask)
            hidden_states = model.model.layers[-1].ln_2(hidden_states)
            output = model.lm_head(hidden_states)
            return output
    
    layers = model.model.layers
    split_layers = []
    for i in range(world_size):
        start = i * layers_per_gpu
        end = start + layers_per_gpu if i < world_size - 1 else num_layers
        split_layers.append(layers[start:end])
    
    pipe_models = []
    for i in range(world_size):
        pipe_model = QWenPipeline(split_layers[i])
        pipe_model.to(f"cuda:{i}")
        pipe_models.append(pipe_model)
    
    class DistributedQWen(nn.Module):
        def __init__(self, pipe_models):
            super().__init__()
            self.pipe_models = pipe_models
            self.embedding = model.model.embedding
            self.lm_head = model.lm_head
            self.layers = model.model.layers
        
        def forward(self, input_ids, attention_mask):
            hidden_states = self.embedding(input_ids)
            hidden_states = self.layers[0].ln_1(hidden_states)
            for i, pipe_model in enumerate(self.pipe_models):
                hidden_states = pipe_model(hidden_states, attention_mask)
            hidden_states = self.layers[-1].ln_2(hidden_states)
            output = self.lm_head(hidden_states)
            return output
    
    return DistributedQWen(pipe_models)

def train(actor_model, ref_model, reward_model, tokenizer, dataset, output_dir="./results", 
          batch_size=4, micro_batch_size=1, max_epochs=3, max_new_tokens=128, 
          gamma=0.99, entropy_coef=0.01, learning_rate_actor=5e-6, log_dir="./logs"):
    os.makedirs(output_dir, exist_ok=True)
    
    # 创建DeepSpeed配置
    ds_config = create_ds_config(world_size)
    
    # 配置DeepSpeed for Actor模型
    dschf_config = HfDeepSpeedConfig(ds_config)
    
    # 按层切分模型
    actor_model = create_layer_split_model(actor_model, world_size)
    
    # 初始化DeepSpeed优化器
    optimizer_actor = torch.optim.AdamW(actor_model.parameters(), lr=learning_rate_actor)
    
    # 集成DeepSpeed
    actor_model, optimizer_actor, _, _ = deepspeed.initialize(
        model=actor_model,
        optimizer=optimizer_actor,
        config_params=ds_config
    )
    
    # 数据并行包装Reward模型
    if world_size > 1:
        reward_model = nn.parallel.DistributedDataParallel(reward_model, device_ids=[local_rank])
    
    # 仅在主卡创建SummaryWriter
    writer = SummaryWriter(log_dir) if local_rank == 0 else None
    
    # SwanLab 初始化实验
    swan_experiment = None
    if SWANLAB_AVAILABLE and local_rank == 0:
        try:
            swan_experiment = Experiment(
                project_name="NL2SQL-GRPO",
                experiment_name="SQL生成模型GRPO训练",
                tags=["NL2SQL", "GRPO", "强化学习", f"{world_size}卡训练"]
            )
            # 记录超参数
            swan_experiment.log_params({
                "batch_size": batch_size,
                "micro_batch_size": micro_batch_size,
                "max_epochs": max_epochs,
                "max_new_tokens": max_new_tokens,
                "gamma": gamma,
                "entropy_coef": entropy_coef,
                "learning_rate_actor": learning_rate_actor,
                "gpu_count": world_size
            })
        except Exception as e:
            print(f"SwanLab初始化失败: {e}")
            swan_experiment = None
    
    global_step = 0
    
    # 创建数据加载器
    train_sampler = torch.utils.data.DistributedSampler(dataset, shuffle=True)
    dataloader = DataLoader(dataset, batch_size=batch_size, sampler=train_sampler)
    dataloader = RepeatingLoader(dataloader)
    
    for epoch in range(max_epochs):
        if local_rank == 0:
            print(f"Epoch {epoch+1}/{max_epochs}")
        
        for batch_idx in range(100):
            batch = next(dataloader)
            input_ids = batch["input_ids"].to(device)
            attention_mask = batch["attention_mask"].to(device)
            target_ids = batch["target_ids"].to(device)
            
            # 准备提示词
            prompts = [tokenizer.decode(input_ids[i][:attention_mask[i].sum()], skip_special_tokens=True) for i in range(len(input_ids))]
            
            # 生成GRPO样本
            samples_list = generate_grpo_samples(
                prompts, actor_model, reward_model, tokenizer, 
                max_length=512, max_new_tokens=max_new_tokens
            )
            
            # 计算基线（使用参考模型的平均奖励）
            baseline = 0.0
            
            # 处理每个样本
            for samples in samples_list:
                # 计算对数概率
                full_ids = torch.cat([samples.prompt_ids[0], samples.response_ids], dim=0).unsqueeze(0)
                full_attention_mask = torch.cat([samples.prompt_attention_mask[0], samples.response_attention_mask], dim=0).unsqueeze(0)
                
                with torch.no_grad():
                    outputs = actor_model(full_ids, attention_mask=full_attention_mask)
                    logits = outputs.logits
                    
                    response_start_idx = samples.prompt_ids.size(1)
                    response_logits = logits[:, response_start_idx-1:-1, :]
                    response_log_probs = F.log_softmax(response_logits, dim=-1)
                    
                    target_log_probs = response_log_probs.gather(2, samples.response_ids.unsqueeze(-1)).squeeze(-1)
                    
                    if samples.response_attention_mask is not None:
                        target_log_probs = (target_log_probs * samples.response_attention_mask).sum() / samples.response_attention_mask.sum()
                    else:
                        target_log_probs = target_log_probs.mean()
                
                # 计算优势
                advantage = samples.reward - baseline
                
                # 创建经验对象
                experience = GRPOExperience(
                    prompt_ids=samples.prompt_ids,
                    prompt_attention_mask=samples.prompt_attention_mask,
                    response_ids=samples.response_ids,
                    response_attention_mask=samples.response_attention_mask,
                    reward=samples.reward,
                    log_probs=target_log_probs,
                    baseline=torch.tensor(baseline, device=device),
                    advantage=advantage,
                    prompt_length=samples.prompt_length,
                    response_length=samples.response_length,
                )
                
                # 训练步骤
                total_loss, policy_loss, entropy_bonus, reward_mean = train_step_grpo(
                    experience, actor_model, optimizer_actor,
                    gamma=gamma, entropy_coef=entropy_coef,
                    writer=writer, swan_experiment=swan_experiment, global_step=global_step
                )
                global_step += 1
            
            if (batch_idx + 1) % 10 == 0 and local_rank == 0:
                print(f"Batch {batch_idx+1} completed, Total Loss: {total_loss:.4f}, Reward: {reward_mean:.4f}")
        
        # 仅在主卡保存检查点
        if local_rank == 0:
            print(f"Saving model at epoch {epoch+1}")
            model_save_path = os.path.join(output_dir, f"model_epoch_{epoch+1}")
            unwrapped_model = actor_model.module if hasattr(actor_model, "module") else actor_model
            unwrapped_model.save_pretrained(model_save_path)
            tokenizer.save_pretrained(model_save_path)
            
            if swan_experiment and SWANLAB_AVAILABLE:
                swan_experiment.log_artifact(model_save_path, name=f"model_epoch_{epoch+1}")
    
    if local_rank == 0:
        print("Training completed! Saving final model...")
        model_save_path = os.path.join(output_dir, "final_model")
        unwrapped_model = actor_model.module if hasattr(actor_model, "module") else actor_model
        unwrapped_model.save_pretrained(model_save_path)
        tokenizer.save_pretrained(model_save_path)
        
        if swan_experiment and SWANLAB_AVAILABLE:
            swan_experiment.log_artifact(model_save_path, name="final_model")
            swan_experiment.complete()
    
    if writer:
        writer.close()
    print("Training finished.")

def evaluate(model, tokenizer, dataset, num_samples=10, max_new_tokens=128):
    model.eval()
    indices = random.sample(range(len(dataset)), min(num_samples, len(dataset)))
    
    eval_results = []
    for i, idx in enumerate(indices):
        sample = dataset[idx]
        input_ids = sample["input_ids"].unsqueeze(0).to(device)
        attention_mask = sample["attention_mask"].unsqueeze(0).to(device)
        target_ids = sample["target_ids"]
        
        with torch.no_grad():
            outputs = model.generate(
                input_ids=input_ids,
                attention_mask=attention_mask,
                max_new_tokens=max_new_tokens,
                pad_token_id=tokenizer.pad_token_id,
                eos_token_id=tokenizer.eos_token_id,
            )
        
        generated_sql = tokenizer.decode(outputs[0][input_ids.shape[1]:], skip_special_tokens=True)
        target_sql = tokenizer.decode(target_ids, skip_special_tokens=True)
        prompt = tokenizer.decode(input_ids[0][:attention_mask[0].sum()], skip_special_tokens=True)
        
        is_correct = "SELECT" in generated_sql and "FROM" in generated_sql
        eval_results.append({
            "prompt": prompt,
            "generated_sql": generated_sql,
            "target_sql": target_sql,
            "is_correct": is_correct
        })
        
        if local_rank == 0:
            print(f"\n示例 {i+1}:")
            print(f"输入提示:\n{prompt}")
            print(f"\n生成的SQL:\n{generated_sql}")
            print(f"\n参考SQL:\n{target_sql}")
            print(f"评估结果: {'正确' if is_correct else '错误'}")
            print("-" * 80)
    
    if SWANLAB_AVAILABLE and swan_experiment and local_rank == 0:
        accuracy = sum(1 for r in eval_results if r["is_correct"]) / len(eval_results)
        swan_experiment.log_metrics({"evaluation_accuracy": accuracy})
        swan_experiment.log_table("evaluation_results", eval_results)
    
    return eval_results

def main():
    model_name = r"D:\mmodels\Qwen2___5-0___5B-Instruct"
    dataset_path = r"D:\mmodels\20230412_78K_SelfMade_NL2SQLpilot.json"
    output_dir = "./nl2sql_grpo_results"
    log_dir = "./nl2sql_grpo_logs"
    
    tokenizer = AutoTokenizer.from_pretrained(model_name, trust_remote_code=True)
    tokenizer.padding_side = "left"
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    
    # 加载模型
    actor_model = AutoModelForCausalLM.from_pretrained(
        model_name, 
        trust_remote_code=True,
        torch_dtype=torch.float16,
        device_map="auto"
    )
    actor_model.train()
    for param in actor_model.parameters():
        param.requires_grad_(True)
    
    ref_model = AutoModelForCausalLM.from_pretrained(
        model_name, 
        trust_remote_code=True,
        torch_dtype=torch.float16,
        device_map="auto"
    )
    
    reward_model = GRPORewardModel(actor_model.base_model).to(device)
    
    dataset = NL2SQLDataset(dataset_path, tokenizer)
    
    train(
        actor_model=actor_model,
        ref_model=ref_model,
        reward_model=reward_model,
        tokenizer=tokenizer,
        dataset=dataset,
        output_dir=output_dir,
        batch_size=4,
        micro_batch_size=1,
        max_epochs=3,
        max_new_tokens=128,
        gamma=0.99,
        entropy_coef=0.01,
        learning_rate_actor=5e-6,
        log_dir=log_dir,
    )
    
    if local_rank == 0:
        evaluate(
            model=actor_model,
            tokenizer=tokenizer,
            dataset=dataset,
            num_samples=5,
            max_new_tokens=128,
        )

if __name__ == "__main__":
    main()