import re
import sqlparse
from typing import List, Union, Dict, Any
from sqlparse.sql import Identifier, Where

class RewardFunctions:
    @staticmethod
    def extract_sql(text: str) -> str:
        """从模型输出中提取SQL语句"""
        sql_match = re.search(r"<answer>\n?(.*?)\n?</answer>", text, re.DOTALL)
        return sqlparse.format(sql_match.group(1).strip()) if sql_match else ""

    @staticmethod
    def validate_sql_format(text: str) -> bool:
        """验证是否包含标准格式标记"""
        return all(tag in text for tag in ["<think>", "</think>", "<answer>", "</answer>"])

    @staticmethod
    def correctness_reward(prompts: List[str], responses: List[str], answers: List[str], db_schemas: List[str] = None) -> List[float]:
        """SQL逻辑正确性奖励"""
        rewards = []
        for resp, ans in zip(responses, answers):
            extracted_sql = RewardFunctions.extract_sql(resp)
            rewards.append(2.0 if extracted_sql == sqlparse.format(ans).strip() else 0.0)
        return rewards

    @staticmethod
    def format_reward(prompts: List[str], responses: List[str], answers: List[str], db_schemas: List[str] = None) -> List[float]:
        """输出格式奖励"""
        return [1.0 if RewardFunctions.validate_sql_format(r) else 0.0 for r in responses]

class GRPOTrainer:
    def __init__(
        self,
        model: Union[str, PreTrainedModel],
        reward_funcs: List[Union[str, Callable]],
        config: GRPOConfig,
        train_dataset: Dataset,
        tokenizer: Union[str, AutoTokenizer],
        reward_tokenizers: Optional[List[Union[str, AutoTokenizer]]] = None,
    ):
        self.config = config
        self.model = self._init_model(model)
        self.tokenizer = self._init_tokenizer(tokenizer)
        self.reward_funcs, self.reward_tokenizers = self._init_rewards(reward_funcs, reward_tokenizers)
        self.optimizer = AdamW(self.model.parameters(), lr=self.config.lr)
        self.train_dataset = train_dataset

    def _init_rewards(
        self, 
        reward_funcs: List[Union[str, Callable]], 
        reward_tokenizers: Optional[List[Union[str, AutoTokenizer]]]
    ) -> Tuple[List[Callable], List[Optional[AutoTokenizer]]]:
        """
        初始化奖励函数和对应的tokenizer
        Args:
            reward_funcs: 奖励函数列表，可以是函数或模型路径
            reward_tokenizers: 对应的tokenizer列表
        Returns:
            Tuple: (处理后的奖励函数列表, 对应的tokenizer列表)
        """
        processed_funcs = []
        processed_tokenizers = []
        
        if reward_tokenizers is None:
            reward_tokenizers = [None] * len(reward_funcs)
        
        for func, tokenizer in zip(reward_funcs, reward_tokenizers):
            # 如果是字符串，加载预训练模型
            if isinstance(func, str):
                model = AutoModelForSequenceClassification.from_pretrained(func)
                processed_funcs.append(model.eval())
                
                # 加载对应的tokenizer
                if tokenizer is None:
                    tokenizer = AutoTokenizer.from_pretrained(func)
                if tokenizer.pad_token is None:
                    tokenizer.pad_token = tokenizer.eos_token
                processed_tokenizers.append(tokenizer)
            else:
                # 直接使用函数
                processed_funcs.append(func)
                processed_tokenizers.append(tokenizer)
                
        return processed_funcs, processed_tokenizers

    def _init_model(self, model) -> PreTrainedModel:
        """初始化模型"""
        if isinstance(model, str):
            return AutoModelForCausalLM.from_pretrained(model)
        return model

    def _init_tokenizer(self, tokenizer) -> AutoTokenizer:
        """初始化tokenizer"""
        if isinstance(tokenizer, str):
            tokenizer = AutoTokenizer.from_pretrained(tokenizer)
        tokenizer.padding_side = "left"
        if tokenizer.pad_token is None:
            tokenizer.pad_token = tokenizer.eos_token
        return tokenizer

if __name__ == "__main__":
    config = GRPOConfig()
    
    model_path = "Qwen/Qwen1.5-1.8B"
    dataset_path = "D:/mmodels/20230412_78K_SelfMade_NL2SQLpilot.json"
    
    tokenizer = AutoTokenizer.from_pretrained(model_path)
    model = AutoModelForCausalLM.from_pretrained(model_path)
    
    dataset = NL2SQLDataset(dataset_path, tokenizer)
    
    trainer = GRPOTrainer(
        model=model,
        reward_funcs=[
            RewardFunctions.correctness_reward,
            RewardFunctions.format_reward
        ],
        config=config,
        train_dataset=dataset,
        tokenizer=tokenizer
    )