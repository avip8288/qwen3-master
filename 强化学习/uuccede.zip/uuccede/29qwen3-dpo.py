import os
import torch
import time
from typing import Dict, List
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    TrainerCallback
)
from datasets import load_dataset, Dataset
from trl import DPOTrainer, DPOConfig
from peft import LoraConfig, get_peft_model
import sqlparse
from swanlab.integration.transformers import SwanLabCallback

# 配置参数
MODEL_NAME = "/mnt/d/mmodels/Qwen3-0.6B"
DATASET_PATH = "/mnt/d/mmodels/20230412_78K_SelfMade_NL2SQLpilot.json"
OUTPUT_DIR = "./nl2sql-dpo-final"
MAX_LENGTH = 1024

class SQLValidator:
    """SQL语法和语义验证增强模块"""
    def __init__(self):
        self.error_patterns = {
            'syntax': ["WHEREE", "SELEC", "GROUPP BY", "HAVINGG"],
            'logic': ["CROSS JOIN", "WHERE 1=1", "LIMIT 1000"],
            'security': ["DROP TABLE", "DELETE FROM", "TRUNCATE"]
        }
        
    def validate(self, sql: str) -> Dict[str, float]:
        """综合SQL验证"""
        score = 1.0
        errors = []
        
        # 基础检查
        if not sql.strip():
            return {"score": 0, "errors": ["empty_query"]}
        
        # 语法检查
        try:
            parsed = sqlparse.parse(sql)
            if not parsed:
                score *= 0.3
                errors.append("invalid_syntax")
        except:
            score *= 0.3
            errors.append("parse_error")
        
        # 模式匹配检查
        sql_upper = sql.upper()
        for category, patterns in self.error_patterns.items():
            for p in patterns:
                if p in sql_upper:
                    score *= 0.7
                    errors.append(f"{category}_error:{p}")
        
        return {"score": max(0, min(1, score)), "errors": errors}
    
    def generate_negatives(self, correct_sql: str, num: int = 3) -> List[str]:
        """生成高质量负样本"""
        variants = []
        
        # 语法错误变体
        variants.append(correct_sql.replace("WHERE", "WHEREE"))
        variants.append(correct_sql.replace("SELECT", "SELEC"))
        
        # 逻辑错误变体
        if "WHERE" in correct_sql:
            parts = correct_sql.split("WHERE")
            variants.append(parts[0] + "WHERE 1=1")
            variants.append(parts[0] + "WHERE " + parts[1].replace("=", "!="))
        
        # 结构错误变体
        variants.append("SELECT * FROM (" + correct_sql + ")")
        variants.append(correct_sql.split(";")[0])  # 去掉后续语句
        
        # 选择最有效的负样本
        scored = [(sql, self.validate(sql)["score"]) for sql in variants]
        return [sql for sql, score in sorted(scored, key=lambda x: x[1])[:num]]

class SchemaParser:
    """数据库Schema解析器"""
    @staticmethod
    def extract(input_text: str) -> Dict:
        """从输入文本提取数据库结构"""
        schema = {"tables": [], "columns": [], "relationships": []}
        
        # 提取表结构
        if "MySQL数据库数据库结构如下：" in input_text:
            table_section = input_text.split("MySQL数据库数据库结构如下：")[1].split("\n")[0]
            tables = [t.strip() for t in table_section.split("),")]
            
            for table in tables:
                if "(" in table:
                    name, cols = table.split("(", 1)
                    schema["tables"].append(name.strip())
                    schema["columns"].extend(
                        [f"{name.strip()}.{c.strip()}" 
                         for c in cols.replace(")", "").split(",")]
                    )
        
        # 提取关系
        if "其中:\n" in input_text:
            rel_text = input_text.split("其中:\n")[1].split("\n对于query：")[0]
            schema["relationships"] = [r.strip() for r in rel_text.split("\n") if r.strip()]
        
        return schema

class SQLEnhancer:
    """SQL优化增强器"""
    def __init__(self):
        self.validator = SQLValidator()
    
    def optimize(self, sql: str, schema: Dict) -> str:
        """基于schema优化SQL"""
        # 标准化SQL格式
        formatted = sqlparse.format(sql, reindent=True, keyword_case='upper')
        
        # 添加缺失的关键元素
        if "WHERE" not in formatted and any(col in sql for col in schema["columns"]):
            for col in schema["columns"]:
                if col in sql and "WHERE" not in sql:
                    formatted = formatted.replace(col, f"WHERE {col}")
                    break
        
        return formatted

class CurriculumCallback(TrainerCallback):
    """动态课程学习回调"""
    def __init__(self):
        self.difficulty = 1
        self.best_score = 0
    
    def on_evaluate(self, args, state, control, **kwargs):
        # 根据评估结果调整难度
        metrics = kwargs.get("metrics", {})
        if "eval_accuracy" in metrics:
            accuracy = metrics["eval_accuracy"]
            if accuracy > 0.85 and accuracy > self.best_score:
                self.difficulty = min(3, self.difficulty + 0.2)
                self.best_score = accuracy
            elif accuracy < 0.7:
                self.difficulty = max(1, self.difficulty - 0.1)

def load_model_with_retry(model_name: str, **kwargs):
    """带错误处理和重试的模型加载"""
    for _ in range(3):
        try:
            model = AutoModelForCausalLM.from_pretrained(
                model_name,
                torch_dtype=torch.bfloat16,
                use_cache=False,
                **kwargs
            )
            return model
        except Exception as e:
            print(f"Model loading failed: {e}")
            time.sleep(5)
    raise RuntimeError("Failed to load model after 3 attempts")

def prepare_dataset(dataset_path: str) -> Dataset:
    """数据预处理流水线"""
    raw_data = load_dataset("json", data_files=dataset_path)['train']
    validator = SQLValidator()
    parser = SchemaParser()
    enhancer = SQLEnhancer()
    
    def process_item(item):
        # 验证输入数据
        if not all(key in item for key in ['input', 'output', 'instruction']):
            return None
            
        try:
            # 解析schema
            schema = parser.extract(item["input"])
            
            # 优化正样本SQL
            optimized_sql = enhancer.optimize(item["output"], schema)
            
            # 生成负样本
            negatives = validator.generate_negatives(optimized_sql)
            worst_negative = min(
                negatives, 
                key=lambda x: validator.validate(x)["score"]
            )
            
            # 构建增强prompt - 更健壮的处理方式
            input_parts = item['input'].split('对于query：')
            question = input_parts[1] if len(input_parts) > 1 else item['input']  # 回退到完整输入
            
            enhanced_prompt = (
                f"{item['instruction']}\n"
                f"数据库结构:\n{str(schema)}\n"
                f"问题:\n{question}"
            )
            
            return {
                "prompt": enhanced_prompt,
                "chosen": optimized_sql,
                "rejected": worst_negative,
                "schema": str(schema)
            }
        except Exception as e:
            print(f"Error processing item: {e}")
            return None
    
    processed_data = raw_data.map(process_item, batched=False)
    return processed_data.filter(lambda x: x is not None)

def compute_metrics(eval_preds):
    """自定义评估指标"""
    preds, labels = eval_preds
    validator = SQLValidator()
    
    # 计算SQL准确率
    scores = [validator.validate(p)["score"] for p in preds]
    accuracy = sum(s > 0.8 for s in scores) / len(scores)
    
    return {
        "accuracy": accuracy,
        "avg_score": sum(scores) / len(scores),
        "perfect_rate": sum(s == 1 for s in scores) / len(scores)
    }

def main():
    # 初始化组件
    tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
    tokenizer.add_special_tokens({'additional_special_tokens': ['<TABLE>', '<COLUMN>']})
    
    # 准备数据
    train_data = prepare_dataset(DATASET_PATH)
    if len(train_data) == 0:
        raise ValueError("No valid training data found after preprocessing")
    
    # 加载模型
    device_map = {"": int(os.environ.get("LOCAL_RANK") or 0)}
    model = load_model_with_retry(MODEL_NAME, device_map=device_map)
    ref_model = load_model_with_retry(MODEL_NAME, device_map=device_map)
    
    # 配置LoRA
    lora_config = LoraConfig(
        r=128,
        lora_alpha=64,
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj"],
        lora_dropout=0.1,
        bias="lora_only",
        task_type="CAUSAL_LM"
    )
    model = get_peft_model(model, lora_config)
    
    # 训练配置
    training_args = DPOConfig(
        output_dir=OUTPUT_DIR,
        per_device_train_batch_size=2,
        gradient_accumulation_steps=4,
        learning_rate=3e-5,
        num_train_epochs=5,
        warmup_ratio=0.1,
        weight_decay=0.01,
        max_grad_norm=0.5,
        beta=0.2,
        evaluation_strategy="steps",
        eval_steps=100,
        logging_steps=10,
        save_steps=500,
        fp16=True,
        remove_unused_columns=False,
        metric_for_best_model="accuracy",
        greater_is_better=True,
        max_length=MAX_LENGTH,
        max_prompt_length=768
    )
    
    # 初始化训练器
    trainer = DPOTrainer(
        model=model,
        ref_model=ref_model,
        args=training_args,
        train_dataset=train_data,
        tokenizer=tokenizer,
        callbacks=[SwanLabCallback(), CurriculumCallback()],
        compute_metrics=compute_metrics
    )
    
    # 训练循环
    trainer.train()
    
    # 最终评估和保存
    eval_results = trainer.evaluate()
    print(f"Final evaluation results: {eval_results}")
    
    trainer.save_model(f"{OUTPUT_DIR}/final")
    tokenizer.save_pretrained(f"{OUTPUT_DIR}/final")

if __name__ == "__main__":
    main()