import json
import os
import random
import re
from typing import List, Dict, Any, Optional, Union, Tuple
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from torch.utils.tensorboard import SummaryWriter
from transformers import AutoModelForCausalLM, AutoTokenizer, PreTrainedModel, PreTrainedTokenizer
from dataclasses import dataclass
import swanlab
import deepspeed
from deepspeed import init_distributed
from deepspeed.runtime.pipe import PipelineModule
from deepspeed.utils import RepeatingLoader
from transformers.deepspeed import HfDeepSpeedConfig
import numpy as np

# SwanLab 导入
try:
    import swanlab
    from swanlab import Experiment
    SWANLAB_AVAILABLE = True
except ImportError:
    SWANLAB_AVAILABLE = False
    print("警告：未安装SwanLab，记录功能将仅使用TensorBoard")

def set_seed(seed: int = 42):
    random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

set_seed()

# 初始化分布式环境
init_distributed()
local_rank = torch.distributed.get_rank()
torch.cuda.set_device(local_rank)
world_size = torch.distributed.get_world_size()
device = f"cuda:{local_rank}" if torch.cuda.is_available() else "cpu"

class NL2SQLDataset(Dataset):
    def __init__(self, data_path: str, tokenizer: PreTrainedTokenizer, max_length: int = 512):
        self.data = self._load_data(data_path)
        self.tokenizer = tokenizer
        self.max_length = max_length
        
    def _load_data(self, data_path: str) -> List[Dict[str, str]]:
        try:
            with open(data_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            return data
        except Exception as e:
            print(f"加载数据失败: {e}")
            return []
            
    def __len__(self) -> int:
        return len(self.data)
        
    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        item = self.data[idx]
        instruction = item["instruction"]
        input_text = item["input"]
        output = item["output"]
        prompt = f"{instruction}\n{input_text}"
        
        inputs = self.tokenizer(
            prompt,
            max_length=self.max_length,
            truncation=True,
            padding="max_length",
            return_tensors="pt",
        )
        
        targets = self.tokenizer(
            output,
            max_length=self.max_length,
            truncation=True,
            padding="max_length",
            return_tensors="pt",
        )
        
        return {
            "input_ids": inputs["input_ids"].squeeze(0),
            "attention_mask": inputs["attention_mask"].squeeze(0),
            "target_ids": targets["input_ids"].squeeze(0),
            "target_attention_mask": targets["attention_mask"].squeeze(0),
        }

class DPORewardModel(nn.Module):
    def __init__(self, base_model: PreTrainedModel):
        super().__init__()
        self.base_model = base_model
        self.reward_head = nn.Linear(base_model.config.hidden_size, 1)
        self.to(base_model.dtype)
        
    def forward(self, input_ids: torch.Tensor, attention_mask: torch.Tensor) -> torch.Tensor:
        outputs = self.base_model(input_ids, attention_mask=attention_mask)
        # 使用最后一个token的隐藏状态计算奖励
        last_token_idx = attention_mask.sum(dim=1) - 1
        last_token_hidden = outputs.last_hidden_state[torch.arange(len(input_ids)), last_token_idx]
        reward = self.reward_head(last_token_hidden).squeeze(-1)
        return reward

@dataclass
class DPOSamples:
    prompt_ids: torch.Tensor
    prompt_attention_mask: torch.Tensor
    chosen_ids: torch.Tensor
    chosen_attention_mask: torch.Tensor
    rejected_ids: torch.Tensor
    rejected_attention_mask: torch.Tensor
    prompt_length: torch.Tensor
    chosen_length: torch.Tensor
    rejected_length: torch.Tensor

@dataclass
class DPOExperience:
    prompt_ids: torch.Tensor
    prompt_attention_mask: torch.Tensor
    chosen_ids: torch.Tensor
    chosen_attention_mask: torch.Tensor
    rejected_ids: torch.Tensor
    rejected_attention_mask: torch.Tensor
    prompt_length: torch.Tensor
    chosen_length: torch.Tensor
    rejected_length: torch.Tensor
    chosen_log_probs: torch.Tensor
    rejected_log_probs: torch.Tensor
    reference_chosen_log_probs: torch.Tensor
    reference_rejected_log_probs: torch.Tensor

def generate_dpo_samples(prompts, actor_model, ref_model, tokenizer, max_length=512, max_new_tokens=128, n_rejected=1):
    samples_list = []
    actor_model.eval()
    ref_model.eval()
    
    for prompt in prompts:
        # 编码提示词
        prompt_inputs = tokenizer(
            prompt,
            padding="max_length",
            max_length=max_length - max_new_tokens,
            truncation=True,
            return_tensors="pt",
        )
        prompt_ids = prompt_inputs["input_ids"].to(device)
        prompt_attention_mask = prompt_inputs["attention_mask"].to(device)
        prompt_length = prompt_attention_mask.sum(dim=1)
        
        with torch.no_grad():
            # 生成首选响应
            chosen_outputs = actor_model.generate(
                input_ids=prompt_ids,
                attention_mask=prompt_attention_mask,
                max_new_tokens=max_new_tokens,
                pad_token_id=tokenizer.pad_token_id,
                eos_token_id=tokenizer.eos_token_id,
                do_sample=True,
                temperature=0.7,
                top_p=0.9,
                num_return_sequences=1,
            )
            chosen_ids = chosen_outputs[0]
            chosen_attention_mask = (chosen_ids != tokenizer.pad_token_id).to(dtype=torch.long)
            chosen_length = chosen_attention_mask.sum(dim=0)
            
            # 生成拒绝响应（使用参考模型或随机采样）
            rejected_outputs = ref_model.generate(
                input_ids=prompt_ids,
                attention_mask=prompt_attention_mask,
                max_new_tokens=max_new_tokens,
                pad_token_id=tokenizer.pad_token_id,
                eos_token_id=tokenizer.eos_token_id,
                do_sample=True,
                temperature=0.9,
                top_p=0.95,
                num_return_sequences=n_rejected,
            )
            rejected_ids = rejected_outputs[0]  # 取第一个拒绝样本
            rejected_attention_mask = (rejected_ids != tokenizer.pad_token_id).to(dtype=torch.long)
            rejected_length = rejected_attention_mask.sum(dim=0)
        
        samples = DPOSamples(
            prompt_ids=prompt_ids,
            prompt_attention_mask=prompt_attention_mask,
            chosen_ids=chosen_ids,
            chosen_attention_mask=chosen_attention_mask,
            rejected_ids=rejected_ids,
            rejected_attention_mask=rejected_attention_mask,
            prompt_length=prompt_length,
            chosen_length=chosen_length,
            rejected_length=rejected_length,
        )
        samples_list.append(samples)
    
    return samples_list

def compute_dpo_loss(actor_model, ref_model, samples, reward_model, beta=0.1, temperature=1.0):
    prompt_ids = samples.prompt_ids
    prompt_attention_mask = samples.prompt_attention_mask
    chosen_ids = samples.chosen_ids
    chosen_attention_mask = samples.chosen_attention_mask
    rejected_ids = samples.rejected_ids
    rejected_attention_mask = samples.rejected_attention_mask
    prompt_length = samples.prompt_length
    chosen_length = samples.chosen_length
    rejected_length = samples.rejected_length
    
    batch_size = prompt_ids.size(0)
    
    # 计算首选响应的对数概率
    with torch.no_grad():
        ref_chosen_outputs = ref_model(chosen_ids, attention_mask=chosen_attention_mask)
        ref_chosen_logits = ref_chosen_outputs.logits
        ref_chosen_log_probs = F.log_softmax(ref_chosen_logits, dim=-1)
        
        ref_rejected_outputs = ref_model(rejected_ids, attention_mask=rejected_attention_mask)
        ref_rejected_logits = ref_rejected_outputs.logits
        ref_rejected_log_probs = F.log_softmax(ref_rejected_logits, dim=-1)
    
    # 计算演员模型的对数概率
    actor_chosen_outputs = actor_model(chosen_ids, attention_mask=chosen_attention_mask)
    actor_chosen_logits = actor_chosen_outputs.logits
    actor_chosen_log_probs = F.log_softmax(actor_chosen_logits, dim=-1)
    
    actor_rejected_outputs = actor_model(rejected_ids, attention_mask=rejected_attention_mask)
    actor_rejected_logits = actor_rejected_outputs.logits
    actor_rejected_log_probs = F.log_softmax(actor_rejected_logits, dim=-1)
    
    # 计算奖励
    chosen_inputs = torch.cat([prompt_ids, chosen_ids], dim=1)
    chosen_inputs_attention = torch.cat([prompt_attention_mask, chosen_attention_mask], dim=1)
    chosen_rewards = reward_model(chosen_inputs, chosen_inputs_attention)
    
    rejected_inputs = torch.cat([prompt_ids, rejected_ids], dim=1)
    rejected_inputs_attention = torch.cat([prompt_attention_mask, rejected_attention_mask], dim=1)
    rejected_rewards = reward_model(rejected_inputs, rejected_inputs_attention)
    
    # 计算DPO损失
    loss = 0
    for i in range(batch_size):
        # 首选响应的对数概率（从提示词后开始）
        chosen_start = prompt_length[i]
        chosen_end = prompt_length[i] + chosen_length[i]
        chosen_tokens = chosen_ids[i, chosen_start:chosen_end]
        chosen_actor_log_probs = actor_chosen_log_probs[i, chosen_start-1:chosen_end-1, :]
        chosen_ref_log_probs = ref_chosen_log_probs[i, chosen_start-1:chosen_end-1, :]
        
        # 拒绝响应的对数概率
        rejected_start = prompt_length[i]
        rejected_end = prompt_length[i] + rejected_length[i]
        rejected_tokens = rejected_ids[i, rejected_start:rejected_end]
        rejected_actor_log_probs = actor_rejected_log_probs[i, rejected_start-1:rejected_end-1, :]
        rejected_ref_log_probs = ref_rejected_log_probs[i, rejected_start-1:rejected_end-1, :]
        
        # 提取目标token的对数概率
        chosen_actor_log_probs = chosen_actor_log_probs.gather(2, chosen_tokens.unsqueeze(-1)).squeeze(-1)
        chosen_ref_log_probs = chosen_ref_log_probs.gather(2, chosen_tokens.unsqueeze(-1)).squeeze(-1)
        rejected_actor_log_probs = rejected_actor_log_probs.gather(2, rejected_tokens.unsqueeze(-1)).squeeze(-1)
        rejected_ref_log_probs = rejected_ref_log_probs.gather(2, rejected_tokens.unsqueeze(-1)).squeeze(-1)
        
        # 计算对数概率总和
        chosen_actor_sum = chosen_actor_log_probs.sum()
        chosen_ref_sum = chosen_ref_log_probs.sum()
        rejected_actor_sum = rejected_actor_log_probs.sum()
        rejected_ref_sum = rejected_ref_log_probs.sum()
        
        # 计算奖励差异
        reward_diff = chosen_rewards[i] - rejected_rewards[i]
        
        # DPO目标函数
        log_ratio = (chosen_actor_sum - rejected_actor_sum) - (chosen_ref_sum - rejected_ref_sum)
        loss_i = -torch.log(torch.sigmoid(reward_diff * log_ratio / temperature)) + beta * (chosen_ref_sum - chosen_actor_sum)
        loss += loss_i
    
    return loss / batch_size

def train_step_dpo(experience, actor_model, reward_model, optimizer_actor, beta=0.1, temperature=1.0,
                 writer=None, swan_experiment=None, global_step=0):
    actor_model.train()
    reward_model.train()
    
    optimizer_actor.zero_grad()
    
    with torch.cuda.amp.autocast(dtype=torch.float16):
        loss = compute_dpo_loss(
            actor_model, 
            experience.ref_model, 
            experience, 
            reward_model, 
            beta=beta, 
            temperature=temperature
        )
    
    loss.backward()
    torch.nn.utils.clip_grad_norm_(actor_model.parameters(), 1.0)
    optimizer_actor.step()
    
    if writer is not None and local_rank == 0:
        writer.add_scalar("dpo_loss", loss.item(), global_step)
        writer.add_scalar("reward_diff", experience.reward_diff.mean().item(), global_step)
    
    # SwanLab 记录指标
    if swan_experiment and SWANLAB_AVAILABLE and local_rank == 0:
        swan_experiment.log_metrics({
            "dpo_loss": loss.item(),
            "reward_diff": experience.reward_diff.mean().item()
        }, step=global_step)
    
    if local_rank == 0:
        print(f"Step {global_step}: DPO Loss = {loss.item():.4f}, Reward Diff = {experience.reward_diff.mean().item():.4f}")
    return loss.item()

def create_ds_config(world_size):
    """创建DeepSpeed配置"""
    ds_config = {
        "zero_optimization": {
            "stage": 3,
            "offload_optimizer": {
                "device": "cpu",
                "pin_memory": True
            },
            "offload_param": {
                "device": "cpu",
                "pin_memory": True
            },
            "allgather_partitions": True,
            "allgather_bucket_size": 5e8,
            "overlap_comm": True,
            "reduce_scatter": True,
            "contiguous_gradients": True
        },
        "fp16": {
            "enabled": True,
            "loss_scale": 0,
            "loss_scale_window": 1000,
            "initial_scale_power": 16,
            "hysteresis": 2,
            "min_loss_scale": 1
        },
        "gradient_accumulation_steps": 4,
        "gradient_clipping": 1.0,
        "steps_per_print": 10,
        "train_batch_size": None,
        "train_micro_batch_size_per_gpu": 2,
        "wall_clock_breakdown": False,
        "model_parallel_size": world_size,
        "pipeline_parallel": {
            "enabled": True,
            "chunks": 4,
            "pipeline_batch_size": 2
        }
    }
    return ds_config

def create_layer_split_model(model, world_size):
    """按层切分模型"""
    if world_size == 1:
        return model.to(device)
    
    num_layers = model.config.num_hidden_layers
    layers_per_gpu = num_layers // world_size
    
    class QWenPipeline(PipelineModule):
        def __init__(self, layers):
            super().__init__()
            self.layers = nn.ModuleList(layers)
        
        def forward(self, input_ids, attention_mask):
            hidden_states = model.model.embedding(input_ids)
            hidden_states = model.model.layers[0].ln_1(hidden_states)
            for layer in self.layers:
                hidden_states = layer(hidden_states, attention_mask)
            hidden_states = model.model.layers[-1].ln_2(hidden_states)
            output = model.lm_head(hidden_states)
            return output
    
    layers = model.model.layers
    split_layers = []
    for i in range(world_size):
        start = i * layers_per_gpu
        end = start + layers_per_gpu if i < world_size - 1 else num_layers
        split_layers.append(layers[start:end])
    
    pipe_models = []
    for i in range(world_size):
        pipe_model = QWenPipeline(split_layers[i])
        pipe_model.to(f"cuda:{i}")
        pipe_models.append(pipe_model)
    
    class DistributedQWen(nn.Module):
        def __init__(self, pipe_models):
            super().__init__()
            self.pipe_models = pipe_models
            self.embedding = model.model.embedding
            self.lm_head = model.lm_head
            self.layers = model.model.layers
        
        def forward(self, input_ids, attention_mask):
            hidden_states = self.embedding(input_ids)
            hidden_states = self.layers[0].ln_1(hidden_states)
            for i, pipe_model in enumerate(self.pipe_models):
                hidden_states = pipe_model(hidden_states, attention_mask)
            hidden_states = self.layers[-1].ln_2(hidden_states)
            output = self.lm_head(hidden_states)
            return output
    
    return DistributedQWen(pipe_models)

def train(actor_model, ref_model, reward_model, tokenizer, dataset, output_dir="./results", 
          batch_size=4, micro_batch_size=1, max_epochs=3, max_new_tokens=128, beta=0.1, temperature=1.0,
          learning_rate_actor=5e-6, log_dir="./logs"):
    os.makedirs(output_dir, exist_ok=True)
    
    # 创建DeepSpeed配置
    ds_config = create_ds_config(world_size)
    
    # 配置DeepSpeed for Actor模型
    dschf_config = HfDeepSpeedConfig(ds_config)
    
    # 按层切分模型
    actor_model = create_layer_split_model(actor_model, world_size)
    
    # 初始化DeepSpeed优化器
    optimizer_actor = torch.optim.AdamW(actor_model.parameters(), lr=learning_rate_actor)
    
    # 集成DeepSpeed
    actor_model, optimizer_actor, _, _ = deepspeed.initialize(
        model=actor_model,
        optimizer=optimizer_actor,
        config_params=ds_config
    )
    
    # 数据并行包装Reward模型
    if world_size > 1:
        reward_model = nn.parallel.DistributedDataParallel(reward_model, device_ids=[local_rank])
    
    # 仅在主卡创建SummaryWriter
    writer = SummaryWriter(log_dir) if local_rank == 0 else None
    
    # SwanLab 初始化实验
    swan_experiment = None
    if SWANLAB_AVAILABLE and local_rank == 0:
        try:
            swan_experiment = Experiment(
                project_name="NL2SQL-DPO",
                experiment_name="SQL生成模型DPO训练",
                tags=["NL2SQL", "DPO", "强化学习", f"{world_size}卡训练"]
            )
            # 记录超参数
            swan_experiment.log_params({
                "batch_size": batch_size,
                "micro_batch_size": micro_batch_size,
                "max_epochs": max_epochs,
                "max_new_tokens": max_new_tokens,
                "beta": beta,
                "temperature": temperature,
                "learning_rate_actor": learning_rate_actor,
                "gpu_count": world_size
            })
        except Exception as e:
            print(f"SwanLab初始化失败: {e}")
            swan_experiment = None
    
    global_step = 0
    
    # 创建数据加载器
    train_sampler = torch.utils.data.DistributedSampler(dataset, shuffle=True)
    dataloader = DataLoader(dataset, batch_size=batch_size, sampler=train_sampler)
    dataloader = RepeatingLoader(dataloader)
    
    for epoch in range(max_epochs):
        if local_rank == 0:
            print(f"Epoch {epoch+1}/{max_epochs}")
        
        for batch_idx in range(100):
            batch = next(dataloader)
            input_ids = batch["input_ids"].to(device)
            attention_mask = batch["attention_mask"].to(device)
            target_ids = batch["target_ids"].to(device)
            
            # 准备提示词
            prompts = [tokenizer.decode(input_ids[i][:attention_mask[i].sum()], skip_special_tokens=True) for i in range(len(input_ids))]
            
            # 生成DPO样本
            samples_list = generate_dpo_samples(
                prompts, actor_model, ref_model, tokenizer, 
                max_length=512, max_new_tokens=max_new_tokens, n_rejected=1
            )
            
            # 计算奖励差异
            reward_diff_list = []
            for samples in samples_list:
                chosen_inputs = torch.cat([samples.prompt_ids, samples.chosen_ids], dim=1)
                chosen_attention = torch.cat([samples.prompt_attention_mask, samples.chosen_attention_mask], dim=1)
                chosen_reward = reward_model(chosen_inputs, chosen_attention)
                
                rejected_inputs = torch.cat([samples.prompt_ids, samples.rejected_ids], dim=1)
                rejected_attention = torch.cat([samples.prompt_attention_mask, samples.rejected_attention_mask], dim=1)
                rejected_reward = reward_model(rejected_inputs, rejected_attention)
                
                reward_diff = chosen_reward - rejected_reward
                reward_diff_list.append(reward_diff)
            
            # 训练步骤
            for samples, reward_diff in zip(samples_list, reward_diff_list):
                experience = DPOExperience(
                    prompt_ids=samples.prompt_ids,
                    prompt_attention_mask=samples.prompt_attention_mask,
                    chosen_ids=samples.chosen_ids,
                    chosen_attention_mask=samples.chosen_attention_mask,
                    rejected_ids=samples.rejected_ids,
                    rejected_attention_mask=samples.rejected_attention_mask,
                    prompt_length=samples.prompt_length,
                    chosen_length=samples.chosen_length,
                    rejected_length=samples.rejected_length,
                    ref_model=ref_model,
                    reward_diff=reward_diff
                )
                
                loss = train_step_dpo(
                    experience, actor_model, reward_model, optimizer_actor,
                    beta=beta, temperature=temperature,
                    writer=writer, swan_experiment=swan_experiment, global_step=global_step
                )
                global_step += 1
            
            if (batch_idx + 1) % 10 == 0 and local_rank == 0:
                print(f"Batch {batch_idx+1} completed, Loss: {loss:.4f}")
        
        # 仅在主卡保存检查点
        if local_rank == 0:
            print(f"Saving model at epoch {epoch+1}")
            model_save_path = os.path.join(output_dir, f"model_epoch_{epoch+1}")
            unwrapped_model = actor_model.module if hasattr(actor_model, "module") else actor_model
            unwrapped_model.save_pretrained(model_save_path)
            tokenizer.save_pretrained(model_save_path)
            
            if swan_experiment and SWANLAB_AVAILABLE:
                swan_experiment.log_artifact(model_save_path, name=f"model_epoch_{epoch+1}")
    
    if local_rank == 0:
        print("Training completed! Saving final model...")
        model_save_path = os.path.join(output_dir, "final_model")
        unwrapped_model = actor_model.module if hasattr(actor_model, "module") else actor_model
        unwrapped_model.save_pretrained(model_save_path)
        tokenizer.save_pretrained(model_save_path)
        
        if swan_experiment and SWANLAB_AVAILABLE:
            swan_experiment.log_artifact(model_save_path, name="final_model")
            swan_experiment.complete()
    
    if writer:
        writer.close()
    print("Training finished.")

def evaluate(model, tokenizer, dataset, num_samples=10, max_new_tokens=128):
    model.eval()
    indices = random.sample(range(len(dataset)), min(num_samples, len(dataset)))
    
    eval_results = []
    for i, idx in enumerate(indices):
        sample = dataset[idx]
        input_ids = sample["input_ids"].unsqueeze(0).to(device)
        attention_mask = sample["attention_mask"].unsqueeze(0).to(device)
        target_ids = sample["target_ids"]
        
        with torch.no_grad():
            outputs = model.generate(
                input_ids=input_ids,
                attention_mask=attention_mask,
                max_new_tokens=max_new_tokens,
                pad_token_id=tokenizer.pad_token_id,
                eos_token_id=tokenizer.eos_token_id,
            )
        
        generated_sql = tokenizer.decode(outputs[0][input_ids.shape[1]:], skip_special_tokens=True)
        target_sql = tokenizer.decode(target_ids, skip_special_tokens=True)
        prompt = tokenizer.decode(input_ids[0][:attention_mask[0].sum()], skip_special_tokens=True)
        
        is_correct = "SELECT" in generated_sql and "FROM" in generated_sql
        eval_results.append({
            "prompt": prompt,
            "generated_sql": generated_sql,
            "target_sql": target_sql,
            "is_correct": is_correct
        })
        
        if local_rank == 0:
            print(f"\n示例 {i+1}:")
            print(f"输入提示:\n{prompt}")
            print(f"\n生成的SQL:\n{generated_sql}")
            print(f"\n参考SQL:\n{target_sql}")
            print(f"评估结果: {'正确' if is_correct else '错误'}")
            print("-" * 80)
    
    if SWANLAB_AVAILABLE and swan_experiment and local_rank == 0:
        accuracy = sum(1 for r in eval_results if r["is_correct"]) / len(eval_results)
        swan_experiment.log_metrics({"evaluation_accuracy": accuracy})
        swan_experiment.log_table("evaluation_results", eval_results)
    
    return eval_results

def main():
    model_name = r"D:\mmodels\Qwen2___5-0___5B-Instruct"
    dataset_path = r"D:\mmodels\20230412_78K_SelfMade_NL2SQLpilot.json"
    output_dir = "./nl2sql_dpo_results"
    log_dir = "./nl2sql_dpo_logs"
    
    tokenizer = AutoTokenizer.from_pretrained(model_name, trust_remote_code=True)
    tokenizer.padding_side = "left"
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    
    # 加载模型
    actor_model = AutoModelForCausalLM.from_pretrained(
        model_name, 
        trust_remote_code=True,
        torch_dtype=torch.float16,
        device_map="auto"
    )
    actor_model.train()
    for param in actor_model.parameters():
        param.requires_grad_(True)
    
    ref_model = AutoModelForCausalLM.from_pretrained(
        model_name, 
        trust_remote_code=True,
        torch_dtype=torch.float16,
        device_map="auto"
    )
    
    reward_model = DPORewardModel(actor_model.base_model).to(device)
    
    dataset = NL2SQLDataset(dataset_path, tokenizer)
    
    train(
        actor_model=actor_model,
        ref_model=ref_model,
        reward_model=reward_model,
        tokenizer=tokenizer,
        dataset=dataset,
        output_dir=output_dir,
        batch_size=4,
        micro_batch_size=1,
        max_epochs=3,
        max_new_tokens=128,
        beta=0.1,
        temperature=1.0,
        learning_rate_actor=5e-6,
        log_dir=log_dir,
    )
    
    if local_rank == 0:
        evaluate(
            model=actor_model,
            tokenizer=tokenizer,
            dataset=dataset,
            num_samples=5,
            max_new_tokens=128,
        )

if __name__ == "__main__":
    main()

    '''

    # 1卡运行
deepspeed --num_gpus=1 train_script.py

# 4卡运行
deepspeed --num_gpus=4 train_script.py

'''